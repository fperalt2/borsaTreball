function hideShow() {
    var password = document.getElementById("password");
    if (password.type == 'password') {
        password.type = 'text';
    } else {
        password.type = 'password';
    }
    var hide = document.getElementById("hide");
    
    if (hide.className == 'mostrar') {
        jQuery('#hide i').addClass('fa-eye');
        jQuery('#hide i').removeClass('fa-eye-slash');
        hide.className = 'ocultar';
    } else {
        jQuery('#hide i').addClass('fa-eye-slash');
        jQuery('#hide i').removeClass('fa-eye');
        hide.className = 'mostrar';
    }
}

window.onload = function () {

}


function fGetCookie() {
    document.getElementById("name").value = getCookie("username");
}

function fSetCookie() {
    var days = "10";
    var checkusername = document.getElementById("checkusername");
    var username = document.getElementById("username");
    if (checkusername.checked) {
        setCookie("username", username.value, days);
        setCookie("checkusername", 1, days);

    } else {
        delCookie("username");
        delCookie("checkusername");
    }

}

function setCookie(NameOfCookie, value, expiredays) {
    var ExpireDate = new Date();
    ExpireDate.setTime(ExpireDate.getTime() + (expiredays * 24 * 3600 * 1000));
    document.cookie = NameOfCookie + "=" + escape(value) +
        ((expiredays == null) ? "" : "; expires=" + ExpireDate.toGMTString());
}

function getCookie(NameOfCookie) {
    if (document.cookie.length > 0) {
        begin = document.cookie.indexOf(NameOfCookie + "=");
        if (begin != -1) {
            begin += NameOfCookie.length + 1;
            end = document.cookie.indexOf(";", begin);
            if (end == -1) end = document.cookie.length;
            return unescape(document.cookie.substring(begin, end));
        }
    }
    return null;
}

function delCookie(NameOfCookie) {
    if (getCookie(NameOfCookie)) {
        document.cookie = NameOfCookie + "=" +
            "; expires=Thu, 01-Jan-70 00:00:01 GMT";
    }
}