//DESPLEGABLE

$(document).ready(function() {
    $('.boton-desplegar').on('click',function(){
        $('.desplegable').slideToggle();
        $('.boton-desplegar i').toggleClass('.fa-caret-right');
        $('.boton-desplegar i').toggleClass('.fa-caret-down');
    });
});