$(document).ready(function() {
    netejarInputs();
//    afegirEtiqueta();
    afegirCicle();
    inizialitzarEventsEdit();
});

function netejarInputs() {
    $('#divCiclesEnviar').val('');
//    $('#divEtiquetesEnviar').val('');
}

function inizialitzarEvents() {
//    $('#divEtiquetes .icon-cancel-circled').click(function(){
//        var cercar = $(this).text();
//        console.log(cercar);
//        var content = $('#divCiclesEnviar').val();
//        var values = content.split(";");
//        var res = "";
//        for (var i = 0; i < values.length; i++) {
//            if (values[i] == cercar) {
//                values.splice(i, 1);
//            }
//            res += values[i] + ";";
//        }
//        
//        $('#divEtiquetesEnviar').val(res);
//        actualitzarEtiquetes();
//    });
//    
    
    $('#divCicles .icon-cancel-circled').click(function(){
        var cercar = $(this).attr("data-idcicle");
        var content = $('#divCiclesEnviar').val();
        var values = content.split(";");
        values.splice(-1,1);
        var res = "";
        var pos = -1;
        for (var i = 0; i < values.length; i++) {
            if (values[i] != cercar) {
                res += values[i] + ";";
            }
            
            
            
        }    
        
        $('#divCiclesEnviar').val(res);
        actualitzarCicles(res);
    });

}

function inizialitzarEventsEdit() {

    var valors = $('#divCiclesEnviar').attr('data-value');
    if(valors!=null){
        document.getElementById('divCiclesEnviar').value = valors;

        actualitzarCicles(valors);
    }
}



function actualitzarCicles(cicles) {
//    var content = $('#divCiclesEnviar').val();
    var selectValues = $('#selectCicle option');
    var valuesId = cicles.split(";");
    var res = "";
    valuesId.splice(-1,1);
    for (var i = 0; i < valuesId.length; i++) {
        for (var j = 0; j < selectValues.length; j++) {
            if (valuesId[i] == selectValues[j].value) {
                res += "<span class='icon-cancel-circled' data-idcicle='"+valuesId[i]+"'>" + selectValues[j].innerHTML + "</span>";
            }        
        }
    }
    $('#divCicles').html(res);
    inizialitzarEvents();
}

//function actualitzarEtiquetes(etiquetes) {
////    var content = $('#divEtiquetesEnviar').val();
//    var values = etiquetes.split(";");
//    var res = "";
//    values.splice(-1,1);
//    for (var i = 0; i < values.length; i++) {
//        res += "<span class='icon-cancel-circled'>" + values[i] + "</span>"
//    }
//    
//    $('#divEtiquetes').html(res);
//}


function afegirCicle() {
    var content = "";
    var contentHtml = ""
    
    $('#afegirCicle').click(function(){
        var values = [];
        var existeixCicle = false;
        var selectValueId = $('#selectCicle option:selected').val();
        
        content = $('#divCiclesEnviar').val();
        
        values = content.split(";");
        for (var i = 0; i < values.length; i++){
            if (selectValueId == values[i]) {
                existeixCicle = true;
            }
        }
        
        if (!existeixCicle){
//            afegirEtiquetesCicle(selectValueId);
            content += selectValueId + ";";
            $('#divCiclesEnviar').val(content);
            actualitzarCicles(content);
        }
    });
}
//
//function afegirEtiqueta() {
//    var content = "";
//    var valuesHtml = "";
//    var contentHtml = "";
//    
//    $('#afegirEtiqueta').click(function(){ 
//        content = $('#divEtiquetesEnviar').val();
//        valuesHtml = $('#divEtiquetesEnviar');
//        var hola = $("option[data-cicle=" + selectValueId + "]");
//        
//        for (var i = 0; i < valuesHtml.length; i++) {
//            contentHtml += valuesHtml[i].innerHTML + ";";
//            console.log(valuesHtml[i]);
//        }
//        
//        var selectValue = $('#selectEtiqueta option:selected').html();
//        
//        if(!validarExisteix(content, selectValue)) {
//            content += selectValue + ";";
//            $('#divEtiquetesEnviar').val(content);
//            actualitzarEtiquetes(contentHtml);
//        }
//    });
//}
//
//function afegirEtiquetesCicle(selectValueId) {
//
//    var content = $('#divEtiquetesEnviar').val();
//    var values = $("option[data-cicle=" + selectValueId + "]");
//    var valuesHtml = $("option[data-cicle=" + selectValueId + "]");
//    var contentHtml = "";
//    
//    for (var i = 0; i < values.length; i++) {
//        if(!validarExisteix(content, values[i].value)) {
//            content += values[i].value + ";";
//        }
//        contentHtml += valuesHtml[i].innerHTML + ";";
//    }
//    for (var i = 0; i < contentHtml.length; i++) {
//
//        console.log(contentHtml);
//     }
//    
//    $('#divEtiquetesEnviar').val(content);
//    actualitzarEtiquetes(contentHtml);
//}

//EVITAR DUPLICATS
function validarExisteix(content, valorComprovar) {
    var existeix = false;
    var values = [];
    values = content.split(";");
    
    for (var i = 0; i < values.length; i++){
        if (values[i] == valorComprovar) {
            existeix = true;
        }
    }
    if (existeix) {
        return true;
    } else {
        return false;
    }
}

//GENERATE SELECT
function mostraCursos(dades) {
    var select = "";
    for (var i in dades) {
        select += '<option value="' + i + '">' + dades[i] + '</option>\n';
    }
    $("#provincia").html(select);
}

function mostraEtiquetes(dades) {
    var select = "";
    for (var i in dades) {
        select += '<option value="' + i + '">' + dades[i] + '</option>\n';
    }
    $("#municipio").html(select);

}
