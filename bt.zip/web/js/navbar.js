$(document).ready(function() {
    $(".fa-angle-down").click(function(){
        $(".fa-angle-down").css('display', 'none !important');
        $(".fa-angle-up").css('display', 'inline-block !important');
    });

    $(".fa-angle-up").click(function(){
        $(".fa-angle-up").css('display', 'none !important');
        $(".fa-angle-down").css('display', 'inline-block !important');
    });

    $(".fa-angle-down").click(function(){
    });
});