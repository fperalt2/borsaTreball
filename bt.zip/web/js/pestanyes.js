function openTab(evt, tabName) {
    var tabcontent = document.getElementsByClassName("tab_content");
    var tablinks = document.getElementsByClassName("tablinks");
    
    
    for (var i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.visibility = "hidden";
        tabcontent[i].style.display = "none";
    }
    
    for (var i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    
    document.getElementById(tabName).style.visibility = "visible";
    document.getElementById(tabName).style.display = "flex";
    
    evt.currentTarget.className += " active";
}


function openTabShow(evt, tabName) {
    var tabcontent = document.getElementsByClassName("tab_content_show");
    var tablinks = document.getElementsByClassName("tablinks");
    
    
    for (var i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.visibility = "hidden";
        tabcontent[i].style.display = "none";
    }
    
    for (var i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    
    document.getElementById(tabName).style.visibility = "visible";
    document.getElementById(tabName).style.display = "block";
    
    evt.currentTarget.className += " active";
}





//
//$(function () {
//    $("#dades-personals").click(function () {
//        $('html, body').animate({
//            scrollTop: $("#dades-personals").offset().top
//        }, 1000);
//    });
//    $("#dades_academiques").click(function () {
//        $('html, body').animate({
//            scrollTop: $("#dades_academiques").offset().top
//        }, 1500);
//    });
//    $("#dades_situacio").click(function () {
//        $('html, body').animate({
//            scrollTop: $("#dades_situacio").offset().top
//        }, 1500);
//    });
//    $("#dades_altres").click(function () {
//        $('html, body').animate({
//            scrollTop: $("#dades_altres").offset().top
//        }, 1500);
//    });
//    $("#dades_registre").click(function () {
//        $('html, body').animate({
//            scrollTop: $("#dades_registre").offset().top
//        }, 1500);
//    });
//});
//
//    $(".tab_content").hide();
//    $(".tab_content:first").show(); 
//
//    $("ul.tabs li").click(function() {
//        $("ul.tabs li").removeClass("active");
//        var rel = $(this).attr('rel');
//        var li = $("ul.tabs li").attr('rel');
//        if($("ul.tabs li").attr('rel') == rel){
//            //alert(rel);
//            //var c = rel.split("_");
//            //alert(c[1]);
//            $("ul.tabs li."+rel).addClass("active");
//        }
//        $(this).addClass("active");
//        $(".tab_content").hide();
//        var activeTab = $(this).attr("rel"); 
//        $("#"+activeTab).fadeIn(); 
//    });
    
    
