<?php


    $em = $this->getDoctrine()->getManager();

    $usuaris = $em->getRepository('borsaTreballWebBundle:Usuari')->findAll();

    foreach ($usuaris as $usuari){
        if ($usuari->getUsername() == $username) {
            echo "true";  
        }
    }
    echo "false";
?>
