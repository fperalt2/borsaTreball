<?php

namespace borsaTreball\WebBundle\Utils\fpdf;

class FitxaPDF extends FPDF
{

function Header()
{
	// To be implemented in your own inherited class
	// Select Arial bold 15
    $this->SetFont('Arial','B',12);
    // Move to the right
    //$this->Cell(80);
    // Framed title
		$titol1 = 'Generalitat de Catalunya - Departament d\'Ensenyament';
		//$titol .= '                                       ';
		//$titol .= 'Institut Carles Vallbona';
		$titol2 = 'Institut Carles Vallbona';
		$this->Cell(30,10,$titol1,0,0,'L');
		$this->Ln(5);
		$this->Cell(30,10,$titol2,0,0,'L');
		//$this->Cell(15,10,'Generalitat de Catalunya - Departament d\'Ensenyament',0,0,'L');
		//$this->Cell(15,10,'Institut Carles Vallbona',0,0,'R');
		//$this->Cell(30,10,'Departament d\'Ensenyament',0,0,'L');
    //$this->Cell(30,10,'Institut Carles Vallbona',0,0,'L');
    // Line break
    $this->Ln(10);
}

function Footer()
{
	// To be implemented in your own inherited class
}

}
?>
