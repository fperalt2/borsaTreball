<?php

namespace borsaTreball\WebBundle\Controller;

use borsaTreball\WebBundle\Entity\Idioma;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
/**
 * Idioma controller.
 *
 */
class IdiomaController extends Controller
{
    /**
     * Lists all idioma entities.
     *
     */
    public function indexAction()
    {
        $this->denyAccessUnlessGranted(['ROLE_1','ROLE_2','ROLE_3']);
        $em = $this->getDoctrine()->getManager();

        $idiomas = $em->getRepository('borsaTreballWebBundle:Idioma')->findAll();

        return $this->render('borsaTreballWebBundle:idioma:index.html.twig', array(
            'idiomas' => $idiomas,
        ));
    }

    /**
     * Creates a new idioma entity.
     *
     */
    public function newAction(Request $request)
    {
        $idioma = new Idioma();
        $form = $this->createForm('borsaTreball\WebBundle\Form\IdiomaType', $idioma);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($idioma);
            $em->flush();

            return $this->redirectToRoute('idioma_index');
        }

        return $this->render('borsaTreballWebBundle:idioma:new.html.twig', array(
            'idioma' => $idioma,
            'form' => $form->createView(),
        ));
    }

    /**
     * Finds and displays a idioma entity.
     *
     */
    public function showAction(Idioma $idioma)
    {
        $deleteForm = $this->createDeleteForm($idioma);

        return $this->render('borsaTreballWebBundle:idioma:show.html.twig', array(
            'idioma' => $idioma,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing idioma entity.
     *
     */
    public function editAction(Request $request, Idioma $idioma)
    {
        $deleteForm = $this->createDeleteForm($idioma);
        $editForm = $this->createForm('borsaTreball\WebBundle\Form\IdiomaType', $idioma);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('idioma_edit', array('ididioma' => $idioma->getIdidioma()));
        }

        return $this->render('borsaTreballWebBundle:idioma:edit.html.twig', array(
            'idioma' => $idioma,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Deletes a idioma entity.
     *
     */
    public function deleteAction(Request $request, Idioma $idioma)
    {
        $form = $this->createDeleteForm($idioma);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($idioma);
            $em->flush();
        }

        return $this->redirectToRoute('idioma_index');
    }

    /**
     * Creates a form to delete a idioma entity.
     *
     * @param Idioma $idioma The idioma entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Idioma $idioma)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('idioma_delete', array('ididioma' => $idioma->getIdidioma())))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
}
