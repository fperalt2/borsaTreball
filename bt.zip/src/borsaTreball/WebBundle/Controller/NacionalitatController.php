<?php

namespace borsaTreball\WebBundle\Controller;

use borsaTreball\WebBundle\Entity\Nacionalitat;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
/**
 * Nacionalitat controller.
 *
 */
class NacionalitatController extends Controller
{
    /**
     * Lists all nacionalitat entities.
     *
     */
    public function indexAction()
    {
        $this->denyAccessUnlessGranted(['ROLE_1','ROLE_2','ROLE_3']);
        $em = $this->getDoctrine()->getManager();

        $nacionalitats = $em->getRepository('borsaTreballWebBundle:Nacionalitat')->findAll();

        return $this->render('borsaTreballWebBundle:nacionalitat:index.html.twig', array(
            'nacionalitats' => $nacionalitats,
        ));
    }

    /**
     * Creates a new nacionalitat entity.
     *
     */
    public function newAction(Request $request)
    {
        $nacionalitat = new Nacionalitat();
        $form = $this->createForm('borsaTreball\WebBundle\Form\NacionalitatType', $nacionalitat);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($nacionalitat);
            $em->flush();

            return $this->redirectToRoute('nacionalitat_index');
        }

        return $this->render('borsaTreballWebBundle:nacionalitat:new.html.twig', array(
            'nacionalitat' => $nacionalitat,
            'form' => $form->createView(),
        ));
    }

    /**
     * Finds and displays a nacionalitat entity.
     *
     */
    public function showAction(Nacionalitat $nacionalitat)
    {
        $deleteForm = $this->createDeleteForm($nacionalitat);

        return $this->render('borsaTreballWebBundle:nacionalitat:show.html.twig', array(
            'nacionalitat' => $nacionalitat,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing nacionalitat entity.
     *
     */
    public function editAction(Request $request, Nacionalitat $nacionalitat)
    {
        $deleteForm = $this->createDeleteForm($nacionalitat);
        $editForm = $this->createForm('borsaTreball\WebBundle\Form\NacionalitatType', $nacionalitat);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('nacionalitat_edit', array('idnacionalitat' => $nacionalitat->getIdnacionalitat()));
        }

        return $this->render('borsaTreballWebBundle:nacionalitat:edit.html.twig', array(
            'nacionalitat' => $nacionalitat,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Deletes a nacionalitat entity.
     *
     */
    public function deleteAction(Request $request, Nacionalitat $nacionalitat)
    {
        $form = $this->createDeleteForm($nacionalitat);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($nacionalitat);
            $em->flush();
        }

        return $this->redirectToRoute('nacionalitat_index');
    }

    /**
     * Creates a form to delete a nacionalitat entity.
     *
     * @param Nacionalitat $nacionalitat The nacionalitat entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Nacionalitat $nacionalitat)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('nacionalitat_delete', array('idnacionalitat' => $nacionalitat->getIdnacionalitat())))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
}
