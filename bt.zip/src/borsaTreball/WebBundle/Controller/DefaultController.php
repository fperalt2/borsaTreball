<?php

namespace borsaTreball\WebBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use borsaTreball\WebBundle\Entity\Email;
use borsaTreball\WebBundle\Entity\Oferta;
use borsaTreball\WebBundle\Entity\Estatoferta;
use borsaTreball\WebBundle\Entity\Estatofertaalumne;
use borsaTreball\WebBundle\Entity\Empresa;
use borsaTreball\WebBundle\Entity\Cicle;
use borsaTreball\WebBundle\Entity\Alumne;
use borsaTreball\WebBundle\Entity\Ofertaetiqueta;
use borsaTreball\WebBundle\Entity\Ofertacicle;
use borsaTreball\WebBundle\Entity\Ofertaalumne;
use borsaTreball\WebBundle\Entity\EmpresaUsuari;
use borsaTreball\WebBundle\Entity\Usuari;
use borsaTreball\WebBundle\Entity\TipusUsuari;
use borsaTreball\WebBundle\Entity\AlumneUsuari;
use borsaTreball\WebBundle\Entity\Estudisalumne;
use borsaTreball\WebBundle\Entity\Estudi;
use borsaTreball\WebBundle\Entity\Professor;
use borsaTreball\WebBundle\Entity\ProfessorUsuari;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use borsaTreball\WebBundle\Utils\fpdf\FitxaPDF;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use ZipArchive;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;

class DefaultController extends Controller {

    public function indexBaseAction() {
        $token = $this->get('security.token_storage')->getToken();
        $user = $token->getUser();
        if($user != "anon."){
            return $this->redirectToRoute('borsa_treball_web_home');
        }
        return $this->render('default/index.html.twig');
    }

    public function aboutUsAction() {
        $token = $this->get('security.token_storage')->getToken();
        $user = $token->getUser();
        if($user != "anon."){
            return $this->redirectToRoute('borsa_treball_web_home');
        }

        return $this->render('default/index_nosaltres.html.twig');

    }




    public function indexAction() {
        $token = $this->get('security.token_storage')->getToken();
        $user = $token->getUser();
        $em = $this->getDoctrine()->getManager();


        $userId = $user->getIdtipususuari()->getIdtipususuari();
        $usuari = $user->getNomusuari();
        //$usuari = 'FP';
        switch ($userId) {
            case 1:
                $tipus = "Admin";
                $a = $em->getRepository('borsaTreballWebBundle:Alumne')->findAll();
                $cont1 = 0;
                foreach ($a as $value) {
                    $cont1++;
                }
                $nAlumnes = $cont1;
                $e = $em->getRepository('borsaTreballWebBundle:Empresa')->findAll();
                $cont1 = 0;
                foreach ($e as $value) {
                    $cont1++;
                }
                $nEmpreses = $cont1;
                $o = $em->getRepository('borsaTreballWebBundle:Oferta')->findAll();
                $cont1 = 0;
                foreach ($o as $value) {
                    $cont1++;
                }
                $nOfertes = $cont1;
                $t1 = $em->getRepository('borsaTreballWebBundle:Oferta')->findBy(['idestatoferta' => 1]);
                $cont1 = 0;
                foreach ($t1 as $value) {
                    $cont1++;
                }
                $cont2 = 0;
                $t2 = $em->getRepository('borsaTreballWebBundle:Alumne')->findBy(['validat' => 0]);
                foreach ($t2 as $value) {
                    $cont2++;
                }
                $cont3 = 0;
                $t3 = $em->getRepository('borsaTreballWebBundle:Empresa')->findBy(['validada' => 0]);
                foreach ($t3 as $value) {
                    $cont3++;
                }

                $nTascas = $cont1 + $cont2 + $cont3;
                $t1 = $em->getRepository('borsaTreballWebBundle:Ofertaalumne')->findBy(['idestatofertaalumne' => 2]);
                $contDAW = 0;
                $contDAM = 0;
                $contASIX = 0;
                $contSMX = 0;
                $contGAD = 0;
                $contADFI = 0;
                $contACO = 0;
                $contGVEC = 0;
                $contCINT = 0;
                $contTIL = 0;

                foreach ($t1 as $value) {
                    $sigles = $value->getidalumne()->getidcicle()->getsigles();
                    switch ($sigles) {
                        case "DAW":
                            $contDAW++;
                            break;
                        case "DAM":
                            $contDAM++;
                            break;
                        case "ASIX":
                            $contASIX++;
                            break;
                        case "SMX":
                            $contSMX++;
                            break;
                        case "GAD":
                            $contGAD++;
                            break;
                        case "ADFI":
                            $contADFI++;
                            break;
                        case "ACO":
                            $contACO++;
                            break;
                        case "GVEC":
                            $contGVEC++;
                            break;
                        case "CINT":
                            $contCINT++;
                            break;
                        case "TIL":
                            $contTIL++;
                            break;
                    }
                }
                $ofertes = $em->getRepository('borsaTreballWebBundle:Oferta')->findAll();
                $ofertes = array_reverse($ofertes);

                return $this->render('borsaTreballWebBundle:Default:home_admin.html.twig', array(
                    'tipus' => $tipus,
                    'usuari' => $usuari,
                    'nAlumnes' => $nAlumnes,
                    'nEmpreses' => $nEmpreses,
                    'nOfertes' => $nOfertes,
                    'nTascas' => $nTascas,
                    'nDAW' => $contDAW,
                    'nDAM' => $contDAM,
                    'nASIX' => $contASIX,
                    'nSMX' => $contSMX,
                    'nGAD' => $contGAD,
                    'nADFI' => $contADFI,
                    'nACO' => $contACO,
                    'nGVEC' => $contGVEC,
                    'nCINT' => $contCINT,
                    'nTIL' => $contTIL,
                    'ofertes' => $ofertes,
                ));
                break;
            case 2:
                $tipus = "Professor";
                $a = $em->getRepository('borsaTreballWebBundle:Alumne')->findAll();
                $cont1 = 0;
                foreach ($a as $value) {
                    $cont1++;
                }
                $nAlumnes = $cont1;
                $e = $em->getRepository('borsaTreballWebBundle:Empresa')->findAll();
                $cont1 = 0;
                foreach ($e as $value) {
                    $cont1++;
                }
                $nEmpreses = $cont1;
                $o = $em->getRepository('borsaTreballWebBundle:Oferta')->findAll();
                $cont1 = 0;
                foreach ($o as $value) {
                    $cont1++;
                }
                $nOfertes = $cont1;
                $t1 = $em->getRepository('borsaTreballWebBundle:Oferta')->findBy(['idestatoferta' => 1]);
                $cont1 = 0;
                foreach ($t1 as $value) {
                    $cont1++;
                }

                $cont2 = 0;
                $t2 = $em->getRepository('borsaTreballWebBundle:Alumne')->findBy(['validat' => 0]);
                foreach ($t2 as $value) {
                    $cont2++;
                }
                $cont3 = 0;
                $t3 = $em->getRepository('borsaTreballWebBundle:Empresa')->findBy(['validada' => 0]);
                foreach ($t3 as $value) {
                    $cont3++;
                }

                $nTascas = $cont1 +$cont2 +$cont3;
                $t1 = $em->getRepository('borsaTreballWebBundle:Ofertaalumne')->findBy(['idestatofertaalumne' => 2]);
                $contDAW = 0;
                $contDAM = 0;
                $contASIX = 0;
                $contSMX = 0;
                $contGAD = 0;
                $contADFI = 0;
                $contACO = 0;
                $contGVEC = 0;
                $contCINT = 0;
                $contTIL = 0;

                foreach ($t1 as $value) {
                    $sigles = $value->getidalumne()->getidcicle()->getsigles();
                    switch ($sigles) {
                        case "DAW":
                            $contDAW++;
                            break;
                        case "DAM":
                            $contDAM++;
                            break;
                        case "ASIX":
                            $contASIX++;
                            break;
                        case "SMX":
                            $contSMX++;
                            break;
                        case "GAD":
                            $contGAD++;
                            break;
                        case "ADFI":
                            $contADFI++;
                            break;
                        case "ACO":
                            $contACO++;
                            break;
                        case "GVEC":
                            $contGVEC++;
                            break;
                        case "CINT":
                            $contCINT++;
                            break;
                        case "TIL":
                            $contTIL++;
                            break;
                    }
                }
                $ofertes = $em->getRepository('borsaTreballWebBundle:Oferta')->findAll();
                $ofertes = array_reverse($ofertes);

                return $this->render('borsaTreballWebBundle:Default:home_admin.html.twig', array(
                    'tipus' => $tipus,
                    'usuari' => $usuari,
                    'nAlumnes' => $nAlumnes,
                    'nEmpreses' => $nEmpreses,
                    'nOfertes' => $nOfertes,
                    'nTascas' => $nTascas,
                    'nDAW' => $contDAW,
                    'nDAM' => $contDAM,
                    'nASIX' => $contASIX,
                    'nSMX' => $contSMX,
                    'nGAD' => $contGAD,
                    'nADFI' => $contADFI,
                    'nACO' => $contACO,
                    'nGVEC' => $contGVEC,
                    'nCINT' => $contCINT,
                    'nTIL' => $contTIL,
                    'ofertes' => $ofertes,
                ));
                break;
            case 3:
                $tipus = "Coordinador";
                $a = $em->getRepository('borsaTreballWebBundle:Alumne')->findAll();
                $cont1 = 0;
                foreach ($a as $value) {
                    $cont1++;
                }
                $nAlumnes = $cont1;
                $e = $em->getRepository('borsaTreballWebBundle:Empresa')->findAll();
                $cont1 = 0;
                foreach ($e as $value) {
                    $cont1++;
                }
                $nEmpreses = $cont1;
                $o = $em->getRepository('borsaTreballWebBundle:Oferta')->findAll();
                $cont1 = 0;
                foreach ($o as $value) {
                    $cont1++;
                }
                $nOfertes = $cont1;
                $t1 = $em->getRepository('borsaTreballWebBundle:Oferta')->findBy(['idestatoferta' => 1]);
                $cont1 = 0;
                foreach ($t1 as $value) {
                    $cont1++;
                }

                $cont2 = 0;
                $t2 = $em->getRepository('borsaTreballWebBundle:Alumne')->findBy(['validat' => 0]);
                foreach ($t2 as $value) {
                    $cont2++;
                }
                $cont3 = 0;
                $t3 = $em->getRepository('borsaTreballWebBundle:Empresa')->findBy(['validada' => 0]);
                foreach ($t3 as $value) {
                    $cont3++;
                }

                $nTascas = $cont1 +$cont2 +$cont3;
                $t1 = $em->getRepository('borsaTreballWebBundle:Ofertaalumne')->findBy(['idestatofertaalumne' => 2]);
                $contDAW = 0;
                $contDAM = 0;
                $contASIX = 0;
                $contSMX = 0;
                $contGAD = 0;
                $contADFI = 0;
                $contACO = 0;
                $contGVEC = 0;
                $contCINT = 0;
                $contTIL = 0;

                foreach ($t1 as $value) {
                    $sigles = $value->getidalumne()->getidcicle()->getsigles();
                    switch ($sigles) {
                        case "DAW":
                            $contDAW++;
                            break;
                        case "DAM":
                            $contDAM++;
                            break;
                        case "ASIX":
                            $contASIX++;
                            break;
                        case "SMX":
                            $contSMX++;
                            break;
                        case "GAD":
                            $contGAD++;
                            break;
                        case "ADFI":
                            $contADFI++;
                            break;
                        case "ACO":
                            $contACO++;
                            break;
                        case "GVEC":
                            $contGVEC++;
                            break;
                        case "CINT":
                            $contCINT++;
                            break;
                        case "TIL":
                            $contTIL++;
                            break;
                    }
                }
                $ofertes = $em->getRepository('borsaTreballWebBundle:Oferta')->findAll();
                $ofertes = array_reverse($ofertes);

                return $this->render('borsaTreballWebBundle:Default:home_admin.html.twig', array(
                    'tipus' => $tipus,
                    'usuari' => $usuari,
                    'nAlumnes' => $nAlumnes,
                    'nEmpreses' => $nEmpreses,
                    'nOfertes' => $nOfertes,
                    'nTascas' => $nTascas,
                    'nDAW' => $contDAW,
                    'nDAM' => $contDAM,
                    'nASIX' => $contASIX,
                    'nSMX' => $contSMX,
                    'nGAD' => $contGAD,
                    'nADFI' => $contADFI,
                    'nACO' => $contACO,
                    'nGVEC' => $contGVEC,
                    'nCINT' => $contCINT,
                    'nTIL' => $contTIL,
                    'ofertes' => $ofertes,
                ));
                break;
            case 4:
                $tipus = "Alumne";
                $idAlumne = $user->getIdalumne();
                $alumne = $em->getRepository('borsaTreballWebBundle:Alumne')->findBy(['idalumne' => $idAlumne]);

                $ofertes = $em->getRepository('borsaTreballWebBundle:Ofertaalumne')->findBy(['idalumne' => $idAlumne]);
                if($ofertes != null){
                    foreach($ofertes as $oferta){
                        $deleteForm = $this->createDeleteOfertaAlumneForm($oferta);
                    }

                    return $this->render('borsaTreballWebBundle:Default:home_alumne.html.twig', array(
                        'tipus' => $tipus,
                        'alumne' => $alumne[0],
                        'ofertes' => $ofertes,
                        'inscrit' => 0,
                        'delete_form' => $deleteForm->createView(),
                    ));
                } else{
                    return $this->render('borsaTreballWebBundle:Default:home_alumne.html.twig', array(
                        'tipus' => $tipus,
                        'alumne' => $alumne[0],
                        'ofertes' => $ofertes,
                        'inscrit' => 0,
                    ));
                }

                break;
            case 5:
                $tipus = "Empresa";
                $empresaId = $user->getIdempresa()->getIdempresa();

                $validada = $em->getRepository('borsaTreballWebBundle:Empresa')->find($empresaId)->getValidada();

                $ofertas = $em->getRepository('borsaTreballWebBundle:Oferta')->findBy(['idempresa' => $empresaId,'idestatoferta' => 3]);
                $cont= 0;
                foreach ($ofertas as $a) {
                    $cont++;
                }
                $ofertesNoValidades = $cont;

                $ofertas = $em->getRepository('borsaTreballWebBundle:Oferta')->findBy(['idempresa' => $empresaId,'idestatoferta' => 1]);
                $cont= 0;
                foreach ($ofertas as $a) {
                    $cont++;
                }
                $ofertesPendents = $cont;

                $ofertas = $em->getRepository('borsaTreballWebBundle:Oferta')->findBy(['idempresa' => $empresaId,'idestatoferta' => 2]);
                $cont= 0;
                $cont1= 0;
                foreach ($ofertas as $a) {
                    $ofer = $em->getRepository('borsaTreballWebBundle:Ofertaalumne')->findBy(['idoferta' => $a->getIdoferta()]);
                    foreach ($ofer as $h) {

                        $cont1++;
                    }
                    $cont++;
                }
                $ofertesValidades = $cont;
                $alumnesInscrits = $cont1;


                $o = $em->getRepository('borsaTreballWebBundle:Oferta')->findBy(['idempresa' => $empresaId, 'idestatoferta' => 2]);
                $ofertes = array_reverse($o);
                $oferta = "";
                $ofertaAlumne = "";
                $cont = 0;
                $a = array();
                foreach ($o as $s) {
                    $cont1 = 0;
                    $ofer = $em->getRepository('borsaTreballWebBundle:Ofertaalumne')->findBy(['idoferta' => $s->getIdoferta(), 'idestatofertaalumne' => 2]);
                    foreach ($ofer as $d) {
                        $cont1++;
                    }
                    $a[$cont]=$cont1;
                    $cont++;
                }

                $oferta = array_reverse($o);
                $ofertaAlumne = array_reverse($a);


                return $this->render('borsaTreballWebBundle:Default:home_empresa.html.twig', array(
                    'tipus' => $tipus,
                    'usuari' => $usuari,
                    'validada' => $validada,
                    'ofertesNoValidades' => $ofertesNoValidades,
                    'ofertesValidades' => $ofertesValidades,
                    'ofertesPendent' => $ofertesPendents,
                    'alumnesInscrits' => $alumnesInscrits,
                    'ofertes' => $ofertes,
                    'oferta' => $oferta,
                    'aluOferta' => $ofertaAlumne,

                ));
                break;
        }

        return $this->render('borsaTreballWebBundle:usuari:login.html.twig');
    }



    public function registre_alumneAction(Request $request, $tipo) {
        $token = $this->get('security.token_storage')->getToken();
        $user = $token->getUser();
        if($user != "anon."){
            return $this->redirectToRoute('borsa_treball_web_home');
        }
        $form = $this->createForm('borsaTreball\WebBundle\Form\EmailType');
        $form->handleRequest($request);
        $email = new Email();
	$host = $this->container->getParameter('mailer_host');
	$port = $this->container->getParameter('mailer_port');
	$encrypt = $this->container->getParameter('mailer_encryption');
	$mailuser = $this->container->getParameter('mailer_user');
	$mailpassword = $this->container->getParameter('mailer_password');
        $mailsender = 'noreply@iescarlesvallona.cat';
        $transport = \Swift_SmtpTransport::newInstance($host,$port,$encrypt)
	->setUsername($mailuser)
	->setPassword($mailpassword);
	//->setFrom($mailsender);

        //$transport = \Swift_SmtpTransport::newInstance('smtp.sendgrid.net',587,'tls')
          //  ->setUsername('apikey')
           // ->setPassword('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');

        $mailer = new \Swift_Mailer($transport);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();

            $correu = $form->get('email')->getData();
            //$link = "http://localhost:8080/bt/web/nou_compte_alumne?refAlum=".$correu;
            $link = "http://borsa.iescarlesvallbona.cat/nou_compte_alumne?refAlum=".$correu;
            $array_email = explode('@', $correu);
            if ($array_email[1] == 'iescarlesvallbona.cat') {
                $ne = $em->getRepository('borsaTreballWebBundle:Email')->findBy(['email' => $correu]);
                if ($ne == null) {
                    $email->setestat(1);
                    $email->setemail($correu);
                    $em->persist($email);
                    $em->flush();
                    //WEBSERVICE
                    /*
                    $data = json_encode($email);
                    $url = '172.16.9.110:50267/api/email';

                    $ch = curl_init($url);

                    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8'));
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    $result = curl_exec($ch);
                    $codi = curl_getinfo($ch,CURLINFO_HTTP_CODE);
                    curl_close($ch);
                    */

                    $message = (new \Swift_Message('Registrat!'))
                        ->setFrom('noreply@iescarlesvallbona.com')
                        ->setTo($correu)
                        ->setBody(
                        $this->renderView(
                            // app/Resources/views/Emails/registration.html.twig
                            'Email/email.html.twig',
                            array('link' => $link)
                        ),
                        'text/html'
                    );

                    $mailer->send($message);
                } else {
                    $ne = $em->getRepository('borsaTreballWebBundle:Email')->findBy(['email' => $correu]);
                    foreach($ne as $n){
                        if( $n->getEstat() == 1){
                            $email->setestat(1);
                            $email->setemail($correu);

                            $data = json_encode($email);
                            $url = '172.16.9.110:50267/api/email';

                            $ch = curl_init($url);

                            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
                            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8'));
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                            $result = curl_exec($ch);
                            $codi = curl_getinfo($ch,CURLINFO_HTTP_CODE);
                            curl_close($ch);


                            $message = (new \Swift_Message('Registrat!'))
                                ->setFrom('noreply@iescarlesvallbona.com')
                                ->setTo($correu)
                                ->setBody(
                                $this->renderView(
                                    // app/Resources/views/Emails/registration.html.twig
                                    'Email/email.html.twig',
                                    array('link' => $link)
                                ),
                                'text/html'
                            );
                            $mailer->send($message);
                        }else{
                            return $this->redirectToRoute('borsa_treball_web_registre_alumne', array('tipo' => 3));

                        }
                    }
                }
            } else {
                return $this->redirectToRoute('borsa_treball_web_registre_alumne', array('tipo' => 2));
            }
            return $this->redirectToRoute('borsa_treball_web_registre_alumne', array('tipo' => 1));
        }

        return $this->render('borsaTreballWebBundle:Default:registre_alumne.html.twig', array(
            'email' => $email,
            'form' => $form->createView(),
            'tipo' => $tipo,
        ));
    }

    /**
     * Creates a new oferta entity.
     *
     */
    public function crearOfertaAction(Request $request) {
        $token = $this->get('security.token_storage')->getToken();
        $user = $token->getUser();

        $empresaId = $user->getIdempresa()->getIdempresa();


        $em = $this->getDoctrine()->getManager();
        $oferta = new Oferta();
        $form = $this->createForm('borsaTreball\WebBundle\Form\OfertaEmpresaType', $oferta);
        $form->handleRequest($request);

        $estatOferta=new Estatoferta();
        $estatOferta = $em->getRepository('borsaTreballWebBundle:Estatoferta')->findBy(['idestatoferta' => 1]);
        $oferta->setIdestatoferta($estatOferta[0]);

        $empresa=new Empresa();
        $empresa = $em->getRepository('borsaTreballWebBundle:Empresa')->findBy(['idempresa' => $empresaId]);
        $oferta->setIdempresa($empresa[0]);

        if ($form->isSubmitted() && $form->isValid()) {


            $stringCicles=$_REQUEST["cicles"];
            $ciclesForm=explode(";",$stringCicles);

            for($i=0;$i<count($ciclesForm)-1;$i++){
                $ofertaCicle= new Ofertacicle();

                $cicle=new Cicle();
                $cicle = $em->getRepository('borsaTreballWebBundle:Cicle')->findBy(['idcicle' => $ciclesForm[$i]]);

                $ofertaCicle->setIdcicle($cicle[0]);
                $ofertaCicle->setIdoferta($oferta);

                $em->persist($ofertaCicle);
            }

            $em = $this->getDoctrine()->getManager();
            $em->persist($oferta);
            $em->flush();
            return $this->redirectToRoute('borsa_treball_web_veure_oferta', array('idoferta' => $oferta->getIdoferta()));
        }

        //        $etiquetes = $em->getRepository('borsaTreballWebBundle:Etiqueta')->findAll();
        $cicles = $em->getRepository('borsaTreballWebBundle:Cicle')->findAll();

        return $this->render('borsaTreballWebBundle:Default:crear_oferta.html.twig', array(
            'oferta' => $oferta,
            'form' => $form->createView(),
            //            'etiquetes' => $etiquetes,
            'cicles' => $cicles,
        ));
    }

    public function registre_empresaAction(Request $request) {
      $token = $this->get('security.token_storage')->getToken();
      $user = $token->getUser();
      if($user != "anon."){
          return $this->redirectToRoute('borsa_treball_web_home');
      }

      $em = $this->getDoctrine()->getManager();

      $empresa = new Empresa();

      $empresaUsuari = new EmpresaUsuari();
      // $provincia1 = $em->getRepository('borsaTreballWebBundle:Provincia')->findOneBy(['idprovincia' => 1]);
      // $poblacio1 = $em->getRepository('borsaTreballWebBundle:Poblacio')->findOneBy(['idpoblacio' => 1]);
      // $empresaUsuari->setIdprovincia($provincia1);
      // $empresaUsuari->setIdpoblacio($poblacio1);

      //$empresaUsuari->setIdprovincia($provincia);
      $usuari = new Usuari();
      $form = $this->createForm('borsaTreball\WebBundle\Form\EmpresaUsuariType', $empresaUsuari, array(
          'entity_manager' => $em,
      ));
      $form->handleRequest($request);

      // if (null !== $form['idprovincia']) {
      //     $idprovincia = $form['idprovincia']->getData();
      // } else {
      //     $idprovincia = 1;
      // }

      if ($form->isSubmitted() && $form->isValid()) {

          $empresa->setNomempresa($form['nomempresa']->getData());
          $empresa->setNifempresa($form['nifempresa']->getData());
          $empresa->setNomresponsable($form['nomresponsable']->getData());
          $empresa->setInformacioempresa($form['informacioempresa']->getData());
          $empresa->setCorreoempresa($form['correoempresa']->getData());
          $empresa->setTelefonempresa($form['telefonempresa']->getData());
          $empresa->setDireccio($form['direccio']->getData());
          $empresa->setCodipostal($form['codipostal']->getData());
          $empresa->setIdnacionalitat($form['idnacionalitat']->getData());
          $empresa->setIdpoblacio($form['idpoblacio']->getData());
          $empresa->setIdprovincia($form['idprovincia']->getData());
          $empresa->setValidada(0);
          //dump($empresa);die();
          $usuari->setNomusuari($form['nifempresa']->getData());
          $usuari->setPassword(crypt($form['password']->getData(), null));
          $tipusUsuari = $em->getRepository('borsaTreballWebBundle:Tipususuari')->findBy(['idtipususuari' => 5]);
          foreach ($tipusUsuari as $a) {
              $usuari->setIdtipususuari($a);
          }
          $usuari->setIdempresa($empresa);
          $em->persist($usuari);


          $em->persist($empresa);
          $em->flush();

          return $this->redirectToRoute('borsa_treball_web_login');
      } elseif (!$form->isSubmitted()) {
        if(isset($_POST['idprovincia'])) {
          $idprovincia = $_POST['idprovincia'];
        } else {
          $idprovincia = 1;
        }
        $provincia = $em->getRepository('borsaTreballWebBundle:Provincia')->findOneBy(['idprovincia' => $idprovincia]);
        $poblacions = $em->getRepository('borsaTreballWebBundle:Poblacio')->findBy(['idprovincia' => $provincia]);
        $form->add('idpoblacio', EntityType::class, array( 'class' => 'borsaTreballWebBundle:Poblacio','choices' => $poblacions,'choice_label' => 'nompoblacio', 'multiple' => FALSE, 'label_attr'=> array('class' => 'labelT'), 'attr' => array('class' => 'form-control') ));
      }
          /*elseif (isset($_POST['idprovincia'])) {
          $idprovincia = $_POST['idprovincia'];

          $provincia = $em->getRepository('borsaTreballWebBundle:Provincia')->findOneBy(['idprovincia' => $idprovincia]);
          $poblacions = $em->getRepository('borsaTreballWebBundle:Poblacio')->findBy(['idprovincia' => $provincia]);

          $data = json_encode($poblacions);
          $data = '[{"idpoblacio":"1","nompoblacio":"Granollers","idprovincia":"1"}]';
          // $response = new Response(
          //     'Content',
          //     Response::HTTP_OK,
          //     array('content-type' => 'application/json')
          // );
          $response = new Response();
          $response->setContent($data);
          $response->headers->set('Content-Type', 'application/json');
          $response->setStatusCode(Response::HTTP_OK);
          return $response;
      }*/

      return $this->render('borsaTreballWebBundle:Default:registre_empresa.html.twig', array(
          'form' => $form->createView(),
      ));
    }

    public function nouCompteAlumneAction(Request $request) {//
        $alumne = new Alumne();
        $alumneUsuari = new AlumneUsuari();
        $usuari = new Usuari();
        $userName = explode ('@',$_GET["refAlum"])[0];
        $alumneUsuari->setNomusuari($userName);
        $form = $this->createForm('borsaTreball\WebBundle\Form\AlumneUsuariType', $alumneUsuari);
        $form->handleRequest($request);

        $em = $this->getDoctrine()->getManager();

        if ($form->isSubmitted() && $form->isValid()) {

            $alumne->setNom($form['nom']->getData());
            $alumne->setCognoms($form['cognoms']->getData());
            $alumne->setNivellcurs($form['nivellcurs']->getData());
            $alumne->setDni($form['dni']->getData());
            $alumne->setSexe($form['sexe']->getData());
            $alumne->setIdcicle($form['idcicle']->getData());
            $alumne->setIdnacionalitat($form['idnacionalitat']->getData());
            $alumne->setDatanaixement($form['datanaixement']->getData());
            $alumne->setLlocnaixement($form['llocnaixement']->getData());
            $alumne->setDireccio($form['direccio']->getData());
            $alumne->setEmail($form['email']->getData());
            $alumne->setIdpoblacio($form['idpoblacio']->getData());
            $alumne->setIdprovincia($form['idprovincia']->getData());
            $alumne->setCodipostal($form['codipostal']->getData());
            $alumne->setTelefonfixe($form['telefonfixe']->getData());
            $alumne->setMobil($form['mobil']->getData());
            $alumne->setNumseguretatsocial($form['numseguretatsocial']->getData());
            $alumne->setCoditarjetasanitaria($form['coditarjetasanitaria']->getData());
            $alumne->setNompare($form['nompare']->getData());
            $alumne->setNommare($form['nommare']->getData());
            $alumne->setEmailpare($form['emailpare']->getData());
            $alumne->setEmailmare($form['emailmare']->getData());
            $alumne->setTelefonpare($form['telefonpare']->getData());
            $alumne->setTelefonmare($form['telefonmare']->getData());
            $alumne->setIdestudisacces($form['idestudisacces']->getData());
            $alumne->setIdnomestudiacces($form['idnomestudiacces']->getData());
            $alumne->setCentreprocedencia($form['centreprocedencia']->getData());
            $alumne->setLinkedin($form['linkedin']->getData());
            $alumne->setActiulaboral($form['actiulaboral']->getData());
            $alumne->setNomempresa($form['nomempresa']->getData());
            $alumne->setAntiguitat($form['antiguitat']->getData());
            $alumne->setCercafeina($form['cercafeina']->getData());
            $alumne->setSectorempresarial($form['sectorempresarial']->getData());
            $alumne->setCarnetconduir($form['carnetconduir']->getData());
            $alumne->setVehiclepropi($form['vehiclepropi']->getData());
            $alumne->setIntencionsfutures($form['intencionsfutures']->getData());
            $alumne->setGraduat($form['graduat']->getData());
            $alumne->setDescripcio($form['descripcio']->getData());
            $alumne->setFctdual($form['fctdual']->getData());
            $alumne->setNotificacions($form['notificacions']->getData());

            if($form['curriculum']->getData() != null){
                // Recogemos el fichero
                $file=$form['curriculum']->getData();

                // Sacamos la extensión del fichero
                $ext=$file->guessExtension();

                // Le ponemos un nombre al fichero
                $file_name=$userName.".".$ext;

                // Guardamos el fichero en el directorio uploads que estará en el directorio /web del framework
                $file->move("uploads", $file_name);

                // Establecemos el nombre de fichero en el atributo de la entidad
                $alumne->setCurriculum($file_name);

            }
            $alumne->setValidat(0);
            $usuari->setNomusuari($form['nomusuari']->getData());
            $usuari->setPassword(crypt($form['password']->getData(), null));
            $tipusUsuari = $em->getRepository('borsaTreballWebBundle:Tipususuari')->findBy(['idtipususuari' => 4]);
            foreach ($tipusUsuari as $a) {
                $usuari->setIdtipususuari($a);
            }
            $usuari->setIdalumne($alumne);


            if(isset($_GET["refAlum"])){
                $verifica = $_GET["refAlum"];
                $emailNew = new Email();
                $email = $em->getRepository('borsaTreballWebBundle:email')->findBy(['email' => $verifica]);
                $registrat =false;
                foreach ($email as $e){
                    if ($e->getEstat() == 2) {
                        $registrat = true;
                    } else {
                        $e->setEstat(2);
                        $emailNew = $e;
                        $em->persist($emailNew);

                    }

                }
                /*
                $data = json_encode($emailNew);
                $url = '172.16.9.110:50267/api/email';

                $ch = curl_init($url);

                curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
                curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8'));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $result = curl_exec($ch);
                $codi = curl_getinfo($ch,CURLINFO_HTTP_CODE);
                curl_close($ch);
                */

            }
//
            if ($registrat) {
                return $this->redirectToRoute('borsa_treball_web_login_error_registre');
            } else {
                $em->persist($usuari);
                $em->flush();
                return $this->redirectToRoute('borsa_treball_web_login_registre_correcte');
            }

        }
        //    }
        return $this->render('borsaTreballWebBundle:Default:nou_compte_alumne.html.twig', array(
            // 'alumne' => $alumne,
            //  'usuari' => $usuari,
            'email' => $email,
            'form' => $form->createView(),
            //            'formU' => $formU->createView(),
        ));
    }

    public function edit_alumneAction(Request $request) {
        $token = $this->get('security.token_storage')->getToken();
        $user = $token->getUser();
        $userId = $user->getIdalumne()->getIdalumne();
        $userName = $user->getNomusuari();
        $em = $this->getDoctrine()->getManager();
        $alumne = $em->getRepository('borsaTreballWebBundle:Alumne')->findBy(['idalumne' => $userId]);

        //$alumne->setCurriculum($professor[0]->getNomprofessor());


        $editForm = $this->createForm('borsaTreball\WebBundle\Form\AlumneType', $alumne[0]);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $file = $editForm['curriculum']->getData();
            if($file == null){
                //                $curriculumAntic=$_POST['curriculumAntic'];
                //$a = $em->getRepository('borsaTreballWebBundle:Alumne')->findBy(['idalumne' => $alumne[0]->getIdalumne()]);
                //$alumne[0]->setCurriculum($a[0]->getNom()."_".$a[0]->getCognoms().".pdf");
                //$alumne[0]->setCurriculum($userName.".pdf");
                //                var_dump($curriculumAntic);
                //                var_dump($alumne->getIdalumne());
                //                var_dump($a[0]->getCurriculum());
                //                var_dump($a[0]->getEmail());
                //                exit();
            }else{

                // Sacamos la extensión del fichero
                $ext=$file->guessExtension();

                // Le ponemos un nombre al fichero
                //$file_name=$alumne[0]->getNom()."_".$alumne[0]->getCognoms().".".$ext;
                $file_name=$userName.".".$ext;

                // Guardamos el fichero en el directorio uploads que estará en el directorio /web del framework
                $file->move("uploads", $file_name);

                // Establecemos el nombre de fichero en el atributo de la entidad
                $alumne[0]->setCurriculum($file_name);
            }


            $idCicle = $editForm['idcicle']->getData();
            $estudisAlumne = new Estudisalumne();
            $estudi =new Estudi();

            $estudi = $em->getRepository('borsaTreballWebBundle:Estudi')->findBy(['idestudi' => $idCicle]);
            $estudisAlumne->setFinalitzat(0);
            $estudisAlumne->setIdestudi($estudi[0]);
            $estudisAlumne->setIdalumne($alumne[0]);
            $cicleAlumne = $em->getRepository('borsaTreballWebBundle:Estudisalumne')->findBy(['idestudi' => $idCicle, 'idalumne'  => $userId]);
            if($cicleAlumne == null){
                $em->persist($estudisAlumne);
            }

            //return $this->redirectToRoute('alumne_show', array('idalumne' => $alumne->getIdalumne()));

            $stringCicles=$_REQUEST["cicles"];
            $ciclesForm=explode(";",$stringCicles);

            for($i=0;$i<count($ciclesForm)-1;$i++){
                $estudisAlumne= new Estudisalumne();

                $estudi=new Estudi();

                $estudi = $em->getRepository('borsaTreballWebBundle:Estudi')->findBy(['idestudi' => $ciclesForm[$i]]);

                $estudisAlumne->setFinalitzat(1);
                $estudisAlumne->setIdestudi($estudi[0]);
                $estudisAlumne->setIdalumne($alumne[0]);

                $estudiAlumne = $em->getRepository('borsaTreballWebBundle:Estudisalumne')->findBy(['idestudi' => $ciclesForm[$i], 'idalumne'  => $userId]);
                if($estudiAlumne == null){
                    $em->persist($estudisAlumne);
                }

            }
            $this->getDoctrine()->getManager()->flush();

        }

        $em = $this->getDoctrine()->getManager();
        $estudis = $em->getRepository('borsaTreballWebBundle:Estudi')->findAll();

        return $this->render('borsaTreballWebBundle:Default:edit_alumne.html.twig', array(
            'alumne' => $alumne[0],
            'edit_form' => $editForm->createView(),
            'cicles' => $estudis,
        ));
    }

    public function edit_adminAction(Request $request) {

        $token = $this->get('security.token_storage')->getToken();
        $user = $token->getUser();
        $userId = $user->getIdprofessor()->getIdprofessor();
        //echo $userId;die();
        $em = $this->getDoctrine()->getManager();
        $professor = $em->getRepository('borsaTreballWebBundle:Professor')->findBy(['idprofessor' => $userId]);
        $usuari = $em->getRepository('borsaTreballWebBundle:Usuari')->findBy(['idprofessor' => $userId]);
        $nom = $usuari[0]->getNomusuari();
        $professorU = new ProfessorUsuari();
        $professorU->setNomprofessor($professor[0]->getNomprofessor());
        $professorU->setCognomprofessor($professor[0]->getCognomprofessor());
        $professorU->setEmail($professor[0]->getEmail());
        $professorU->setLinkedin($professor[0]->getLinkedin());
        $professorU->setNomusuari($usuari[0]->getNomusuari());


        $editForm = $this->createForm('borsaTreball\WebBundle\Form\ProfessorUsuariType', $professorU);
        //echo $professorU->getEmail();die();

        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $professor[0]->setNomprofessor($editForm['nomprofessor']->getData());
            $professor[0]->setCognomprofessor($editForm['cognomprofessor']->getData());
            $professor[0]->setEmail($editForm['email']->getData());
            $professor[0]->setLinkedin($editForm['linkedin']->getData());

            $usuari[0]->setNomusuari($editForm['nomusuari']->getData());
            $usuari[0]->setPassword(crypt($editForm['password']->getData(), null));

            $em->persist($professor[0]);
            $em->persist($usuari[0]);
            $em->flush();

            return $this->redirectToRoute('borsa_treball_web_home');
        }

        return $this->render('borsaTreballWebBundle:Default:edit_admin.html.twig', array(
            'admin' => $professor[0],
            'edit_form' => $editForm->createView(),
            //'cicles' => $estudis,
        ));
    }

    public function edit_empresaAction(Request $request) {

        $token = $this->get('security.token_storage')->getToken();
        $user = $token->getUser();
        $userId = $user->getIdempresa()->getIdempresa();
        //echo $userId;die();
        $em = $this->getDoctrine()->getManager();
        $empresa = $em->getRepository('borsaTreballWebBundle:Empresa')->findBy(['idempresa' => $userId]);
        $usuari = $em->getRepository('borsaTreballWebBundle:Usuari')->findBy(['idempresa' => $userId]);
        $nom = $usuari[0]->getNomusuari();
        $empresaU = new EmpresaUsuari();
        $empresaU->setNomempresa($empresa[0]->getNomempresa());
        $empresaU->setNifempresa($empresa[0]->getNifempresa());
        $empresaU->setNomresponsable($empresa[0]->getNomresponsable());
        $empresaU->setInformacioempresa($empresa[0]->getInformacioempresa());
        $empresaU->setCorreoempresa($empresa[0]->getCorreoempresa());
        $empresaU->setTelefonempresa($empresa[0]->getTelefonempresa());
        $empresaU->setDireccio($empresa[0]->getDireccio());
        $empresaU->setCodipostal($empresa[0]->getCodipostal());
        $empresaU->setIdnacionalitat($empresa[0]->getIdnacionalitat());
        $empresaU->setIdpoblacio($empresa[0]->getIdpoblacio());
        $empresaU->setIdprovincia($empresa[0]->getIdprovincia());
        $empresaU->setNomusuari($usuari[0]->getNomusuari());


        $editForm = $this->createForm('borsaTreball\WebBundle\Form\EmpresaUsuariType', $empresaU, array(
            'entity_manager' => $em,
        ));
        //echo $empresaU->getEmail();die();

        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $empresa[0]->setNomempresa($editForm['nomempresa']->getData());
            $empresa[0]->setNifempresa($editForm['nifempresa']->getData());
            $empresa[0]->setNomresponsable($editForm['nomresponsable']->getData());
            $empresa[0]->setInformacioempresa($editForm['informacioempresa']->getData());
            $empresa[0]->setCorreoempresa($editForm['correoempresa']->getData());
            $empresa[0]->setTelefonempresa($editForm['telefonempresa']->getData());
            $empresa[0]->setDireccio($editForm['direccio']->getData());
            $empresa[0]->setCodipostal($editForm['codipostal']->getData());
            $empresa[0]->setIdnacionalitat($editForm['idnacionalitat']->getData());
            $empresa[0]->setIdpoblacio($editForm['idpoblacio']->getData());
            $empresa[0]->setIdprovincia($editForm['idprovincia']->getData());

            //$usuari[0]->setNomusuari($editForm['nomusuari']->getData());
            $usuari[0]->setPassword(crypt($editForm['password']->getData(), null));

            $em->persist($empresa[0]);
            $em->persist($usuari[0]);
            $em->flush();

            return $this->redirectToRoute('borsa_treball_web_home');
        }

/*        return $this->render('borsaTreballWebBundle:Default:edit_admin.html.twig', array(
            'admin' => $empresa[0],
            'edit_form' => $editForm->createView(),
        ));*/
        return $this->render('borsaTreballWebBundle:Default:edit_empresa.html.twig', array(
            'empresa' => $empresa[0],
            'edit_form' => $editForm->createView(),
        ));
    }

    public function ajaxAction(Request $request)
    {

        $em = $this->getDoctrine()->getManager();
        $nomUsuari = $em->getRepository('borsaTreballWebBundle:Usuari')->findBy(['nomusuari' => $request->request->get('username')]);
        //var_dump($nomUsuari[0]);
        if($nomUsuari[0] != null){
            $arrData = ['output' => '0'];
        }else{
            $arrData = ['output' => '1'];
        }
        return new JsonResponse($arrData);

    }

    /**
     * Creates a form to delete a oferta entity.
     *
     * @param Ofertaalumne $ofertaAlumne The oferta entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteOfertaAlumneForm(Ofertaalumne $ofertaAlumne) {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('borsa_treball_web_delete_oferta', array('idofertaalumne' => $ofertaAlumne->getIdofertaalumne())))
            ->setMethod('DELETE')
            ->getForm()
            ;
    }

    /**
     * Finds and displays a oferta entity.
     *
     */
    public function veure_ofertaAction(Oferta $oferta) {
        $deleteForm = $this->createDeleteForm($oferta);

        return $this->render('borsaTreballWebBundle:Default:veure_oferta.html.twig', array(
            'oferta' => $oferta,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * shows LOPD message.
     *
     */
    public function lopdAction(Request $request) {
        return $this->render('borsaTreballWebBundle:Default:lopd.html.twig');
    }

    /**
     * shows LOPD message.
     *
     */
    public function printAlumneAction(Request $request, $idalumne) {

        //require('../../../../fpdf/fpdf.php');
        //require_once(__DIR__.'/../../../../fpdf/fpdf.php');
        //class FPDF {};

        $pdf = new FitxaPDF();
        $pdf->AddPage();
        $pdf->SetFont('Arial','',12);
        $pdf->SetFillColor(190);

        $em = $this->getDoctrine()->getManager();
        //$idalumne = 3;
        $alumne = $em->getRepository('borsaTreballWebBundle:Alumne')->find($idalumne);
        $pdf->Cell(50,8,utf8_decode ('Curs acadèmic: '), 1, 0, 'L', true);
        $pdf->Cell(17,8,'18/19', 1);
        $pdf->Cell(40,8,utf8_decode ('Cicle: '), 1, 0, 'L', true);
        $pdf->Cell(17,8,$alumne->getIdcicle()?utf8_decode ($alumne->getIdcicle()->getSigles()):'', 1);
        $pdf->Cell(40,8,utf8_decode ('Nivell curs: '), 1, 0, 'L', true);
        $pdf->Cell(16,8,utf8_decode ($alumne->getNivellcurs()), 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Nom: '), 1, 0, 'L', true);
        $pdf->Cell(130,8,utf8_decode ($alumne->getNom()), 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Cognoms: '), 1, 0, 'L', true);
        $pdf->Cell(130,8,utf8_decode ($alumne->getCognoms()), 1, 1);
        $pdf->Cell(50,8,utf8_decode ('DNI: '), 1, 0, 'L', true);
        $pdf->Cell(40,8,utf8_decode ($alumne->getDni()), 1);
        $pdf->Cell(50,8,utf8_decode ('Sexe: '), 1, 0, 'L', true);
        $pdf->Cell(40,8,utf8_decode ($alumne->getSexe()), 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Nacionalitat: '), 1, 0, 'L', true);
        $pdf->Cell(40,8,$alumne->getIdnacionalitat()?utf8_decode ($alumne->getIdnacionalitat()->getNomnacionalitat()):'', 1);
        $pdf->Cell(50,8,utf8_decode ('Data de naixement: '), 1, 0, 'L', true);
        $pdf->Cell(40,8,$alumne->getDatanaixement()?utf8_decode ($alumne->getDatanaixement()->format('d-m-Y')):'', 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Lloc de naixement: '), 1, 0, 'L', true);
        $pdf->Cell(130,8,utf8_decode ($alumne->getLlocnaixement()), 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Adreça: '), 1, 0, 'L', true);
        $pdf->Cell(130,8,utf8_decode ($alumne->getDireccio()), 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Correu electrònic: '), 1, 0, 'L', true);
        $pdf->Cell(130,8,utf8_decode ($alumne->getEmail()), 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Poblacio: '), 1, 0, 'L', true);
        $pdf->Cell(130,8,$alumne->getIdpoblacio()?utf8_decode ($alumne->getIdpoblacio()->getNompoblacio()):'', 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Provincia: '), 1, 0, 'L', true);
        $pdf->Cell(40,8,$alumne->getIdprovincia()?utf8_decode ($alumne->getIdprovincia()->getNomprovincia()):'', 1);
        $pdf->Cell(50,8,utf8_decode ('Codi postal: '), 1, 0, 'L', true);
        $pdf->Cell(40,8,utf8_decode ($alumne->getCodipostal()), 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Telefon fix: '), 1, 0, 'L', true);
        $pdf->Cell(40,8,utf8_decode ($alumne->getTelefonfixe()), 1);
        $pdf->Cell(50,8,utf8_decode ('Telèfon mòbil: '), 1, 0, 'L', true);
        $pdf->Cell(40,8,utf8_decode ($alumne->getMobil()), 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Nro. seg. social: '), 1, 0, 'L', true);
        $pdf->Cell(130,8,utf8_decode ($alumne->getNumseguretatsocial()), 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Codi tar. sanitària: '), 1, 0, 'L', true);
        $pdf->Cell(130,8,utf8_decode ($alumne->getCoditarjetasanitaria()), 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Nom pare: '), 1, 0, 'L', true);
        $pdf->Cell(40,8,utf8_decode ($alumne->getNompare()), 1);
        $pdf->Cell(50,8,utf8_decode ('Telèfon pare: '), 1, 0, 'L', true);
        $pdf->Cell(40,8,utf8_decode ($alumne->getTelefonpare()), 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Email pare: '), 1, 0, 'L', true);
        $pdf->Cell(130,8,utf8_decode ($alumne->getEmailpare()), 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Nom mare: '), 1, 0, 'L', true);
        $pdf->Cell(40,8,utf8_decode ($alumne->getNommare()), 1);
        $pdf->Cell(50,8,utf8_decode ('Telèfon mare: '), 1, 0, 'L', true);
        $pdf->Cell(40,8,utf8_decode ($alumne->getTelefonmare()), 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Email mare: '), 1, 0, 'L', true);
        $pdf->Cell(130,8,utf8_decode ($alumne->getEmailmare()), 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Estudis d\'accés: '), 1, 0, 'L', true);
        $pdf->Cell(40,8,$alumne->getIdEstudisAcces()?utf8_decode ($alumne->getIdEstudisAcces()->getNomestudi()):'', 1);
        $pdf->Cell(50,8,utf8_decode ('Estudis darrer any: '), 1, 0, 'L', true);
        $pdf->Cell(40,8,$alumne->getIdnomestudiacces()?utf8_decode ($alumne->getIdnomestudiacces()->getNomestudi()):'', 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Centre d\'origen: '), 1, 0, 'L', true);
        $pdf->Cell(130,8,utf8_decode ($alumne->getCentreprocedencia()), 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Linkedin: '), 1, 0, 'L', true);
        $pdf->Cell(130,8,utf8_decode ($alumne->getLinkedin()), 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Actiu laboral: '), 1, 0, 'L', true);
        $pdf->Cell(40,8,$alumne->getActiulaboral()?utf8_decode('Sí'):'', 1);
        $pdf->Cell(50,8,utf8_decode ('Antiguitat: '), 1, 0, 'L', true);
        $pdf->Cell(40,8,utf8_decode ($alumne->getAntiguitat()), 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Nom de l\'empresa: '), 1, 0, 'L', true);
        $pdf->Cell(130,8,utf8_decode ($alumne->getNomempresa()), 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Cerca feina: '), 1, 0, 'L', true);
        $pdf->Cell(17,8,$alumne->getCercafeina()?utf8_decode('Sí'):'', 1);
        $pdf->Cell(40,8,utf8_decode ('Carnet conduir: '), 1, 0, 'L', true);
        $pdf->Cell(17,8,$alumne->getCarnetconduir()?utf8_decode('Sí'):'', 1);
        $pdf->Cell(40,8,utf8_decode ('Vehicle propi: '), 1, 0, 'L', true);
        $pdf->Cell(16,8,$alumne->getVehiclepropi()?utf8_decode('Sí'):'', 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Sector empresarial: '), 1, 0, 'L', true);
        $pdf->Cell(130,8,utf8_decode ($alumne->getSectorempresarial()), 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Intencions futures: '), 1, 0, 'L', true);
        $pdf->Cell(130,8,utf8_decode ($alumne->getIntencionsfutures()), 1, 1);
        $pdf->Cell(50,8,utf8_decode ('Graduat: '), 1, 0, 'L', true);
        $pdf->Cell(17,8,$alumne->getGraduat()?utf8_decode('Sí'):'', 1);
        $pdf->Cell(40,8,utf8_decode ('FCT/dual: '), 1, 0, 'L', true);
        $pdf->Cell(17,8,$alumne->getFctdual()?utf8_decode('Sí'):'', 1);
        $pdf->Cell(40,8,utf8_decode ('CV lliurat: '), 1, 0, 'L', true);
        $pdf->Cell(16,8,($alumne->getCurriculum() != null)?utf8_decode('Sí'):'', 1, 1);

        //$pdf->Ln();
        //$pdf->Cell(60,10,'Hecho con FPDF.',0,1,'C');
        //$pdf->Output();
        $nomDoc = utf8_decode ($alumne->getNom()).' '.utf8_decode ($alumne->getCognoms()).'.pdf';
        return new Response($pdf->Output('D', $nomDoc), 200, array('Content-Type' => 'application/pdf'));
        //echo FPDF_VERSION;
        //echo 'fet!';die();

    }

    /**
     * print group's PDFs
     *
     */
    public function printAlumnesAction(Request $request, $curs, $cicle) {

      $em = $this->getDoctrine()->getManager();

      $token = $this->get('security.token_storage')->getToken();
      $user = $token->getUser();
      $userName = $user->getNomusuari();

      $em = $this->getDoctrine()->getManager();

      //if (isset ($_GET['cicle']) && isset ($_GET['curs'])) {
      if ($curs != null && $cicle != null) {
          // $cicle = $_GET['cicle'];
          // $curs = $_GET['curs'];
          $alumnes = $em->getRepository('borsaTreballWebBundle:Alumne')->findBy(array('idcicle' => $cicle,'nivellcurs' => $curs),array('cognoms' => 'ASC'));
      } elseif (preg_match('/[0-9]/', $userName[0])) {
          $curs = $userName[0];

          // si el nom d'usuari acaba en un numero, el nom del cicle arriba fins al penultim caracter
          if (preg_match('/[0-9]/', $userName[strlen($userName)-1])) {
              $nomCicle = substr($userName, 1, strlen($userName)-2);
          } else {
              $nomCicle = substr($userName, 1, strlen($userName)-1);
          }
          //echo $curs;echo $nomCicle;die();
          $cicle = $em->getRepository('borsaTreballWebBundle:Cicle')->findOneBy(array('sigles' => $nomCicle))?$em->
            getRepository('borsaTreballWebBundle:Cicle')->findOneBy(array('sigles' => $nomCicle))->getIdcicle():-1;
          //echo $cicle;die();
          if ($cicle != -1) {
            $alumnes = $em->getRepository('borsaTreballWebBundle:Alumne')
            ->findBy(array('idcicle' => $cicle,'nivellcurs' => $curs),array('cognoms' => 'ASC'));
          } else {
            $alumnes = $em->getRepository('borsaTreballWebBundle:Alumne')->findAll();
          }

      } else {
          $cicle = -1;
          $curs = -1;
          $alumnes = $em->getRepository('borsaTreballWebBundle:Alumne')->findAll();

      };

      $cicles = $em->getRepository('borsaTreballWebBundle:Cicle')->findAll();
      $cicleUsuari = $em->getRepository('borsaTreballWebBundle:Cicle')->find($cicle);

      $cicleSigles = $cicleUsuari->getSigles();
      $zip = new ZipArchive();
      if (!file_exists('downloads/')) {
        mkdir('downloads/', 0755, true);
      }
      $filename = 'downloads/'.$curs.$cicleSigles.'.zip';
      if ($zip->open($filename, ZipArchive::OVERWRITE)!==TRUE) { {
      }
        if ($zip->open($filename, ZipArchive::CREATE)!==TRUE) {
              exit("cannot open <$filename>\n");
        }
      }

        //$idalumne = 3;
        foreach ($alumnes as $alumne) {
          $pdf = new FitxaPDF();
          $pdf->AddPage();
          $pdf->SetFont('Arial','',12);
          $pdf->SetFillColor(190);

          $pdf->Cell(50,8,utf8_decode ('Curs acadèmic: '), 1, 0, 'L', true);
          $pdf->Cell(17,8,'18/19', 1);
          $pdf->Cell(40,8,utf8_decode ('Cicle: '), 1, 0, 'L', true);
          $pdf->Cell(17,8,$alumne->getIdcicle()?utf8_decode ($alumne->getIdcicle()->getSigles()):'', 1);
          $pdf->Cell(40,8,utf8_decode ('Nivell curs: '), 1, 0, 'L', true);
          $pdf->Cell(16,8,utf8_decode ($alumne->getNivellcurs()), 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Nom: '), 1, 0, 'L', true);
          $pdf->Cell(130,8,utf8_decode ($alumne->getNom()), 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Cognoms: '), 1, 0, 'L', true);
          $pdf->Cell(130,8,utf8_decode ($alumne->getCognoms()), 1, 1);
          $pdf->Cell(50,8,utf8_decode ('DNI: '), 1, 0, 'L', true);
          $pdf->Cell(40,8,utf8_decode ($alumne->getDni()), 1);
          $pdf->Cell(50,8,utf8_decode ('Sexe: '), 1, 0, 'L', true);
          $pdf->Cell(40,8,utf8_decode ($alumne->getSexe()), 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Nacionalitat: '), 1, 0, 'L', true);
          $pdf->Cell(40,8,$alumne->getIdnacionalitat()?utf8_decode ($alumne->getIdnacionalitat()->getNomnacionalitat()):'', 1);
          $pdf->Cell(50,8,utf8_decode ('Data de naixement: '), 1, 0, 'L', true);
          $pdf->Cell(40,8,$alumne->getDatanaixement()?utf8_decode ($alumne->getDatanaixement()->format('d-m-Y')):'', 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Lloc de naixement: '), 1, 0, 'L', true);
          $pdf->Cell(130,8,utf8_decode ($alumne->getLlocnaixement()), 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Adreça: '), 1, 0, 'L', true);
          $pdf->Cell(130,8,utf8_decode ($alumne->getDireccio()), 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Correu electrònic: '), 1, 0, 'L', true);
          $pdf->Cell(130,8,utf8_decode ($alumne->getEmail()), 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Poblacio: '), 1, 0, 'L', true);
          $pdf->Cell(130,8,$alumne->getIdpoblacio()?utf8_decode ($alumne->getIdpoblacio()->getNompoblacio()):'', 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Provincia: '), 1, 0, 'L', true);
          $pdf->Cell(40,8,$alumne->getIdprovincia()?utf8_decode ($alumne->getIdprovincia()->getNomprovincia()):'', 1);
          $pdf->Cell(50,8,utf8_decode ('Codi postal: '), 1, 0, 'L', true);
          $pdf->Cell(40,8,utf8_decode ($alumne->getCodipostal()), 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Telefon fix: '), 1, 0, 'L', true);
          $pdf->Cell(40,8,utf8_decode ($alumne->getTelefonfixe()), 1);
          $pdf->Cell(50,8,utf8_decode ('Telèfon mòbil: '), 1, 0, 'L', true);
          $pdf->Cell(40,8,utf8_decode ($alumne->getMobil()), 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Nro. seg. social: '), 1, 0, 'L', true);
          $pdf->Cell(130,8,utf8_decode ($alumne->getNumseguretatsocial()), 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Codi tar. sanitària: '), 1, 0, 'L', true);
          $pdf->Cell(130,8,utf8_decode ($alumne->getCoditarjetasanitaria()), 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Nom pare: '), 1, 0, 'L', true);
          $pdf->Cell(40,8,utf8_decode ($alumne->getNompare()), 1);
          $pdf->Cell(50,8,utf8_decode ('Telèfon pare: '), 1, 0, 'L', true);
          $pdf->Cell(40,8,utf8_decode ($alumne->getTelefonpare()), 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Email pare: '), 1, 0, 'L', true);
          $pdf->Cell(130,8,utf8_decode ($alumne->getEmailpare()), 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Nom mare: '), 1, 0, 'L', true);
          $pdf->Cell(40,8,utf8_decode ($alumne->getNommare()), 1);
          $pdf->Cell(50,8,utf8_decode ('Telèfon mare: '), 1, 0, 'L', true);
          $pdf->Cell(40,8,utf8_decode ($alumne->getTelefonmare()), 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Email mare: '), 1, 0, 'L', true);
          $pdf->Cell(130,8,utf8_decode ($alumne->getEmailmare()), 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Estudis d\'accés: '), 1, 0, 'L', true);
          $pdf->Cell(40,8,$alumne->getIdEstudisAcces()?utf8_decode ($alumne->getIdEstudisAcces()->getNomestudi()):'', 1);
          $pdf->Cell(50,8,utf8_decode ('Estudis darrer any: '), 1, 0, 'L', true);
          $pdf->Cell(40,8,$alumne->getIdnomestudiacces()?utf8_decode ($alumne->getIdnomestudiacces()->getNomestudi()):'', 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Centre d\'origen: '), 1, 0, 'L', true);
          $pdf->Cell(130,8,utf8_decode ($alumne->getCentreprocedencia()), 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Linkedin: '), 1, 0, 'L', true);
          $pdf->Cell(130,8,utf8_decode ($alumne->getLinkedin()), 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Actiu laboral: '), 1, 0, 'L', true);
          $pdf->Cell(40,8,$alumne->getActiulaboral()?utf8_decode('Sí'):'', 1);
          $pdf->Cell(50,8,utf8_decode ('Antiguitat: '), 1, 0, 'L', true);
          $pdf->Cell(40,8,utf8_decode ($alumne->getAntiguitat()), 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Nom de l\'empresa: '), 1, 0, 'L', true);
          $pdf->Cell(130,8,utf8_decode ($alumne->getNomempresa()), 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Cerca feina: '), 1, 0, 'L', true);
          $pdf->Cell(17,8,$alumne->getCercafeina()?utf8_decode('Sí'):'', 1);
          $pdf->Cell(40,8,utf8_decode ('Carnet conduir: '), 1, 0, 'L', true);
          $pdf->Cell(17,8,$alumne->getCarnetconduir()?utf8_decode('Sí'):'', 1);
          $pdf->Cell(40,8,utf8_decode ('Vehicle propi: '), 1, 0, 'L', true);
          $pdf->Cell(16,8,$alumne->getVehiclepropi()?utf8_decode('Sí'):'', 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Sector empresarial: '), 1, 0, 'L', true);
          $pdf->Cell(130,8,utf8_decode ($alumne->getSectorempresarial()), 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Intencions futures: '), 1, 0, 'L', true);
          $pdf->Cell(130,8,utf8_decode ($alumne->getIntencionsfutures()), 1, 1);
          $pdf->Cell(50,8,utf8_decode ('Graduat: '), 1, 0, 'L', true);
          $pdf->Cell(17,8,$alumne->getGraduat()?utf8_decode('Sí'):'', 1);
          $pdf->Cell(40,8,utf8_decode ('FCT/dual: '), 1, 0, 'L', true);
          $pdf->Cell(17,8,$alumne->getFctdual()?utf8_decode('Sí'):'', 1);
          $pdf->Cell(40,8,utf8_decode ('CV lliurat: '), 1, 0, 'L', true);
          $pdf->Cell(16,8,($alumne->getCurriculum() != null)?utf8_decode('Sí'):'', 1, 1);

           $nomDoc = 'downloads/'.utf8_decode ($alumne->getNom()).' '.utf8_decode ($alumne->getCognoms())
           .'_'.utf8_decode ($alumne->getNivellcurs()).utf8_decode ($alumne->getIdcicle()->getSigles()).'.pdf';

            $nomZip = utf8_decode ($alumne->getNom()).' '.utf8_decode ($alumne->getCognoms())
            .'_'.utf8_decode ($alumne->getNivellcurs()).utf8_decode ($alumne->getIdcicle()->getSigles()).'.pdf';

          $pdf->Output('F', $nomDoc);
          //$nomDoc = utf8_decode ($alumne->getNivellcurs()).utf8_decode ($alumne->getIdcicle()->getSigles())
          $zip->addFile($nomDoc, $nomZip);
//          return new Response($pdf->Output('F', $nomDoc), 200, array('Content-Type' => 'application/pdf'));

        }
        $zip->close();

        // $zip = new ZipArchive();
        // $filename = "./test112.zip";
        //
        // if ($zip->open($filename, ZipArchive::CREATE)!==TRUE) {
        //     exit("cannot open <$filename>\n");
        // }
        // $zip->addFile($nomDoc);
        // $zip->close();

        $response = new BinaryFileResponse($filename);
        $response->setContentDisposition(ResponseHeaderBag::DISPOSITION_ATTACHMENT,
         $curs.$cicleSigles.'.zip');
         return $response;
        // return $this->render('borsaTreballWebBundle:alumne:index.html.twig', array(
        //     'alumnes' => $alumnes,
        //     'cicles' => $cicles,
        //     'cicle' => $cicle,
        //     'curs' => $curs,
        //     //'form' => $form->createView(),
        // ));

    }

    /**
     * Finds and displays llista alumnes oferta
     *
     */
    public function llista_alumnes_ofertaAction(Oferta $oferta) {

        $em = $this->getDoctrine()->getManager();
        $alumnesOferta = $em->getRepository('borsaTreballWebBundle:Ofertaalumne')->findBy(['idoferta' => $oferta->getIdoferta(), 'idestatofertaalumne' => 2]);

        return $this->render('borsaTreballWebBundle:Default:llista_alumnes_oferta.html.twig', array(
                'alumnes' => $alumnesOferta,
        ));
    }


    /**
     * Displays a form to edit an existing oferta entity.
     *
     */
    public function editar_ofertaAction(Request $request, Oferta $oferta)
    {
        $deleteForm = $this->createDeleteForm($oferta);
        $editForm = $this->createForm('borsaTreball\WebBundle\Form\OfertaType', $oferta);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('borsa_treball_web_editar_oferta', array('idoferta' => $oferta->getIdoferta()));
        }
        $em = $this->getDoctrine()->getManager();
        $etiquetes = $em->getRepository('borsaTreballWebBundle:Etiqueta')->findAll();
        $etiquetesOferta = $em->getRepository('borsaTreballWebBundle:Ofertacicle')->findBy(['idoferta' => $oferta->getIdoferta()]);
        $ciclesOferta="";
        if($etiquetesOferta!=null){
            foreach($etiquetesOferta as $e){
                $ciclesOferta .= $e->getIdcicle()->getIdcicle().";";
            }
        }
        $cicles = $em->getRepository('borsaTreballWebBundle:Cicle')->findAll();

        return $this->render('borsaTreballWebBundle:Default:editar_oferta.html.twig', array(
            'oferta' => $oferta,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
            'etiquetes' => $etiquetes,
            'etiquetesOferta' => $ciclesOferta,
            'cicles' => $cicles,
        ));
    }

    /**
     * Deletes a oferta entity.
     *
     */
    public function deleteAction(Request $request, Oferta $oferta) {
        $form = $this->createDeleteForm($oferta);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($oferta);
            $em->flush();
        }

        return $this->redirectToRoute('oferta_index');
    }

    public function ofertaValidadaAction(Request $request) {
        $token = $this->get('security.token_storage')->getToken();
        $user = $token->getUser();
        $empresaId = $user->getIdempresa()->getIdempresa();
        $em = $this->getDoctrine()->getManager();
        $ofertas = $em->getRepository('borsaTreballWebBundle:Oferta')->findBy(['idempresa' => $empresaId,'idestatoferta' => 2]);
        return $this->render('borsaTreballWebBundle:Default:empresa_validades.html.twig', array(
            'ofertes' => $ofertas,
        ));
    }

    public function ofertaPerValidadaAction(Request $request) {
        $token = $this->get('security.token_storage')->getToken();
        $user = $token->getUser();
        $empresaId = $user->getIdempresa()->getIdempresa();
        $em = $this->getDoctrine()->getManager();
        $ofertas = $em->getRepository('borsaTreballWebBundle:Oferta')->findBy(['idempresa' => $empresaId,'idestatoferta' => 1]);
        return $this->render('borsaTreballWebBundle:Default:empresa_per_validar.html.twig', array(
            'ofertes' => $ofertas,
        ));
    }

    public function ofertaNoValidadaAction(Request $request) {
        $token = $this->get('security.token_storage')->getToken();
        $user = $token->getUser();
        $empresaId = $user->getIdempresa()->getIdempresa();
        $em = $this->getDoctrine()->getManager();
        $ofertas = $em->getRepository('borsaTreballWebBundle:Oferta')->findBy(['idempresa' => $empresaId,'idestatoferta' => 3]);
        return $this->render('borsaTreballWebBundle:Default:empresa_no_validades.html.twig', array(
            'ofertes' => $ofertas,
        ));
    }

    /**
     * Creates a form to delete a oferta entity.
     *
     * @param Oferta $oferta The oferta entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Oferta $oferta) {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('oferta_delete', array('idoferta' => $oferta->getIdoferta())))
            ->setMethod('DELETE')
            ->getForm()
            ;
    }

    public function contactAction(Request $request)
    {
        $token = $this->get('security.token_storage')->getToken();
        $user = $token->getUser();
        if($user != "anon."){
            return $this->redirectToRoute('borsa_treball_web_home');
        }

        return $this->render('default/index_contacta.html.twig');
    }





}
