<?php

namespace borsaTreball\WebBundle\Controller;

use borsaTreball\WebBundle\Entity\Empresa;
use borsaTreball\WebBundle\Entity\EmpresaUsuari;
use borsaTreball\WebBundle\Entity\Usuari;
use borsaTreball\WebBundle\Entity\TipusUsuari;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;


/**
 * Empresa controller.
 *
 */
class EmpresaController extends Controller
{
    /**
     * Lists all empresa entities.
     *
     */
    public function indexAction()
    {
        $this->denyAccessUnlessGranted(['ROLE_1','ROLE_2','ROLE_3']);

        $em = $this->getDoctrine()->getManager();

        $empresas = $em->getRepository('borsaTreballWebBundle:Empresa')->findAll();

        return $this->render('borsaTreballWebBundle:empresa:index.html.twig', array(
            'empresas' => $empresas,
        ));
    }

    /**
     * Creates a new empresa entity.
     *
     */
    public function newAction(Request $request)
    {
        $empresa = new Empresa();
        $empresaUsuari = new EmpresaUsuari();
        $usuari = new Usuari();
        $form = $this->createForm('borsaTreball\WebBundle\Form\EmpresaUsuariType', $empresaUsuari);
        $form->handleRequest($request);

        $em = $this->getDoctrine()->getManager();

        if ($form->isSubmitted() && $form->isValid()) {

            $empresa->setNomempresa($form['nomempresa']->getData());
            $empresa->setNomresponsable($form['nomresponsable']->getData());
            $empresa->setInformacioempresa($form['informacioempresa']->getData());
            $empresa->setCorreoempresa($form['correoempresa']->getData());
            $empresa->setTelefonempresa($form['telefonempresa']->getData());
            $empresa->setDireccio($form['direccio']->getData());
            $empresa->setCodipostal($form['codipostal']->getData());
            $empresa->setIdnacionalitat($form['idnacionalitat']->getData());
            $empresa->setIdpoblacio($form['idpoblacio']->getData());
            $empresa->setIdprovincia($form['idprovincia']->getData());
            $empresa->setValidada(0);

            $usuari->setNomusuari($form['nomusuari']->getData());
            $usuari->setPassword(crypt($form['password']->getData(), null));
            $tipusUsuari = $em->getRepository('borsaTreballWebBundle:Tipususuari')->findBy(['idtipususuari' => 5]);
            foreach ($tipusUsuari as $a) {
                $usuari->setIdtipususuari($a);
            }
            $usuari->setIdempresa($empresa);
            $em->persist($usuari);


            $em->persist($empresa);
            $em->flush();

            return $this->redirectToRoute('borsa_treball_web_login');
        }

        return $this->render('borsaTreballWebBundle:empresa:new.html.twig', array(
            //            'empresa' => $empresa,
            'form' => $form->createView(),
        ));
    }

    /**
     * Finds and displays a empresa entity.
     *
     */
    public function showAction(Empresa $empresa)
    {
        $deleteForm = $this->createDeleteForm($empresa);

        return $this->render('borsaTreballWebBundle:empresa:show.html.twig', array(
            'empresa' => $empresa,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing empresa entity.
     *
     */
    public function editAction(Request $request, Empresa $empresa)
    {
        $deleteForm = $this->createDeleteForm($empresa);
        $editForm = $this->createForm('borsaTreball\WebBundle\Form\EmpresaType', $empresa);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('empresa_edit', array('idempresa' => $empresa->getIdempresa()));
        }

        return $this->render('borsaTreballWebBundle:empresa:edit.html.twig', array(
            'empresa' => $empresa,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Deletes a empresa entity.
     *
     */
    public function deleteAction(Request $request, Empresa $empresa)
    {
        $form = $this->createDeleteForm($empresa);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($empresa);
            $em->flush();
        }

        return $this->redirectToRoute('empresa_index');
    }

    /**
     * Creates a form to delete a empresa entity.
     *
     * @param Empresa $empresa The empresa entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Empresa $empresa)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('empresa_delete', array('idempresa' => $empresa->getIdempresa())))
            ->setMethod('DELETE')
            ->getForm()
            ;
    }

        /**
     * Valida empresa
     *
     */
    public function validarAction(Empresa $empresa) {
        $em = $this->getDoctrine()->getManager();
        $deleteForm = $this->createDeleteForm($empresa);

        $empresa->setValidada(1);

        $this->getDoctrine()->getManager()->flush();

        $empresas = $em->getRepository('borsaTreballWebBundle:Empresa')->findAll();

        return $this->render('borsaTreballWebBundle:empresa:index.html.twig', array(
            'empresa' => $empresa,
            'empresas' => $empresas,
            'delete_form' => $deleteForm->createView(),
        ));
    }
}
