<?php

namespace borsaTreball\WebBundle\Controller;

use borsaTreball\WebBundle\Entity\Estatofertaalumne;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

/**
 * Estatofertaalumne controller.
 *
 */
class EstatofertaalumneController extends Controller
{
    /**
     * Lists all estatofertaalumne entities.
     *
     */
    public function indexAction()
    {
        $this->denyAccessUnlessGranted(['ROLE_1','ROLE_2','ROLE_3']);

        $em = $this->getDoctrine()->getManager();

        $estatofertaalumnes = $em->getRepository('borsaTreballWebBundle:Estatofertaalumne')->findAll();

        return $this->render('borsaTreballWebBundle:estatofertaalumne:index.html.twig', array(
            'estatofertaalumnes' => $estatofertaalumnes,
        ));
    }

    /**
     * Creates a new estatofertaalumne entity.
     *
     */
    public function newAction(Request $request)
    {
        $estatofertaalumne = new Estatofertaalumne();
        $form = $this->createForm('borsaTreball\WebBundle\Form\EstatofertaalumneType', $estatofertaalumne);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($estatofertaalumne);
            $em->flush();

            return $this->redirectToRoute('estatofertaalumne_index');
        }

        return $this->render('borsaTreballWebBundle:estatofertaalumne:new.html.twig', array(
            'estatofertaalumne' => $estatofertaalumne,
            'form' => $form->createView(),
        ));
    }

    /**
     * Finds and displays a estatofertaalumne entity.
     *
     */
    public function showAction(Estatofertaalumne $estatofertaalumne)
    {
        $deleteForm = $this->createDeleteForm($estatofertaalumne);

        return $this->render('borsaTreballWebBundle:estatofertaalumne:show.html.twig', array(
            'estatofertaalumne' => $estatofertaalumne,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing estatofertaalumne entity.
     *
     */
    public function editAction(Request $request, Estatofertaalumne $estatofertaalumne)
    {
        $deleteForm = $this->createDeleteForm($estatofertaalumne);
        $editForm = $this->createForm('borsaTreball\WebBundle\Form\EstatofertaalumneType', $estatofertaalumne);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('estatofertaalumne_edit', array('idestatofertaalumne' => $estatofertaalumne->getIdestatofertaalumne()));
        }

        return $this->render('borsaTreballWebBundle:estatofertaalumne:edit.html.twig', array(
            'estatofertaalumne' => $estatofertaalumne,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Deletes a estatofertaalumne entity.
     *
     */
    public function deleteAction(Request $request, Estatofertaalumne $estatofertaalumne)
    {
        $form = $this->createDeleteForm($estatofertaalumne);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($estatofertaalumne);
            $em->flush();
        }

        return $this->redirectToRoute('estatofertaalumne_index');
    }

    /**
     * Creates a form to delete a estatofertaalumne entity.
     *
     * @param Estatofertaalumne $estatofertaalumne The estatofertaalumne entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Estatofertaalumne $estatofertaalumne)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('estatofertaalumne_delete', array('idestatofertaalumne' => $estatofertaalumne->getIdestatofertaalumne())))
            ->setMethod('DELETE')
            ->getForm()
            ;
    }
}
