<?php

namespace borsaTreball\WebBundle\Controller;

use borsaTreball\WebBundle\Entity\Tipuscontracte;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
/**
 * Tipuscontracte controller.
 *
 */
class TipuscontracteController extends Controller
{
    /**
     * Lists all tipuscontracte entities.
     *
     */
    public function indexAction()
    {
        $this->denyAccessUnlessGranted(['ROLE_1','ROLE_2','ROLE_3']);
        $em = $this->getDoctrine()->getManager();

        $tipuscontractes = $em->getRepository('borsaTreballWebBundle:Tipuscontracte')->findAll();

        return $this->render('borsaTreballWebBundle:tipuscontracte:index.html.twig', array(
            'tipuscontractes' => $tipuscontractes,
        ));
    }

    /**
     * Creates a new tipuscontracte entity.
     *
     */
    public function newAction(Request $request)
    {
        $tipuscontracte = new Tipuscontracte();
        $form = $this->createForm('borsaTreball\WebBundle\Form\TipuscontracteType', $tipuscontracte);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($tipuscontracte);
            $em->flush();

            return $this->redirectToRoute('tipuscontracte_index');
        }

        return $this->render('borsaTreballWebBundle:tipuscontracte:new.html.twig', array(
            'tipuscontracte' => $tipuscontracte,
            'form' => $form->createView(),
        ));
    }

    /**
     * Finds and displays a tipuscontracte entity.
     *
     */
    public function showAction(Tipuscontracte $tipuscontracte)
    {
        $deleteForm = $this->createDeleteForm($tipuscontracte);

        return $this->render('borsaTreballWebBundle:tipuscontracte:show.html.twig', array(
            'tipuscontracte' => $tipuscontracte,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing tipuscontracte entity.
     *
     */
    public function editAction(Request $request, Tipuscontracte $tipuscontracte)
    {
        $deleteForm = $this->createDeleteForm($tipuscontracte);
        $editForm = $this->createForm('borsaTreball\WebBundle\Form\TipuscontracteType', $tipuscontracte);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('tipuscontracte_edit', array('idtipuscontracte' => $tipuscontracte->getIdtipuscontracte()));
        }

        return $this->render('borsaTreballWebBundle:tipuscontracte:edit.html.twig', array(
            'tipuscontracte' => $tipuscontracte,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Deletes a tipuscontracte entity.
     *
     */
    public function deleteAction(Request $request, Tipuscontracte $tipuscontracte)
    {
        $form = $this->createDeleteForm($tipuscontracte);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($tipuscontracte);
            $em->flush();
        }

        return $this->redirectToRoute('tipuscontracte_index');
    }

    /**
     * Creates a form to delete a tipuscontracte entity.
     *
     * @param Tipuscontracte $tipuscontracte The tipuscontracte entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Tipuscontracte $tipuscontracte)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('tipuscontracte_delete', array('idtipuscontracte' => $tipuscontracte->getIdtipuscontracte())))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
}
