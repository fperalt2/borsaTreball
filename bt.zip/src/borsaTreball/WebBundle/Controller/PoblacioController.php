<?php

namespace borsaTreball\WebBundle\Controller;

use borsaTreball\WebBundle\Entity\Poblacio;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
/**
 * Poblacio controller.
 *
 */
class PoblacioController extends Controller
{
    /**
     * Lists all poblacio entities.
     *
     */
    public function indexAction()
    {
        $this->denyAccessUnlessGranted(['ROLE_1','ROLE_2','ROLE_3']);
        $em = $this->getDoctrine()->getManager();

        $poblacios = $em->getRepository('borsaTreballWebBundle:Poblacio')->findAll();

        return $this->render('borsaTreballWebBundle:poblacio:index.html.twig', array(
            'poblacios' => $poblacios,
        ));
    }

    /**
     * Creates a new poblacio entity.
     *
     */
    public function newAction(Request $request)
    {
        $poblacio = new Poblacio();
        $form = $this->createForm('borsaTreball\WebBundle\Form\PoblacioType', $poblacio);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($poblacio);
            $em->flush();

            return $this->redirectToRoute('poblacio_index');
        }

        return $this->render('borsaTreballWebBundle:poblacio:new.html.twig', array(
            'poblacio' => $poblacio,
            'form' => $form->createView(),
        ));
    }

    /**
     * Finds and displays a poblacio entity.
     *
     */
    public function showAction(Poblacio $poblacio)
    {
        $deleteForm = $this->createDeleteForm($poblacio);

        return $this->render('borsaTreballWebBundle:poblacio:show.html.twig', array(
            'poblacio' => $poblacio,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing poblacio entity.
     *
     */
    public function editAction(Request $request, Poblacio $poblacio)
    {
        $deleteForm = $this->createDeleteForm($poblacio);
        $editForm = $this->createForm('borsaTreball\WebBundle\Form\PoblacioType', $poblacio);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('poblacio_edit', array('idpoblacio' => $poblacio->getIdpoblacio()));
        }

        return $this->render('borsaTreballWebBundle:poblacio:edit.html.twig', array(
            'poblacio' => $poblacio,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Deletes a poblacio entity.
     *
     */
    public function deleteAction(Request $request, Poblacio $poblacio)
    {
        $form = $this->createDeleteForm($poblacio);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($poblacio);
            $em->flush();
        }

        return $this->redirectToRoute('poblacio_index');
    }

    /**
     * Creates a form to delete a poblacio entity.
     *
     * @param Poblacio $poblacio The poblacio entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Poblacio $poblacio)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('poblacio_delete', array('idpoblacio' => $poblacio->getIdpoblacio())))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
}
