<?php

namespace borsaTreball\WebBundle\Controller;

use borsaTreball\WebBundle\Entity\Oferta;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use borsaTreball\WebBundle\Entity\Etiqueta;
use borsaTreball\WebBundle\Entity\Estatoferta;
use borsaTreball\WebBundle\Entity\Estatofertaalumne;
use borsaTreball\WebBundle\Entity\Empresa;
use borsaTreball\WebBundle\Entity\Cicle;
use borsaTreball\WebBundle\Entity\Alumne;
use borsaTreball\WebBundle\Entity\Ofertaetiqueta;
use borsaTreball\WebBundle\Entity\Ofertacicle;
use borsaTreball\WebBundle\Entity\Ofertaalumne;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
/**
 * Oferta controller.
 *
 */
class OfertaController extends Controller {

    /**
     * Lists all oferta entities.
     *
     */
    public function indexAction() {
        $this->denyAccessUnlessGranted(['ROLE_1','ROLE_2','ROLE_3']);
        $em = $this->getDoctrine()->getManager();

        $ofertas = $em->getRepository('borsaTreballWebBundle:Oferta')->findAll();

        return $this->render('borsaTreballWebBundle:oferta:index.html.twig', array(
            'ofertas' => $ofertas,
        ));
    }

    /**
     * Creates a new oferta entity.
     *
     */
    public function newAction(Request $request) {
        $em = $this->getDoctrine()->getManager();
        $oferta = new Oferta();
        $form = $this->createForm('borsaTreball\WebBundle\Form\OfertaType', $oferta);
        $form->handleRequest($request);

        $estatOferta=new Estatoferta();
        $estatOferta = $em->getRepository('borsaTreballWebBundle:Estatoferta')->findBy(['idestatoferta' => 2]);
        $oferta->setIdestatoferta($estatOferta[0]);

        $host = $this->container->getParameter('mailer_host');
      	$port = $this->container->getParameter('mailer_port');
        $encrypt = $this->container->getParameter('mailer_encryption');
        $mailuser = $this->container->getParameter('mailer_user');
        $mailpassword = $this->container->getParameter('mailer_password');
        $transport = \Swift_SmtpTransport::newInstance($host,$port,$encrypt)
            ->setUsername($mailuser)
          	->setPassword($mailpassword);

        // $transport = \Swift_SmtpTransport::newInstance('smtp.sendgrid.net',587,'tls')
        //     ->setUsername('apikey')
        //     ->setPassword('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');

        $mailer = new \Swift_Mailer($transport);

        if ($form->isSubmitted() && $form->isValid()) {

            //            $stringEtiquetes=$_REQUEST["etiquetes"];
            //            $etiquetesForm=explode(";",$stringEtiquetes);
            $em = $this->getDoctrine()->getManager();


            $oferta-> setIdoferta($oferta->getIdoferta());

            $em->persist($oferta);
            //            for($i=0;$i<count($etiquetesForm)-1;$i++){
            //                $ofertaEtiqueta= new Ofertaetiqueta();
            //                $etiqueta=new Etiqueta();
            //                $etiqueta=$em->getRepository('borsaTreballWebBundle:Etiqueta')->findBy(['idetiqueta' => $etiquetesForm[$i]]);
            //
            //                $ofertaEtiqueta->setIdetiqueta($etiqueta[0]);
            //                $ofertaEtiqueta->setIdoferta($oferta);
            //
            //                $em->persist($ofertaEtiqueta);
            //            }
            //$link = "http://localhost:8080/borsaTreball/web/login";
            $link = "http://borsa.iescarlesvallbona.cat/login";

            $stringCicles=$_REQUEST["cicles"];
            $ciclesForm=explode(";",$stringCicles);

            for($i=0;$i<count($ciclesForm)-1;$i++){
                $ofertaCicle= new Ofertacicle();

                $cicle=new Cicle();
                $cicle = $em->getRepository('borsaTreballWebBundle:Cicle')->findBy(['idcicle' => $ciclesForm[$i]]);
                //$alumnesCicle = $em->getRepository('borsaTreballWebBundle:Alumne')->findBy(['idcicle' => $ciclesForm[$i]]);
                $alumnesCicle = $em->getRepository('borsaTreballWebBundle:Estudisalumne')->findBy(['idestudi' => $ciclesForm[$i]]);
                if($alumnesCicle != null){
                    for($i=0;$i<count($alumnesCicle);$i++){
                        //$alumne=new Alumne();
                        $ofertaAlumne=new Ofertaalumne();
                        //$alumne = ->setIdalumne($alumnesCicle[$i]);

                        $alumne = $em->getRepository('borsaTreballWebBundle:Alumne')->findBy(['idalumne' => $alumnesCicle[$i]->getIdalumne()->getIdalumne()]);
                        $ofertaAlumne->setIdoferta($oferta);
                        $ofertaAlumne->setIdalumne($alumne[0]);

                        $estatOfertaAlumne = new Estatofertaalumne();
                        $estatOfertaAlumne = $em->getRepository('borsaTreballWebBundle:Estatofertaalumne')->findBy(['idestatofertaalumne' => 1]);
                        $ofertaAlumne->setIdestatofertaalumne($estatOfertaAlumne[0]);

                        $ofertaAlu = $em->getRepository('borsaTreballWebBundle:Ofertaalumne')->findBy(['idoferta' => $oferta->getIdoferta(), 'idalumne'  => $alumnesCicle[$i]->getIdalumne()]);
                        if($ofertaAlu == null){
                            $em->persist($ofertaAlumne);

                            $alu = $em->getRepository('borsaTreballWebBundle:Alumne')->findBy(['idalumne' => $alumnesCicle[$i]->getIdalumne()]);
                            if($alu[0]->getNotificacions()==1  && $alu[0]->getValidat()==1){
                                $message = (new \Swift_Message('Nova oferta de feina'))
                                    ->setFrom('noreply@iescarlesvallbona.com')
                                    ->setTo($alu[0]->getEmail())
                                    ->setBody(
                                    $this->renderView(
                                        // app/Resources/views/Emails/registration.html.twig
                                        'Email/email_oferta.html.twig',
                                        array('link' => $link)
                                    ),
                                    'text/html'
                                );

                                $mailer->send($message);
                            }
                        }
                    }
                }
                $ofertaCicle->setIdcicle($cicle[0]);
                $ofertaCicle->setIdoferta($oferta);

                $em->persist($ofertaCicle);
            }
            $em->flush();


            return $this->redirectToRoute('oferta_show', array('idoferta' => $oferta->getIdoferta()));
        }

        $etiquetes = $em->getRepository('borsaTreballWebBundle:Etiqueta')->findAll();
        $cicles = $em->getRepository('borsaTreballWebBundle:Cicle')->findAll();

        return $this->render('borsaTreballWebBundle:oferta:new.html.twig', array(
            'oferta' => $oferta,
            'form' => $form->createView(),
            'etiquetes' => $etiquetes,
            'cicles' => $cicles,
        ));
    }



    /**
     * Finds and displays a oferta entity.
     *
     */
    public function showAction(Oferta $oferta) {
        $deleteForm = $this->createDeleteForm($oferta);

        return $this->render('borsaTreballWebBundle:oferta:show.html.twig', array(
            'oferta' => $oferta,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing oferta entity.
     *
     */
    public function editAction(Request $request, Oferta $oferta) {
        $deleteForm = $this->createDeleteForm($oferta);
        $editForm = $this->createForm('borsaTreball\WebBundle\Form\OfertaType', $oferta);
        $editForm->handleRequest($request);

        $host = $this->container->getParameter('mailer_host');
        $port = $this->container->getParameter('mailer_port');
        $encrypt = $this->container->getParameter('mailer_encryption');
        $mailuser = $this->container->getParameter('mailer_user');
        $mailpassword = $this->container->getParameter('mailer_password');
        $transport = \Swift_SmtpTransport::newInstance($host,$port,$encrypt)
            ->setUsername($mailuser)
            ->setPassword($mailpassword);

        // $transport = \Swift_SmtpTransport::newInstance('smtp.sendgrid.net',587,'tls')
        //     ->setUsername('apikey')
        //     ->setPassword('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');

        $mailer = new \Swift_Mailer($transport);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $stringCicles=$_REQUEST["cicles"];
            $ciclesForm=explode(";",$stringCicles);
            //$link = "http://localhost:8080/borsaTreball/web/login";
            $link = "http://borsa.iescarlesvallbona.cat/login";
            $em = $this->getDoctrine()->getManager();
            for($i=0;$i<count($ciclesForm)-1;$i++){
                $ofertaCicle= new Ofertacicle();

                $cicle=new Cicle();
                $cicle = $em->getRepository('borsaTreballWebBundle:Cicle')->findBy(['idcicle' => $ciclesForm[$i]]);
                $ofertaEstat = $em->getRepository('borsaTreballWebBundle:Ofertacicle')->findBy(['idcicle' => $ciclesForm[$i], 'idoferta' => $oferta->getIdoferta()]);
                if($ofertaEstat == null){
                    //$alumnesCicle = $em->getRepository('borsaTreballWebBundle:Alumne')->findBy(['idcicle' => $ciclesForm[$i]]);
                    $alumnesCicle = $em->getRepository('borsaTreballWebBundle:Estudisalumne')->findBy(['idestudi' => $ciclesForm[$i]]);
                    if($alumnesCicle != null){
                        for($i=0;$i<count($alumnesCicle);$i++){

                            $ofertaAlu = $em->getRepository('borsaTreballWebBundle:Ofertaalumne')->findBy(['idoferta' => $oferta->getIdoferta(), 'idalumne'  => $alumnesCicle[$i]->getIdalumne()]);
                            if($ofertaAlu == null){
                                //$alumne=new Alumne();
                                $ofertaAlumne=new Ofertaalumne();
                                $alumne = $em->getRepository('borsaTreballWebBundle:Alumne')->findBy(['idalumne' => $alumnesCicle[$i]->getIdalumne()]);
                                //$alumne->setIdalumne($alumnesCicle[$i]);
                                $ofertaAlumne->setIdoferta($oferta);
                                $ofertaAlumne->setIdalumne($alumne[0]);
                                $estatOfertaAlumne = new Estatofertaalumne();
                                $estatOfertaAlumne = $em->getRepository('borsaTreballWebBundle:Estatofertaalumne')->findBy(['idestatofertaalumne' => 1]);
                                $ofertaAlumne->setIdestatofertaalumne($estatOfertaAlumne[0]);
                                $em->persist($ofertaAlumne);

                                $alu = $em->getRepository('borsaTreballWebBundle:Alumne')->findBy(['idalumne' => $alumnesCicle[$i]->getIdalumne()]);
                                if($alu != null){
                                    if($alu[0]->getNotificacions()==1   && $alu[0]->getValidat()==1){
                                        $message = (new \Swift_Message('Nova oferta de feina'))
                                            ->setFrom('noreply@iescarlesvallbona.com')
                                            ->setTo($alu[0]->getEmail())
                                            ->setBody(
                                            $this->renderView(
                                                // app/Resources/views/Emails/registration.html.twig
                                                'Email/email_oferta.html.twig',
                                                array('link' => $link)
                                            ),
                                            'text/html'
                                        );

                                        $mailer->send($message);
                                    }

                                }
                            }
                        }
                    }
                    $ofertaCicle->setIdcicle($cicle[0]);
                    $ofertaCicle->setIdoferta($oferta);

                    $em->persist($ofertaCicle);
                }
            }
            $this->getDoctrine()->getManager()->flush();
            return $this->redirectToRoute('oferta_edit', array('idoferta' => $oferta->getIdoferta()));
        }
        $em = $this->getDoctrine()->getManager();

        $etiquetes = $em->getRepository('borsaTreballWebBundle:Etiqueta')->findAll();
        $etiquetesOferta = $em->getRepository('borsaTreballWebBundle:Ofertacicle')->findBy(['idoferta' => $oferta->getIdoferta()]);
        $ciclesOferta="";
        if($etiquetesOferta!=null){
            foreach($etiquetesOferta as $e){
                $ciclesOferta .= $e->getIdcicle()->getIdcicle().";";
            }
        }
        $cicles = $em->getRepository('borsaTreballWebBundle:Cicle')->findAll();

        return $this->render('borsaTreballWebBundle:oferta:edit.html.twig', array(
            'oferta' => $oferta,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
            'etiquetes' => $etiquetes,
            'etiquetesOferta' => $ciclesOferta,
            'cicles' => $cicles,
        ));
    }

    /**
     * Valida oferta
     *
     */
    public function validarAction(Oferta $oferta) {
        $em = $this->getDoctrine()->getManager();
        $deleteForm = $this->createDeleteForm($oferta);

        $estatOferta=new Estatoferta();
        $estatOferta = $em->getRepository('borsaTreballWebBundle:Estatoferta')->findBy(['idestatoferta' => 2]);

        $oferta->setIdestatoferta($estatOferta[0]);

        $ofertaCicles = $em->getRepository('borsaTreballWebBundle:Ofertacicle')->findBy(['idoferta' => $oferta->getIdoferta()]);

        $host = $this->container->getParameter('mailer_host');
        $port = $this->container->getParameter('mailer_port');
        $encrypt = $this->container->getParameter('mailer_encryption');
        $mailuser = $this->container->getParameter('mailer_user');
        $mailpassword = $this->container->getParameter('mailer_password');
        $transport = \Swift_SmtpTransport::newInstance($host,$port,$encrypt)
            ->setUsername($mailuser)
            ->setPassword($mailpassword);

        // $transport = \Swift_SmtpTransport::newInstance('smtp.sendgrid.net',587,'tls')
        //     ->setUsername('apikey')
        //     ->setPassword('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');

        $mailer = new \Swift_Mailer($transport);

        //$link = "http://localhost:8080/borsaTreball/web/oferta/show/".$oferta->getIdoferta();
        $link = "http://borsa.iescarlesvallbona.cat/oferta/show/".$oferta->getIdoferta();

        for($i=0;$i<count($ofertaCicles);$i++){
//            var_dump("aaa");
//            var_dump($ofertaCicles[$i]->getIdofertacicle());
//            exit();
            $alumnesCicle = $em->getRepository('borsaTreballWebBundle:Estudisalumne')->findBy(['idestudi' => $ofertaCicles[$i]->getIdcicle()]);
            if($alumnesCicle != null){
                for($i=0;$i<count($alumnesCicle);$i++){
                    //$alumne=new Alumne();
                    $ofertaAlumne=new Ofertaalumne();
                    //$alumne = ->setIdalumne($alumnesCicle[$i]);

                    $alumne = $em->getRepository('borsaTreballWebBundle:Alumne')->findBy(['idalumne' => $alumnesCicle[$i]->getIdalumne()->getIdalumne()]);
                    //$alumne = $em->getRepository('borsaTreballWebBundle:Alumne')->findBy(['idalumne' => $alumnesCicle[$i]->getIdalumne()]);
                    $ofertaAlumne->setIdoferta($oferta);
                    $ofertaAlumne->setIdalumne($alumne[0]);

                    $estatOfertaAlumne = new Estatofertaalumne();
                    $estatOfertaAlumne = $em->getRepository('borsaTreballWebBundle:Estatofertaalumne')->findBy(['idestatofertaalumne' => 1]);
                    $ofertaAlumne->setIdestatofertaalumne($estatOfertaAlumne[0]);

                    $ofertaAlu = $em->getRepository('borsaTreballWebBundle:Ofertaalumne')->findBy(['idoferta' => $oferta->getIdoferta(), 'idalumne'  => $alumnesCicle[$i]->getIdalumne()]);

                    if($ofertaAlu == null){
                        $em->persist($ofertaAlumne);

                        $alu = $em->getRepository('borsaTreballWebBundle:Alumne')->findBy(['idalumne' => $alumnesCicle[$i]->getIdalumne()]);
                        if($alu[0]->getNotificacions()==1   && $alu[0]->getValidat()==1){
                            $message = (new \Swift_Message('Nova oferta de feina'))
                                ->setFrom('noreply@iescarlesvallbona.com')
                                ->setTo($alu[0]->getEmail())
                                ->setBody(
                                $this->renderView(
                                    // app/Resources/views/Emails/registration.html.twig
                                    'Email/email_oferta.html.twig',
                                    array('link' => $link)
                                ),
                                'text/html'
                            );

                            $mailer->send($message);
                        }
                    }
                }
            }

        }

        $this->getDoctrine()->getManager()->flush();

        return $this->render('borsaTreballWebBundle:oferta:show.html.twig', array(
            'oferta' => $oferta,
            'delete_form' => $deleteForm->createView(),
        ));
    }


    /**
     * Deletes a oferta entity.
     *
     */
    public function deleteAction(Request $request, Oferta $oferta) {
        $form = $this->createDeleteForm($oferta);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($oferta);
            $em->flush();
        }

        return $this->redirectToRoute('oferta_index');
    }

    /**
     * Creates a form to delete a oferta entity.
     *
     * @param Oferta $oferta The oferta entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Oferta $oferta) {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('oferta_delete', array('idoferta' => $oferta->getIdoferta())))
            ->setMethod('DELETE')
            ->getForm()
            ;
    }

    /**
     * Creates a form to delete a oferta entity.
     *
     * @param Ofertaalumne $ofertaAlumne The oferta entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteOfertaAlumneForm(Ofertaalumne $ofertaAlumne) {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('borsa_treball_web_delete_oferta', array('idofertaalumne' => $ofertaAlumne->getIdofertaalumne())))
            ->setMethod('DELETE')
            ->getForm()
            ;
    }

    /**
     * Valida oferta
     *
     */
    public function inscriureAction(Request $request, $idoferta, $inscrit) {
        //$deleteForm = $this->createDeleteForm($oferta);
        $em = $this->getDoctrine()->getManager();

        $token = $this->get('security.token_storage')->getToken();
        $user = $token->getUser();
        $idAlumne = $user->getIdalumne();

        $estatOferta=new Estatoferta();
        $estatOfertaAlumne = $em->getRepository('borsaTreballWebBundle:Estatofertaalumne')->findBy(['idestatofertaalumne' => 2]);

        $ofertaAlumne = $em->getRepository('borsaTreballWebBundle:Ofertaalumne')->findBy(['idalumne' => $idAlumne,'idoferta' => $idoferta, 'idestatofertaalumne' => 1]);

        $oferta = new Oferta();
        $oferta -> setIdoFerta($idoferta);
        $nom = $oferta->getSector();

        if($ofertaAlumne == null){
            return $this->redirectToRoute('borsa_treball_web_home', array('inscrit' => 2, 'nom' => $nom));
        }else{
            $ofertaAlumne[0]->setIdestatofertaalumne($estatOfertaAlumne[0]);
            $this->getDoctrine()->getManager()->flush();
            return $this->redirectToRoute('borsa_treball_web_home', array('inscrit' => 1, 'nom' => $nom));
        }
        return $this->render('borsaTreballWebBundle:Default:home_alumne.html.twig', array(
            'inscrit' => $inscrit,
        ));
    }

    public function noInteresaAction($idofertaalumne) {
        $em = $this->getDoctrine()->getManager();

        $token = $this->get('security.token_storage')->getToken();
        $user = $token->getUser();
        $idAlumne = $user->getIdalumne();

        $ofertaAlumne = $em->getRepository('borsaTreballWebBundle:Ofertaalumne')->findBy(['idalumne' => $idAlumne,'idoferta' => $idofertaalumne]);
        //$form = $this->createDeleteOfertaAlumneForm(($ofertaAlumne[0]));
        //        $form->handleRequest($request);

        //if ($form->isSubmitted() && $form->isValid()) {
        $em = $this->getDoctrine()->getManager();
        $em->remove($ofertaAlumne[0]);
        $em->flush();
        //}
        return $this->redirectToRoute('borsa_treball_web_home', array('inscrit' => 3));

        return $this->render('borsaTreballWebBundle:Default:home_alumne.html.twig', array(
            'inscrit' => $inscrit,
        ));
    }

}
