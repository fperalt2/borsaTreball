<?php

namespace borsaTreball\WebBundle\Controller;

use borsaTreball\WebBundle\Entity\Alumne;
use borsaTreball\WebBundle\Entity\Usuari;
use borsaTreball\WebBundle\Entity\AlumneUsuari;
use borsaTreball\WebBundle\Entity\Estudisalumne;
use borsaTreball\WebBundle\Entity\TipusUsuari;
use borsaTreball\WebBundle\Entity\Email;
use borsaTreball\WebBundle\Entity\Cicle;
use borsaTreball\WebBundle\Entity\Estudi;
use borsaTreball\WebBundle\Entity\FiltreCicle;

use borsaTreball\WebBundle\Form\Type\AlumneUsuariType;
use borsaTreball\WebBundle\Form\Type\FiltreCicleType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

/**
 * Alumne controller.
 *
 */
class AlumneController extends Controller {

    /**
     * Lists all alumne entities.
     *
     */
    public function indexAction(Request $request) {
        //$this->denyAccessUnlessGranted(['ROLE_1','ROLE_2','ROLE_3']);

        $em = $this->getDoctrine()->getManager();

        $token = $this->get('security.token_storage')->getToken();
        $user = $token->getUser();
        $userName = $user->getNomusuari();


//        return $this->render('borsaTreballWebBundle:alumne:index.html.twig', array(
//            'alumnes' => $alumnes,
//        ));


        //$filtreCicle = new FiltreCicle();
        //$form = $this->createForm('borsaTreball\WebBundle\Form\FiltreCicleType', $filtrecicle);

        $em = $this->getDoctrine()->getManager();

        if (isset ($_GET['cicle']) && isset ($_GET['curs'])) {
            $cicle = $_GET['cicle'];
            $curs = $_GET['curs'];
            $alumnes = $em->getRepository('borsaTreballWebBundle:Alumne')->findBy(array('idcicle' => $cicle,'nivellcurs' => $curs),array('cognoms' => 'ASC'));
             //$alumnes = $em->getRepository('borsaTreballWebBundle:Alumne')->findByIdcicle($cicle);
        } elseif (preg_match('/[0-9]/', $userName[0])) {
            $curs = $userName[0];

            // si el nom d'usuari acaba en un numero, el nom del cicle arriba fins al penultim caracter
            if (preg_match('/[0-9]/', $userName[strlen($userName)-1])) {
                $nomCicle = substr($userName, 1, strlen($userName)-2);
            } else {
                $nomCicle = substr($userName, 1, strlen($userName)-1);
            }
            //echo $curs;echo $nomCicle;die();
            $cicle = $em->getRepository('borsaTreballWebBundle:Cicle')->findOneBy(array('sigles' => $nomCicle))?$em->
              getRepository('borsaTreballWebBundle:Cicle')->findOneBy(array('sigles' => $nomCicle))->getIdcicle():-1;
            //echo $cicle;die();
            if ($cicle != -1) {
              $alumnes = $em->getRepository('borsaTreballWebBundle:Alumne')
              ->findBy(array('idcicle' => $cicle,'nivellcurs' => $curs),array('cognoms' => 'ASC'));
            } else {
              $alumnes = $em->getRepository('borsaTreballWebBundle:Alumne')->findAll();
            }

        } else {
            $cicle = -1;
            $curs = -1;
            $alumnes = $em->getRepository('borsaTreballWebBundle:Alumne')->findAll();

        };
        //$alumnes = $em->getRepository('borsaTreballWebBundle:Alumne')->findAll();
        $cicles = $em->getRepository('borsaTreballWebBundle:Cicle')->findAll();
        $cicleNom = $em->getRepository('borsaTreballWebBundle:Cicle')->find($cicle)?
        $em->getRepository('borsaTreballWebBundle:Cicle')->find($cicle)->getSigles():'';

        //$form->handleRequest($request);

//        if ($form->isSubmitted() && $form->isValid()) {
//
//
////            $curs = $form['nivellcurs']->getData();
////            $cicle = $form['idcicle']->getData();
//
////            $alumnes = $em->getRepository('borsaTreballWebBundle:Alumne')->findByNivellcurs($curs)->findByIdcicle($cicle);
//            $alumnes = $em->getRepository('borsaTreballWebBundle:Alumne')->findAll();
//        }
//        else {
//            $alumnes = $em->getRepository('borsaTreballWebBundle:Alumne')->findAll();
//        }

        return $this->render('borsaTreballWebBundle:alumne:index.html.twig', array(
            'alumnes' => $alumnes,
            'cicles' => $cicles,
            'cicle' => $cicle,
            'cicleNom' => $cicleNom,
            'curs' => $curs,
            //'form' => $form->createView(),
        ));

    }



    /**
     * Creates a new alumne entity.
     *
     */
    public function newAction(Request $request) {
        $alumne = new Alumne();
        $alumneUsuari = new AlumneUsuari();
        $usuari = new Usuari();
        $form = $this->createForm('borsaTreball\WebBundle\Form\AlumneUsuariType', $alumneUsuari);
        $form->handleRequest($request);

        $em = $this->getDoctrine()->getManager();

        if ($form->isSubmitted() && $form->isValid()) {

            $alumne->setNom($form['nom']->getData());
            $alumne->setCognoms($form['cognoms']->getData());
            $alumne->setNivellcurs($form['nivellcurs']->getData());
            $alumne->setDni($form['dni']->getData());
            $alumne->setSexe($form['sexe']->getData());
            $alumne->setIdcicle($form['idcicle']->getData());
            $alumne->setIdnacionalitat($form['idnacionalitat']->getData());
            $alumne->setDatanaixement($form['datanaixement']->getData());
            $alumne->setLlocnaixement($form['llocnaixement']->getData());
            $alumne->setDireccio($form['direccio']->getData());
            $alumne->setEmail($form['email']->getData());
            $alumne->setIdpoblacio($form['idpoblacio']->getData());
            $alumne->setIdprovincia($form['idprovincia']->getData());
            $alumne->setCodipostal($form['codipostal']->getData());
            $alumne->setTelefonfixe($form['telefonfixe']->getData());
            $alumne->setMobil($form['mobil']->getData());
            $alumne->setNumseguretatsocial($form['numseguretatsocial']->getData());
            $alumne->setCoditarjetasanitaria($form['coditarjetasanitaria']->getData());
            $alumne->setNompare($form['nompare']->getData());
            $alumne->setNommare($form['nommare']->getData());
            $alumne->setEmailpare($form['emailpare']->getData());
            $alumne->setEmailmare($form['emailmare']->getData());
            $alumne->setTelefonpare($form['telefonpare']->getData());
            $alumne->setTelefonmare($form['telefonmare']->getData());
            $alumne->setIdestudisacces($form['idestudisacces']->getData());
            $alumne->setIdnomestudiacces($form['idnomestudiacces']->getData());
            $alumne->setCentreprocedencia($form['centreprocedencia']->getData());
            $alumne->setLinkedin($form['linkedin']->getData());
            $alumne->setActiulaboral($form['actiulaboral']->getData());
            $alumne->setNomempresa($form['nomempresa']->getData());
            $alumne->setAntiguitat($form['antiguitat']->getData());
            $alumne->setCercafeina($form['cercafeina']->getData());
            $alumne->setSectorempresarial($form['sectorempresarial']->getData());
            $alumne->setCarnetconduir($form['carnetconduir']->getData());
            $alumne->setVehiclepropi($form['vehiclepropi']->getData());
            $alumne->setIntencionsfutures($form['intencionsfutures']->getData());
            $alumne->setGraduat($form['graduat']->getData());
            $alumne->setDescripcio($form['descripcio']->getData());
            $alumne->setFctdual($form['fctdual']->getData());
            $alumne->setNotificacions($form['notificacions']->getData());

            if($form['curriculum']->getData() != null){
                // Recogemos el fichero
                $file=$form['curriculum']->getData();

                // Sacamos la extensión del fichero
                $ext=$file->guessExtension();

                // Le ponemos un nombre al fichero
                $file_name=$alumne->getNom()."_".$alumne->getCognoms()."_".time().".".$ext;

                // Guardamos el fichero en el directorio uploads que estará en el directorio /web del framework
                $file->move("uploads", $file_name);

                // Establecemos el nombre de fichero en el atributo de la entidad
                $alumne->setCurriculum($file_name);
            }
            $alumne->setValidat(0);

            $usuari->setNomusuari($form['nomusuari']->getData());

            $usuari->setPassword(crypt($form['password']->getData(), null));
            $tipusUsuari = $em->getRepository('borsaTreballWebBundle:Tipususuari')->findBy(['idtipususuari' => 4]);
            foreach ($tipusUsuari as $a) {
                $usuari->setIdtipususuari($a);
            }
            $usuari->setIdalumne($alumne);
            $em->persist($usuari);




            if(isset($_GET["refAlum"])){
                $verifica = $_GET["refAlum"];
                $emailNew = new Email();
                $email = $em->getRepository('borsaTreballWebBundle:email')->findBy(['email' => $verifica]);
                foreach ($email as $e){
                    $e->setEstat(2);
                    $emailNew = $e;
                }
                $em->persist($emailNew);
            }



            $idCicle = $form['idcicle']->getData();
            $estudisAlumne = new Estudisalumne();
            $estudi =new Estudi();

            $estudi = $em->getRepository('borsaTreballWebBundle:Estudi')->findBy(['idestudi' => $idCicle]);
            $estudisAlumne->setFinalitzat(0);
            $estudisAlumne->setIdestudi($estudi[0]);
            $estudisAlumne->setIdalumne($alumne);
            $em->persist($estudisAlumne);

            //return $this->redirectToRoute('alumne_show', array('idalumne' => $alumne->getIdalumne()));

            $stringCicles=$_REQUEST["cicles"];
            $ciclesForm=explode(";",$stringCicles);

            for($i=0;$i<count($ciclesForm)-1;$i++){
                $estudisAlumne= new Estudisalumne();
                $estudi=new Estudi();
                $estudi = $em->getRepository('borsaTreballWebBundle:Estudi')->findBy(['idestudi' => $ciclesForm[$i]]);
                $estudisAlumne->setFinalitzat(1);
                $estudisAlumne->setIdestudi($estudi[0]);
                $estudisAlumne->setIdalumne($alumne[0]);
                $em->persist($estudisAlumne);
            }

            $em->flush();

        }
        //    }
        $estudis = $em->getRepository('borsaTreballWebBundle:Estudi')->findAll();

        return $this->render('borsaTreballWebBundle:alumne:new.html.twig', array(
            // 'alumne' => $alumne,
            //  'usuari' => $usuari,
            'form' => $form->createView(),
            'cicles' => $estudis,
            //            'formU' => $formU->createView(),
        ));
    }

    /**
     * Finds and displays a alumne entity.
     *
     */
    public function showAction(Alumne $alumne) {
        $deleteForm = $this->createDeleteForm($alumne);
        $em = $this->getDoctrine()->getManager();
        $alumneId = $alumne->getIdAlumne();
        $etiquetesAlumnes = $em->getRepository('borsaTreballWebBundle:Etiquetaalumne')->findBy(['idalumne' => $alumneId]);
        $nomEtiquetes = array();
        foreach ($etiquetesAlumnes as $e) {
            $etiquetaAlumne = $em->getRepository('borsaTreballWebBundle:Etiqueta')->findBy(['idetiqueta' => $e->getIdetiqueta()]);
            foreach ($etiquetaAlumne as $a) {
                array_push($nomEtiquetes, $a->getNometiqueta());
            }
        }

        $estudisAlumnes = $em->getRepository('borsaTreballWebBundle:Estudisalumne')->findBy(['idalumne' => $alumneId]);

        $nomEstudis = array();
        foreach ($estudisAlumnes as $e) {
            $estudiAlumne = $em->getRepository('borsaTreballWebBundle:Estudi')->findBy(['idestudi' => $e->getIdestudi()]);
            foreach ($estudiAlumne as $a) {
                array_push($nomEstudis, $a->getNomestudi());
            }
        }

        $idiomesAlumnes = $em->getRepository('borsaTreballWebBundle:Idiomaalumne')->findBy(['idalumne' => $alumneId]);
        $nomIdiomes = array();
        $nivellIdiomes = array();
        foreach ($idiomesAlumnes as $n) {
            array_push($nivellIdiomes, $n->getNivellidioma());
        }
        foreach ($idiomesAlumnes as $e) {
            $idiomaAlumne = $em->getRepository('borsaTreballWebBundle:Idioma')->findBy(['ididioma' => $e->getIdidioma()]);
            foreach ($idiomaAlumne as $a) {
                array_push($nomIdiomes, $a->getNomidioma());
            }
        }
        //$idiomes=array_merge($nomIdiomes,$nivellIdiomes);

        return $this->render('borsaTreballWebBundle:alumne:show.html.twig', array(
            'alumne' => $alumne,
            'etiquetesAlumnes' => $nomEtiquetes,
            'estudisAlumnes' => $nomEstudis,
            'nomIdiomesAlumnes' => $nomIdiomes,
            'nivellIdiomesAlumnes' => $nivellIdiomes,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing alumne entity.
     *
     */
    public function editAction(Request $request, Alumne $alumne) {
        $deleteForm = $this->createDeleteForm($alumne);
        $editForm = $this->createForm('borsaTreball\WebBundle\Form\AlumneType', $alumne);
        $editForm->handleRequest($request);
        $em = $this->getDoctrine()->getManager();
        if ($editForm->isSubmitted() && $editForm->isValid()) {
            // Recogemos el fichero
            $file=$editForm['curriculum']->getData();

            if($file == null){
//                $curriculumAntic=$_POST['curriculumAntic'];
                $a = $em->getRepository('borsaTreballWebBundle:Alumne')->findBy(['idalumne' => $alumne->getIdalumne()]);
                $alumne->setCurriculum($a[0]->getNom()."_".$a[0]->getCognoms().".pdf");
//                var_dump($curriculumAntic);
//                var_dump($alumne->getIdalumne());
//                var_dump($a[0]->getCurriculum());
//                var_dump($a[0]->getEmail());
//                exit();
            }else{

                // Sacamos la extensión del fichero
                $ext=$file->guessExtension();

                // Le ponemos un nombre al fichero
                $file_name=$alumne->getNom()."_".$alumne->getCognoms().".".$ext;

                // Guardamos el fichero en el directorio uploads que estará en el directorio /web del framework
                $file->move("uploads", $file_name);

                // Establecemos el nombre de fichero en el atributo de la entidad
                $alumne->setCurriculum($file_name);
            }
            $idCicle = $editForm['idcicle']->getData();
            $estudisAlumne = new Estudisalumne();
            $estudi =new Estudi();

            $estudi = $em->getRepository('borsaTreballWebBundle:Estudi')->findBy(['idestudi' => $idCicle]);
            $estudisAlumne->setFinalitzat(0);
            $estudisAlumne->setIdestudi($estudi[0]);
            $estudisAlumne->setIdalumne($alumne);
            $cicleAlumne = $em->getRepository('borsaTreballWebBundle:Estudisalumne')->findBy(['idestudi' => $idCicle, 'idalumne'  => $alumne->getIdalumne()]);
            if($cicleAlumne == null){
                $em->persist($estudisAlumne);
            }

            //return $this->redirectToRoute('alumne_show', array('idalumne' => $alumne->getIdalumne()));

            $stringCicles=$_REQUEST["cicles"];
            $ciclesForm=explode(";",$stringCicles);

            for($i=0;$i<count($ciclesForm)-1;$i++){
                $estudisAlumne= new Estudisalumne();

                $estudi=new Estudi();

                $estudi = $em->getRepository('borsaTreballWebBundle:Estudi')->findBy(['idestudi' => $ciclesForm[$i]]);

                $estudisAlumne->setFinalitzat(1);
                $estudisAlumne->setIdestudi($estudi[0]);
                $estudisAlumne->setIdalumne($alumne[0]);

                $estudiAlumne = $em->getRepository('borsaTreballWebBundle:Estudisalumne')->findBy(['idestudi' => $ciclesForm[$i], 'idalumne'  => $userId]);
                if($estudiAlumne == null){
                    $em->persist($estudisAlumne);
                }

            }
            $this->getDoctrine()->getManager()->flush();
        }

        $em = $this->getDoctrine()->getManager();
        $estudis = $em->getRepository('borsaTreballWebBundle:Estudi')->findAll();

        return $this->render('borsaTreballWebBundle:alumne:edit.html.twig', array(
            'alumne' => $alumne,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
            'cicles' => $estudis,
        ));
    }

    /**
     * Deletes a alumne entity.
     *
     */
    public function deleteAction(Request $request, Alumne $alumne) {
        $form = $this->createDeleteForm($alumne);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($alumne);
            $em->flush();
        }

        return $this->redirectToRoute('alumne_index');
    }

    /**
     * Creates a form to delete a alumne entity.
     *
     * @param Alumne $alumne The alumne entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Alumne $alumne) {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('alumne_delete', array('idalumne' => $alumne->getIdalumne())))
            ->setMethod('DELETE')
            ->getForm()
            ;
    }

    /**
     * Valida alumne
     *
     */
    public function validarAction(Alumne $alumne) {
        $em = $this->getDoctrine()->getManager();
        $deleteForm = $this->createDeleteForm($alumne);

        $alumne->setValidat(1);

        $this->getDoctrine()->getManager()->flush();

        return $this->render('borsaTreballWebBundle:alumne:show.html.twig', array(
            'alumne' => $alumne,
            'delete_form' => $deleteForm->createView(),
        ));
    }

}
