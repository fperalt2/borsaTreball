<?php

namespace borsaTreball\WebBundle\Controller;

use borsaTreball\WebBundle\Entity\Tipususuari;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
/**
 * Tipususuari controller.
 *
 */
class TipususuariController extends Controller
{
    /**
     * Lists all tipususuari entities.
     *
     */
    public function indexAction()
    {
        $this->denyAccessUnlessGranted(['ROLE_1','ROLE_2','ROLE_3']);
        $em = $this->getDoctrine()->getManager();

        $tipususuaris = $em->getRepository('borsaTreballWebBundle:Tipususuari')->findAll();

        return $this->render('borsaTreballWebBundle:tipususuari:index.html.twig', array(
            'tipususuaris' => $tipususuaris,
        ));
    }

    /**
     * Creates a new tipususuari entity.
     *
     */
    public function newAction(Request $request)
    {
        $tipususuari = new Tipususuari();
        $form = $this->createForm('borsaTreball\WebBundle\Form\TipususuariType', $tipususuari);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($tipususuari);
            $em->flush();

            return $this->redirectToRoute('tipususuari_index');
        }

        return $this->render('borsaTreballWebBundle:tipususuari:new.html.twig', array(
            'tipususuari' => $tipususuari,
            'form' => $form->createView(),
        ));
    }

    /**
     * Finds and displays a tipususuari entity.
     *
     */
    public function showAction(Tipususuari $tipususuari)
    {
        $deleteForm = $this->createDeleteForm($tipususuari);

        return $this->render('borsaTreballWebBundle:tipususuari:show.html.twig', array(
            'tipususuari' => $tipususuari,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing tipususuari entity.
     *
     */
    public function editAction(Request $request, Tipususuari $tipususuari)
    {
        $deleteForm = $this->createDeleteForm($tipususuari);
        $editForm = $this->createForm('borsaTreball\WebBundle\Form\TipususuariType', $tipususuari);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('tipususuari_edit', array('idtipususuari' => $tipususuari->getIdtipususuari()));
        }

        return $this->render('borsaTreballWebBundle:tipususuari:edit.html.twig', array(
            'tipususuari' => $tipususuari,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Deletes a tipususuari entity.
     *
     */
    public function deleteAction(Request $request, Tipususuari $tipususuari)
    {
        $form = $this->createDeleteForm($tipususuari);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($tipususuari);
            $em->flush();
        }

        return $this->redirectToRoute('tipususuari_index');
    }

    /**
     * Creates a form to delete a tipususuari entity.
     *
     * @param Tipususuari $tipususuari The tipususuari entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Tipususuari $tipususuari)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('tipususuari_delete', array('idtipususuari' => $tipususuari->getIdtipususuari())))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
}
