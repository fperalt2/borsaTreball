<?php

namespace borsaTreball\WebBundle\Controller;

use borsaTreball\WebBundle\Entity\Usuari;
use borsaTreball\WebBundle\Entity\Alumne;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
/**
 * Usuari controller.
 *
 */
class UsuariController extends Controller
{
    /**
     * Lists all usuari entities.
     *
     */
    public function indexAction()
    {
        $this->denyAccessUnlessGranted(['ROLE_1','ROLE_2','ROLE_3']);
        $em = $this->getDoctrine()->getManager();

        $usuaris = $em->getRepository('borsaTreballWebBundle:Usuari')->findAll();

        return $this->render('borsaTreballWebBundle:usuari:index.html.twig', array(
            'usuaris' => $usuaris,
        ));
    }

    public function  loginAction(Request $request)
    {
        $token = $this->get('security.token_storage')->getToken();
        $user = $token->getUser();
        if($user != "anon."){
            return $this->redirectToRoute('borsa_treball_web_home');
        }
        
        $authenticationUtils = $this->get('security.authentication_utils'); //mostra per pantalla si hi ha un error

        // get the login error if there is one
        $error = $authenticationUtils->getLastAuthenticationError();//recull error

        // last username entered by the user
        $lastUsername = $authenticationUtils->getLastUsername();//recull l'ultim ususername

        return $this->render('borsaTreballWebBundle:usuari:login.html.twig', array(
            'last_username' => $lastUsername,
            'error'         => $error,
        ));
    }

    
public function  loginRegistreCorrecteAction(Request $request)
    {
        $token = $this->get('security.token_storage')->getToken();
        $user = $token->getUser();
        if($user != "anon."){
            return $this->redirectToRoute('borsa_treball_web_home');
        }
        
        $authenticationUtils = $this->get('security.authentication_utils'); //mostra per pantalla si hi ha un error

        // get the login error if there is one
        $error = $authenticationUtils->getLastAuthenticationError();//recull error

        // last username entered by the user
        $lastUsername = $authenticationUtils->getLastUsername();//recull l'ultim ususername

        return $this->render('borsaTreballWebBundle:usuari:loginRegistreCorrecte.html.twig', array(
            'last_username' => $lastUsername,
            'error'         => $error,
        ));
    }
    
public function  loginErrorRegistreAction(Request $request)
    {
        $token = $this->get('security.token_storage')->getToken();
        $user = $token->getUser();
        if($user != "anon."){
            return $this->redirectToRoute('borsa_treball_web_home');
        }
        
        $authenticationUtils = $this->get('security.authentication_utils'); //mostra per pantalla si hi ha un error

        // get the login error if there is one
        $error = $authenticationUtils->getLastAuthenticationError();//recull error

        // last username entered by the user
        $lastUsername = $authenticationUtils->getLastUsername();//recull l'ultim ususername

        return $this->render('borsaTreballWebBundle:usuari:loginErrorRegistre.html.twig', array(
            'last_username' => $lastUsername,
            'error'         => $error,
        ));
    }
    
    public function loguedAction()
    {
        return $this->render('borsaTreballWebBundle:Default:index.html.twig');
    }

    public function logoutAction()
    {
        return $this->render('borsaTreballWebBundle:usuari:login.html.twig');
    }


    /**
     * Creates a new usuari entity.
     *
     */
    public function newAction(Request $request, Alumne $alumne)
    {
        $usuari = new Usuari();
        $form = $this->createForm('borsaTreball\WebBundle\Form\UsuariType', $usuari);
        $form->handleRequest($request);
        
//        $alumne = new Alumne();
//        $formA = $this->createForm('borsaTreball\WebBundle\Form\AlumneType', $alumne);
//        $formA->handleRequest($request);


        if ($form->isSubmitted() && $form->isValid()) {
            $usuari->setPassword(crypt($usuari->getPassword(), null));
            $em = $this->getDoctrine()->getManager();
//            $alu = new Alumne();
//            
//            $query = $em->createQuery(
//                'SELECT a.idalumne
//            FROM borsaTreballWebBundle:Alumne a
//            ORDER BY a.idalumne DESC'
//            );
//            
//            $alu = $query->getResult(); 
            
//            $alumne = new Alumne();
//            $alumne->setIdalumne($alu[0]['idalumne']);
//            $usuari->setIdalumne($alumne);
            //$usuari->setIdalumne($alu[0]['idalumne']);

            $em->persist($usuari);
            $em->flush();

            return $this->redirectToRoute('borsa_treball_web_login');
        }

        return $this->render('borsaTreballWebBundle:usuari:new.html.twig', array(
            'usuari' => $usuari,
            'form' => $form->createView(),
        ));
    }

    /**
     * Finds and displays a usuari entity.
     *
     */
    public function showAction(Usuari $usuari)
    {
        $deleteForm = $this->createDeleteForm($usuari);

        return $this->render('borsaTreballWebBundle:usuari:show.html.twig', array(
            'usuari' => $usuari,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing usuari entity.
     *
     */
    public function editAction(Request $request, Usuari $usuari)
    {
        $deleteForm = $this->createDeleteForm($usuari);
        $editForm = $this->createForm('borsaTreball\WebBundle\Form\UsuariType', $usuari);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $usuari->setPassword(crypt($usuari->getPassword(), null));

            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('usuari_edit', array('idusuari' => $usuari->getIdusuari()));
        }

        return $this->render('borsaTreballWebBundle:usuari:edit.html.twig', array(
            'usuari' => $usuari,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Deletes a usuari entity.
     *
     */
    public function deleteAction(Request $request, Usuari $usuari)
    {
        $form = $this->createDeleteForm($usuari);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($usuari);
            $em->flush();
        }

        return $this->redirectToRoute('usuari_index');
    }

    /**
     * Creates a form to delete a usuari entity.
     *
     * @param Usuari $usuari The usuari entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Usuari $usuari)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('usuari_delete', array('idusuari' => $usuari->getIdusuari())))
            ->setMethod('DELETE')
            ->getForm()
            ;
    }
}
