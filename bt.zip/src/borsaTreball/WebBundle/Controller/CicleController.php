<?php

namespace borsaTreball\WebBundle\Controller;

use borsaTreball\WebBundle\Entity\Cicle;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;


/**
 * Cicle controller.
 *
 */
class CicleController extends Controller
{
    /**
     * Lists all cicle entities.
     *
     */
    public function indexAction()
    {
        $this->denyAccessUnlessGranted(['ROLE_1','ROLE_2','ROLE_3']);
        $em = $this->getDoctrine()->getManager();

        $cicles = $em->getRepository('borsaTreballWebBundle:Cicle')->findAll();

        return $this->render('borsaTreballWebBundle:cicle:index.html.twig', array(
            'cicles' => $cicles,
        ));
    }

    /**
     * Creates a new cicle entity.
     *
     */
    public function newAction(Request $request)
    {
        $cicle = new Cicle();
        $form = $this->createForm('borsaTreball\WebBundle\Form\CicleType', $cicle);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($cicle);
            $em->flush();

            return $this->redirectToRoute('cicle_index');
        }

        return $this->render('borsaTreballWebBundle:cicle:new.html.twig', array(
            'cicle' => $cicle,
            'form' => $form->createView(),
        ));
    }

    /**
     * Finds and displays a cicle entity.
     *
     */
    public function showAction(Cicle $cicle)
    {
        $deleteForm = $this->createDeleteForm($cicle);

        return $this->render('borsaTreballWebBundle:cicle:show.html.twig', array(
            'cicle' => $cicle,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing cicle entity.
     *
     */
    public function editAction(Request $request, Cicle $cicle)
    {
        $deleteForm = $this->createDeleteForm($cicle);
        $editForm = $this->createForm('borsaTreball\WebBundle\Form\CicleType', $cicle);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('cicle_edit', array('idcicle' => $cicle->getIdcicle()));
        }

        return $this->render('borsaTreballWebBundle:cicle:edit.html.twig', array(
            'cicle' => $cicle,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Deletes a cicle entity.
     *
     */
    public function deleteAction(Request $request, Cicle $cicle)
    {
        $form = $this->createDeleteForm($cicle);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($cicle);
            $em->flush();
        }

        return $this->redirectToRoute('cicle_index');
    }

    /**
     * Creates a form to delete a cicle entity.
     *
     * @param Cicle $cicle The cicle entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Cicle $cicle)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('cicle_delete', array('idcicle' => $cicle->getIdcicle())))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
}
