<?php

namespace borsaTreball\WebBundle\Controller;

use borsaTreball\WebBundle\Entity\Estudiacces;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
/**
 * Estudiacce controller.
 *
 */
class EstudiaccesController extends Controller
{
    /**
     * Lists all estudiacce entities.
     *
     */
    public function indexAction()
    {
        $this->denyAccessUnlessGranted(['ROLE_1','ROLE_2','ROLE_3']);
        $em = $this->getDoctrine()->getManager();

        $estudiacces = $em->getRepository('borsaTreballWebBundle:Estudiacces')->findAll();

        return $this->render('borsaTreballWebBundle:estudiacces:index.html.twig', array(
            'estudiacces' => $estudiacces,
        ));
    }

    /**
     * Creates a new estudiacces entity.
     *
     */
    public function newAction(Request $request)
    {
        $estudiacces = new Estudiacces();
        $form = $this->createForm('borsaTreball\WebBundle\Form\EstudiaccesType', $estudiacces);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($estudiacces);
            $em->flush();

            return $this->redirectToRoute('estudiacces_index');
        }

        return $this->render('borsaTreballWebBundle:estudiacces:new.html.twig', array(
            'estudiacces' => $estudiacces,
            'form' => $form->createView(),
        ));
    }

    /**
     * Finds and displays a estudiacces entity.
     *
     */
    public function showAction(Estudiacces $estudiacces)
    {
        $deleteForm = $this->createDeleteForm($estudiacces);

        return $this->render('borsaTreballWebBundle:estudiacces:show.html.twig', array(
            'estudiacces' => $estudiacces,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing estudiacces entity.
     *
     */
    public function editAction(Request $request, Estudiacces $estudiacces)
    {
        $deleteForm = $this->createDeleteForm($estudiacces);
        $editForm = $this->createForm('borsaTreball\WebBundle\Form\EstudiaccesType', $estudiacces);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('estudiacces_edit', array('idestudiacces' => $estudiacce->getIdestudiacces()));
        }

        return $this->render('borsaTreballWebBundle:estudiacces:edit.html.twig', array(
            'estudiacces' => $estudiacces,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Deletes a estudiacces entity.
     *
     */
    public function deleteAction(Request $request, Estudiacces $estudiacces)
    {
        $form = $this->createDeleteForm($estudiacces);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($estudiacces);
            $em->flush();
        }

        return $this->redirectToRoute('estudiacces_index');
    }

    /**
     * Creates a form to delete a estudiacces entity.
     *
     * @param Estudiacces $estudiacces The estudiacces entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Estudiacces $estudiacces)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('estudiacces_delete', array('idestudiacces' => $estudiacces->getIdestudiacces())))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
}
