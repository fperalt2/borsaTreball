<?php

namespace borsaTreball\WebBundle\Controller;

use borsaTreball\WebBundle\Entity\Estudi;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
/**
 * Estudi controller.
 *
 */
class EstudiController extends Controller
{
    /**
     * Lists all estudi entities.
     *
     */
    public function indexAction()
    {
        $this->denyAccessUnlessGranted(['ROLE_1','ROLE_2','ROLE_3']);
        $em = $this->getDoctrine()->getManager();

        $estudis = $em->getRepository('borsaTreballWebBundle:Estudi')->findAll();

        return $this->render('borsaTreballWebBundle:estudi:index.html.twig', array(
            'estudis' => $estudis,
        ));
    }

    /**
     * Creates a new estudi entity.
     *
     */
    public function newAction(Request $request)
    {
        $estudi = new Estudi();
        $form = $this->createForm('borsaTreball\WebBundle\Form\EstudiType', $estudi);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($estudi);
            $em->flush();

            return $this->redirectToRoute('estudi_index');
        }

        return $this->render('borsaTreballWebBundle:estudi:new.html.twig', array(
            'estudi' => $estudi,
            'form' => $form->createView(),
        ));
    }

    /**
     * Finds and displays a estudi entity.
     *
     */
    public function showAction(Estudi $estudi)
    {
        $deleteForm = $this->createDeleteForm($estudi);

        return $this->render('borsaTreballWebBundle:estudi:show.html.twig', array(
            'estudi' => $estudi,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing estudi entity.
     *
     */
    public function editAction(Request $request, Estudi $estudi)
    {
        $deleteForm = $this->createDeleteForm($estudi);
        $editForm = $this->createForm('borsaTreball\WebBundle\Form\EstudiType', $estudi);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('estudi_edit', array('idestudi' => $estudi->getIdestudi()));
        }

        return $this->render('borsaTreballWebBundle:estudi:edit.html.twig', array(
            'estudi' => $estudi,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Deletes a estudi entity.
     *
     */
    public function deleteAction(Request $request, Estudi $estudi)
    {
        $form = $this->createDeleteForm($estudi);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($estudi);
            $em->flush();
        }

        return $this->redirectToRoute('estudi_index');
    }

    /**
     * Creates a form to delete a estudi entity.
     *
     * @param Estudi $estudi The estudi entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Estudi $estudi)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('estudi_delete', array('idestudi' => $estudi->getIdestudi())))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
}
