<?php

namespace borsaTreball\WebBundle\Controller;

use borsaTreball\WebBundle\Entity\Provincia;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
/**
 * Provincia controller.
 *
 */
class ProvinciaController extends Controller
{
    /**
     * Lists all provincia entities.
     *
     */
    public function indexAction()
    {
        $this->denyAccessUnlessGranted(['ROLE_1','ROLE_2','ROLE_3']);
        $em = $this->getDoctrine()->getManager();

        $provincias = $em->getRepository('borsaTreballWebBundle:Provincia')->findAll();

        return $this->render('borsaTreballWebBundle:provincia:index.html.twig', array(
            'provincias' => $provincias,
        ));
    }

    /**
     * Creates a new provincia entity.
     *
     */
    public function newAction(Request $request)
    {
        $provincia = new Provincia();
        $form = $this->createForm('borsaTreball\WebBundle\Form\ProvinciaType', $provincia);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($provincia);
            $em->flush();

            return $this->redirectToRoute('provincia_index');
        }

        return $this->render('borsaTreballWebBundle:provincia:new.html.twig', array(
            'provincia' => $provincia,
            'form' => $form->createView(),
        ));
    }

    /**
     * Finds and displays a provincia entity.
     *
     */
    public function showAction(Provincia $provincia)
    {
        $deleteForm = $this->createDeleteForm($provincia);

        return $this->render('borsaTreballWebBundle:provincia:show.html.twig', array(
            'provincia' => $provincia,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing provincia entity.
     *
     */
    public function editAction(Request $request, Provincia $provincia)
    {
        $deleteForm = $this->createDeleteForm($provincia);
        $editForm = $this->createForm('borsaTreball\WebBundle\Form\ProvinciaType', $provincia);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('provincia_edit', array('idprovincia' => $provincia->getIdprovincia()));
        }

        return $this->render('borsaTreballWebBundle:provincia:edit.html.twig', array(
            'provincia' => $provincia,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Deletes a provincia entity.
     *
     */
    public function deleteAction(Request $request, Provincia $provincia)
    {
        $form = $this->createDeleteForm($provincia);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($provincia);
            $em->flush();
        }

        return $this->redirectToRoute('provincia_index');
    }

    /**
     * Creates a form to delete a provincia entity.
     *
     * @param Provincia $provincia The provincia entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Provincia $provincia)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('provincia_delete', array('idprovincia' => $provincia->getIdprovincia())))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
}
