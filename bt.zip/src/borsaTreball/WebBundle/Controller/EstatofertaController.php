<?php

namespace borsaTreball\WebBundle\Controller;

use borsaTreball\WebBundle\Entity\Estatoferta;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
/**
 * Estatoferta controller.
 *
 */
class EstatofertaController extends Controller
{
    /**
     * Lists all estatoferta entities.
     *
     */
    public function indexAction()
    {
        $this->denyAccessUnlessGranted(['ROLE_1','ROLE_2','ROLE_3']);
        $em = $this->getDoctrine()->getManager();

        $estatofertas = $em->getRepository('borsaTreballWebBundle:Estatoferta')->findAll();

        return $this->render('borsaTreballWebBundle:estatoferta:index.html.twig', array(
            'estatofertas' => $estatofertas,
        ));
    }

    /**
     * Creates a new estatoferta entity.
     *
     */
    public function newAction(Request $request)
    {
        $estatoferta = new Estatoferta();
        $form = $this->createForm('borsaTreball\WebBundle\Form\EstatofertaType', $estatoferta);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($estatoferta);
            $em->flush();

            return $this->redirectToRoute('estatoferta_index');
        }

        return $this->render('borsaTreballWebBundle:estatoferta:new.html.twig', array(
            'estatoferta' => $estatoferta,
            'form' => $form->createView(),
        ));
    }

    /**
     * Finds and displays a estatoferta entity.
     *
     */
    public function showAction(Estatoferta $estatoferta)
    {
        $deleteForm = $this->createDeleteForm($estatoferta);

        return $this->render('borsaTreballWebBundle:estatoferta:show.html.twig', array(
            'estatoferta' => $estatoferta,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing estatoferta entity.
     *
     */
    public function editAction(Request $request, Estatoferta $estatoferta)
    {
        $deleteForm = $this->createDeleteForm($estatoferta);
        $editForm = $this->createForm('borsaTreball\WebBundle\Form\EstatofertaType', $estatoferta);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('estatoferta_edit', array('idestatoferta' => $estatoferta->getIdestatoferta()));
        }

        return $this->render('borsaTreballWebBundle:estatoferta:edit.html.twig', array(
            'estatoferta' => $estatoferta,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Deletes a estatoferta entity.
     *
     */
    public function deleteAction(Request $request, Estatoferta $estatoferta)
    {
        $form = $this->createDeleteForm($estatoferta);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($estatoferta);
            $em->flush();
        }

        return $this->redirectToRoute('estatoferta_index');
    }

    /**
     * Creates a form to delete a estatoferta entity.
     *
     * @param Estatoferta $estatoferta The estatoferta entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Estatoferta $estatoferta)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('estatoferta_delete', array('idestatoferta' => $estatoferta->getIdestatoferta())))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
}
