<?php

namespace borsaTreball\WebBundle\Controller;

use borsaTreball\WebBundle\Entity\Etiqueta;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
/**
 * Etiqueta controller.
 *
 */
class EtiquetaController extends Controller
{
    /**
     * Lists all etiqueta entities.
     *
     */
    public function indexAction()
    {
        $this->denyAccessUnlessGranted(['ROLE_1','ROLE_2','ROLE_3']);
        $em = $this->getDoctrine()->getManager();

        $etiquetas = $em->getRepository('borsaTreballWebBundle:Etiqueta')->findAll();

        return $this->render('borsaTreballWebBundle:etiqueta:index.html.twig', array(
            'etiquetas' => $etiquetas,
        ));
    }

    /**
     * Creates a new etiqueta entity.
     *
     */
    public function newAction(Request $request)
    {
        $etiqueta = new Etiqueta();
        $form = $this->createForm('borsaTreball\WebBundle\Form\EtiquetaType', $etiqueta);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($etiqueta);
            $em->flush();

            return $this->redirectToRoute('etiqueta_index');
        }

        return $this->render('borsaTreballWebBundle:etiqueta:new.html.twig', array(
            'etiqueta' => $etiqueta,
            'form' => $form->createView(),
        ));
    }

    /**
     * Finds and displays a etiqueta entity.
     *
     */
    public function showAction(Etiqueta $etiqueta)
    {
        $deleteForm = $this->createDeleteForm($etiqueta);

        return $this->render('borsaTreballWebBundle:etiqueta:show.html.twig', array(
            'etiqueta' => $etiqueta,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing etiqueta entity.
     *
     */
    public function editAction(Request $request, Etiqueta $etiqueta)
    {
        $deleteForm = $this->createDeleteForm($etiqueta);
        $editForm = $this->createForm('borsaTreball\WebBundle\Form\EtiquetaType', $etiqueta);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('etiqueta_edit', array('idetiqueta' => $etiqueta->getIdetiqueta()));
        }

        return $this->render('borsaTreballWebBundle:etiqueta:edit.html.twig', array(
            'etiqueta' => $etiqueta,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Deletes a etiqueta entity.
     *
     */
    public function deleteAction(Request $request, Etiqueta $etiqueta)
    {
        $form = $this->createDeleteForm($etiqueta);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($etiqueta);
            $em->flush();
        }

        return $this->redirectToRoute('etiqueta_index');
    }

    /**
     * Creates a form to delete a etiqueta entity.
     *
     * @param Etiqueta $etiqueta The etiqueta entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Etiqueta $etiqueta)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('etiqueta_delete', array('idetiqueta' => $etiqueta->getIdetiqueta())))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
}
