<?php

namespace borsaTreball\WebBundle\Controller;

use borsaTreball\WebBundle\Entity\Professor;
use borsaTreball\WebBundle\Entity\ProfessorUsuari;
use borsaTreball\WebBundle\Entity\Usuari;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
/**
 * Professor controller.
 *
 */
class ProfessorController extends Controller
{
    /**
     * Lists all professor entities.
     *
     */
    public function indexAction()
    {
        $this->denyAccessUnlessGranted(['ROLE_1','ROLE_2','ROLE_3']);
        $em = $this->getDoctrine()->getManager();

        $professors = $em->getRepository('borsaTreballWebBundle:Professor')->findAll();

        return $this->render('borsaTreballWebBundle:professor:index.html.twig', array(
            'professors' => $professors,
        ));
    }

    /**
     * Creates a new professor entity.
     *
     */
    public function newAction(Request $request)
    {

        $professor = new Professor();
        $professorUsuari = new ProfessorUsuari();
        $usuari = new Usuari();
        $form = $this->createForm('borsaTreball\WebBundle\Form\ProfessorUsuariType', $professorUsuari);
        $form->handleRequest($request);

        $em = $this->getDoctrine()->getManager();

        if ($form->isSubmitted() && $form->isValid()) {

            $professor->setNomprofessor($form['nomprofessor']->getData());
            $professor->setCognomprofessor($form['cognomprofessor']->getData());
            $professor->setEmail($form['email']->getData());
            $professor->setLinkedin($form['linkedin']->getData());

            $usuari->setNomusuari($form['nomusuari']->getData());
            $usuari->setPassword(crypt($form['password']->getData(), null));
            $usuari->setIdtipususuari($form['idtipususuari']->getData());
            //            $tipusUsuari = $em->getRepository('borsaTreballWebBundle:Tipususuari')->findBy(['idtipususuari' => 5]);
            //            foreach ($tipusUsuari as $a) {
            //            $usuari->setIdtipususuari($a);
            //            }
            $usuari->setIdprofessor($professor);
            $em->persist($usuari);


            $em->persist($professor);
            $em->flush();

            return $this->redirectToRoute('borsa_treball_web_login');
        }

        return $this->render('borsaTreballWebBundle:professor:new.html.twig', array(
            //            'empresa' => $professor,
            'form' => $form->createView(),
        ));


        //        $professor = new Professor();
        //        $form = $this->createForm('borsaTreball\WebBundle\Form\ProfessorType', $professor);
        //        $form->handleRequest($request);
        //
        //        if ($form->isSubmitted() && $form->isValid()) {
        //            $em = $this->getDoctrine()->getManager();
        //            $em->persist($professor);
        //            $em->flush();
        //
        //            return $this->redirectToRoute('professor_show', array('idprofessor' => $professor->getIdprofessor()));
        //        }
        //
        //        return $this->render('borsaTreballWebBundle:professor:new.html.twig', array(
        //            'professor' => $professor,
        //            'form' => $form->createView(),
        //        ));
    }

    /**
     * Finds and displays a professor entity.
     *
     */
    public function showAction(Professor $professor)
    {
        $deleteForm = $this->createDeleteForm($professor);

        return $this->render('borsaTreballWebBundle:professor:show.html.twig', array(
            'professor' => $professor,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing professor entity.
     *
     */
    public function editAction(Request $request, Professor $professor)
    {
        $deleteForm = $this->createDeleteForm($professor);
        $editForm = $this->createForm('borsaTreball\WebBundle\Form\ProfessorType', $professor);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('professor_edit', array('idprofessor' => $professor->getIdprofessor()));
        }

        return $this->render('borsaTreballWebBundle:professor:edit.html.twig', array(
            'professor' => $professor,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Deletes a professor entity.
     *
     */
    public function deleteAction(Request $request, Professor $professor)
    {
        $form = $this->createDeleteForm($professor);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($professor);
            $em->flush();
        }

        return $this->redirectToRoute('professor_index');
    }

    /**
     * Creates a form to delete a professor entity.
     *
     * @param Professor $professor The professor entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Professor $professor)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('professor_delete', array('idprofessor' => $professor->getIdprofessor())))
            ->setMethod('DELETE')
            ->getForm()
            ;
    }
}
