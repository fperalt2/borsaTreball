<?php

namespace borsaTreball\WebBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class borsaTreballWebBundle extends Bundle
{
}
