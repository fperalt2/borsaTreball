<?php

namespace borsaTreball\WebBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType; 
use Symfony\Component\Form\Extension\Core\Type\PasswordType; 
use Symfony\Bridge\Doctrine\Form\Type\EntityType;

class UsuariType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('nomusuari',TextType::class)->add('password',PasswordType::class);
    }/**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'borsaTreball\WebBundle\Entity\Usuari'
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'borsatreball_webbundle_usuari';
    }


}


//->add('idtipususuari', EntityType::class, array( 'class' => 'borsaTreballWebBundle:Tipususuari', 'choice_label' => 'nomtipus', 'multiple' => FALSE, 'label_attr'=> array('class' => 'labelT'), 'attr' => array('class' => 'form-control') ))->add('idalumne', EntityType::class, array( 'class' => 'borsaTreballWebBundle:Alumne', 'choice_label' => 'nom', 'multiple' => FALSE, 'label_attr'=> array('class' => 'labelT'), 'attr' => array('class' => 'form-control') ))->add('idempresa', EntityType::class, array( 'class' => 'borsaTreballWebBundle:Empresa', 'choice_label' => 'nomempresa', 'multiple' => FALSE, 'label_attr'=> array('class' => 'labelT'), 'attr' => array('class' => 'form-control') ))->add('idprofessor', EntityType::class, array( 'class' => 'borsaTreballWebBundle:Professor', 'choice_label' => 'nomprofessor', 'multiple' => FALSE, 'label_attr'=> array('class' => 'labelT'), 'attr' => array('class' => 'form-control') ));