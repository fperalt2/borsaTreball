<?php

namespace borsaTreball\WebBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\BirthdayType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use borsaTreball\WebBundle\Entity\Cicle;
//
class AlumneUsuariType extends AbstractType {

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options) {
        $builder->add('nivellcurs', ChoiceType::class, array('choices' => array(
            '1er' => '1',
            '2on' => '2'),
                                                             'choices_as_values' => true, 'multiple' => false, 'expanded' => true, 'required' => false))
            ->add('nom', TextType::class, array(
                'required' => false
            ))->add('cognoms', TextType::class, array(
            'required' => false
        ))->add('dni', TextType::class, array(
            'required' => false
        ))->add('sexe', ChoiceType::class, array('choices' => array(
            'H' => 'Home',
            'D' => 'Dona'),
                                                 'choices_as_values' => true, 'multiple' => false, 'expanded' => true, 'required' => false))->add('datanaixement', BirthdayType::class)->add('llocnaixement', TextType::class, array(
            'required' => false
        ))
            ->add('direccio', TextType::class, array(
                'required' => false
            ))->add('email', EmailType::class, array(
            'required' => false
        ))->add('codipostal', TextType::class, array(
            'required' => false
        ))->add('telefonfixe', TextType::class, array(
            'required' => false
        ))
            ->add('mobil', TextType::class, array(
                'required' => false
            ))->add('numseguretatsocial', TextType::class, array(
            'required' => false
        ))->add('coditarjetasanitaria', TextType::class, array(
            'required' => false
        ))
            ->add('nompare', TextType::class, array(
                'required' => false
            ))->add('nommare', TextType::class, array(
            'required' => false
        ))->add('emailpare', EmailType::class, array(
            'required' => false
        ))->add('emailmare', EmailType::class, array(
            'required' => false
        ))
            ->add('telefonpare', TextType::class, array(
                'required' => false
            ))->add('telefonmare', TextType::class, array(
            'required' => false
        ))->add('centreprocedencia', TextType::class, array(
            'required' => false
        ))
            ->add('linkedin', TextType::class, array(
                'required' => false
            ))->add('actiulaboral')->add('nomempresa', TextType::class, array(
            'required' => false
        ))->add('antiguitat', TextType::class, array(
            'required' => false
        ))
            ->add('cercafeina')->add('sectorempresarial', TextType::class, array(
            'required' => false
        ))->add('carnetconduir')->add('vehiclepropi')
            ->add('intencionsfutures', ChoiceType::class, array('choices' => array(
                'Continuar estudiant' => 'Continuar estudiant',
                'Treballar' => 'Treballar',
                'Estudiar i treballar' => 'Estudiar i treballar'),
                                                                'choices_as_values' => true, 'multiple' => false, 'expanded' => true, 'required' => false))->add('graduat')
            ->add('curriculum', FileType::class,array(
                'data_class' => null, 'required'=> false)
                 )
            ->add('descripcio', TextareaType::class, array(
                'required' => false
            ))->add('fctdual')->add('notificacions')
            ->add('idcicle', EntityType::class, array('class' => 'borsaTreballWebBundle:Cicle', 'choice_label' => 'nomcicle', 'multiple' => FALSE, 'label_attr' => array('class' => 'labelT'), 'attr' => array('class' => 'form-control'), 'required' =>false))
            ->add('idestudisacces', EntityType::class, array('class' => 'borsaTreballWebBundle:EstudiAcces', 'choice_label' => 'nomestudi', 'multiple' => FALSE, 'label_attr' => array('class' => 'labelT'), 'attr' => array('class' => 'form-control')))
            ->add('idnomestudiacces', EntityType::class, array('class' => 'borsaTreballWebBundle:Estudi', 'choice_label' => 'nomestudi', 'multiple' => FALSE, 'label_attr' => array('class' => 'labelT'), 'attr' => array('class' => 'form-control')))
            ->add('idnacionalitat', EntityType::class, array('class' => 'borsaTreballWebBundle:Nacionalitat', 'choice_label' => 'nomnacionalitat', 'multiple' => FALSE, 'label_attr' => array('class' => 'labelT'), 'attr' => array('class' => 'form-control')))->add('idpoblacio', EntityType::class, array('class' => 'borsaTreballWebBundle:Poblacio', 'choice_label' => 'nompoblacio', 'multiple' => FALSE, 'label_attr' => array('class' => 'labelT'), 'attr' => array('class' => 'form-control')))
            ->add('idprovincia', EntityType::class, array('class' => 'borsaTreballWebBundle:Provincia', 'choice_label' => 'nomprovincia', 'multiple' => FALSE, 'label_attr' => array('class' => 'labelT'), 'attr' => array('class' => 'form-control')))
            ->add('nomusuari',TextType::class, array('attr' => array('readonly' => true,),))->add('password',PasswordType::class);
    }


    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'borsaTreball\WebBundle\Entity\AlumneUsuari'
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'borsatreball_webbundle_alumneusuari';
    }

}
