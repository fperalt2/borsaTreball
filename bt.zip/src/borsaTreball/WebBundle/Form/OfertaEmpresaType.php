<?php

namespace borsaTreball\WebBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType; 
use Symfony\Component\Form\Extension\Core\Type\TextareaType; 
use Symfony\Bridge\Doctrine\Form\Type\EntityType;

class OfertaEmpresaType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('sector',TextType::class)->add('descripcio',TextareaType::class)->add('infolloctreball',TextareaType::class)->add('requisits',TextareaType::class)->add('condicions',TextareaType::class)->add('treballadorsnecessitats',TextType::class)->add('idtipuscontracte', EntityType::class, array( 'class' => 'borsaTreballWebBundle:Tipuscontracte', 'choice_label' => 'nomtipuscontracte', 'multiple' => FALSE, 'label_attr'=> array('class' => 'labelT'), 'attr' => array('class' => 'form-control') ));
    }/**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'borsaTreball\WebBundle\Entity\Oferta'
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'borsatreball_webbundle_oferta';
    }


}
