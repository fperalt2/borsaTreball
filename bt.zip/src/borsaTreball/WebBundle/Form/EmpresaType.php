<?php

namespace borsaTreball\WebBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;

class EmpresaType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('nomempresa',TextType::class)->add('nifempresa',TextType::class)->add('nomresponsable',TextType::class)->add('informacioempresa',TextareaType::class)->add('correoempresa',EmailType::class)->add('telefonempresa',TextType::class)->add('direccio',TextType::class)->add('codipostal',TextType::class)->add('idnacionalitat', EntityType::class, array( 'class' => 'borsaTreballWebBundle:Nacionalitat', 'choice_label' => 'nomnacionalitat', 'multiple' => FALSE, 'label_attr'=> array('class' => 'labelT'), 'attr' => array('class' => 'form-control') ))->add('idpoblacio', EntityType::class, array( 'class' => 'borsaTreballWebBundle:Poblacio', 'choice_label' => 'nompoblacio', 'multiple' => FALSE, 'label_attr'=> array('class' => 'labelT'), 'attr' => array('class' => 'form-control') ))->add('idprovincia', EntityType::class, array( 'class' => 'borsaTreballWebBundle:Provincia', 'choice_label' => 'nomprovincia', 'multiple' => FALSE, 'label_attr'=> array('class' => 'labelT'), 'attr' => array('class' => 'form-control') ));
    }/**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'borsaTreball\WebBundle\Entity\Empresa'
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'borsatreball_webbundle_empresa';
    }


}
