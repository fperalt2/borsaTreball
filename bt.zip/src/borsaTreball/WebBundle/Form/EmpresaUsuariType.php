<?php

namespace borsaTreball\WebBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;

class EmpresaUsuariType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $provincia = 1;

        $em = $options['entity_manager'];
        $poblacions = $em->getRepository('borsaTreballWebBundle:Poblacio')->findBy(['idprovincia' => $provincia]);
        $Barcelona = $em->getRepository('borsaTreballWebBundle:Provincia')->findBy(['idprovincia' => 1]);

        $builder->add('nomempresa',TextType::class)
        ->add('nifempresa',TextType::class)
        ->add('nomresponsable',TextType::class)
        ->add('informacioempresa',TextareaType::class)
        ->add('correoempresa',EmailType::class)
        ->add('telefonempresa',TextType::class)
        ->add('direccio',TextType::class)
        ->add('codipostal',TextType::class)
        ->add('idnacionalitat', EntityType::class, array( 'class' => 'borsaTreballWebBundle:Nacionalitat', 'choice_label' => 'nomnacionalitat', 'multiple' => FALSE, 'label_attr'=> array('class' => 'labelT'), 'attr' => array('class' => 'form-control') ))
        ->add('idprovincia', EntityType::class, array( 'data' => $Barcelona, 'class' => 'borsaTreballWebBundle:Provincia', 'choice_label' => 'nomprovincia', 'multiple' => FALSE, 'label_attr'=> array('class' => 'labelT'), 'attr' => array('class' => 'form-control') ))
        //->add('nomusuari',TextType::class)
        ->add('password', RepeatedType::class, array('type' => PasswordType::class, 'invalid_message' => 'El password no coincideix.',
               'options' => array('attr' => array('class' => 'password-field')), 'required' => true,
               'first_options'  => array('label' => 'Password'), 'second_options' => array('label' => 'Repetir password'),
         ))
        //->add('password',PasswordType::class)
        ->add('idpoblacio', EntityType::class, array( 'class' => 'borsaTreballWebBundle:Poblacio','choice_label' => 'nompoblacio', 'multiple' => FALSE, 'label_attr'=> array('class' => 'labelT'), 'attr' => array('class' => 'form-control') ));
/*
        $builder->addEventListener(FormEvents::PRE_SET_DATA, function (FormEvent $event) use ($options) {
            // ... adding the name field if needed
            if (true) {
                 //$provincia = 1;

                // if ($event->getData()->getIdprovincia() != 1) {
                //     $provincia = $event->getData()->getIdprovincia();
                // } else {
                // };
                //$em = $this->getDoctrine()->getManager();
//                $options = $form->getOptions();
                //$provincia = $event->getData()->getIdprovincia();
                $provincia = 2;
                $form = $event->getForm();
                //$provincia = $form['idprovincia']->getData();
                $em = $options['entity_manager'];
                $Barcelona = $em->getRepository('borsaTreballWebBundle:Provincia')->findBy(['idprovincia' => 1]);
                $Tarragona = $em->getRepository('borsaTreballWebBundle:Provincia')->findBy(['idprovincia' => 2]);
                $poblacions = $em->getRepository('borsaTreballWebBundle:Poblacio')->findBy(['idprovincia' => $Tarragona]);

                //$form->add('name', TextType::class);
                $form->add('idprovincia', EntityType::class, array( 'data' => $Barcelona, 'class' => 'borsaTreballWebBundle:Provincia', 'choice_label' => 'nomprovincia', 'multiple' => FALSE, 'label_attr'=> array('class' => 'labelT'), 'attr' => array('class' => 'form-control') ));
                $form->add('idpoblacio', EntityType::class, array( 'class' => 'borsaTreballWebBundle:Poblacio','choices' => $poblacions,'choice_label' => 'nompoblacio', 'multiple' => FALSE, 'label_attr'=> array('class' => 'labelT'), 'attr' => array('class' => 'form-control') ));
            }
        });

*/
/*
        $builder->get('idprovincia')->addEventListener(FormEvents::POST_SUBMIT, function (FormEvent $event) use ($options) {
            // ... adding the name field if needed
            if (true) {

                // if ($event->getData()->getIdprovincia() != 1) {
                //     $provincia = $event->getData()->getIdprovincia();
                // } else {
                //     $provincia = 1;
                // };
                //$em = $this->getDoctrine()->getManager();
                $provincia = $event->getForm()->getData();
                $provincia = 2;
                //$provincia = $event['nomempresa']->getData();
//                $options = $form->getOptions();
                $em = $options['entity_manager'];
                $poblacions = $em->getRepository('borsaTreballWebBundle:Poblacio')->findBy(['idprovincia' => $provincia]);
                $form = $event->getForm()->getParent();
//                $provincia = $form['idprovincia']->getData();

                //$form->add('name', TextType::class);
                $form->add('idpoblacio', EntityType::class, array( 'class' => 'borsaTreballWebBundle:Poblacio','choices' => $poblacions,'choice_label' => 'nompoblacio', 'multiple' => FALSE, 'label_attr'=> array('class' => 'labelT'), 'attr' => array('class' => 'form-control') ));
            }
        });
*/
    }/**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'borsaTreball\WebBundle\Entity\EmpresaUsuari'
        ));
        $resolver->setRequired('entity_manager');
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'borsatreball_webbundle_empresausuari';
    }


}
