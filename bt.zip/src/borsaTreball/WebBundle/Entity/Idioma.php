<?php

namespace borsaTreball\WebBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Idioma
 *
 * @ORM\Table(name="Idioma")
 * @ORM\Entity
 */
class Idioma
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idIdioma", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $ididioma;

    /**
     * @var string
     *
     * @ORM\Column(name="nomIdioma", type="text", length=65535, nullable=true)
     */
    private $nomidioma;



    /**
     * Get ididioma
     *
     * @return integer
     */
    public function getIdidioma()
    {
        return $this->ididioma;
    }

    /**
     * Set nomidioma
     *
     * @param string $nomidioma
     *
     * @return Idioma
     */
    public function setNomidioma($nomidioma)
    {
        $this->nomidioma = $nomidioma;

        return $this;
    }

    /**
     * Get nomidioma
     *
     * @return string
     */
    public function getNomidioma()
    {
        return $this->nomidioma;
    }
}
