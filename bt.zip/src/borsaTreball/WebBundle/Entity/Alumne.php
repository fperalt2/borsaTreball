<?php

namespace borsaTreball\WebBundle\Entity;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\ORM\Mapping as ORM;

/**
 * Alumne
 *
 * @ORM\Table(name="Alumne", indexes={@ORM\Index(name="idCicle", columns={"idCicle"}), @ORM\Index(name="idEstudisAcces", columns={"idEstudisAcces"}), @ORM\Index(name="idNacionalitat", columns={"idNacionalitat"}), @ORM\Index(name="idPoblació", columns={"idPoblacio"}), @ORM\Index(name="idProvincia", columns={"idProvincia"}), @ORM\Index(name="Alumne_ibfk_8", columns={"idNomEstudiAcces"})})
 * @ORM\Entity
 */
class Alumne
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idAlumne", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idalumne;

    /**
     * @var integer
     *
     * @ORM\Column(name="nivellCurs", type="integer", nullable=true)
     */
    private $nivellcurs;

    /**
     * @var string
     *
     * @ORM\Column(name="nom", type="text", length=65535, nullable=true)
     */
    private $nom;

    /**
     * @var string
     *
     * @ORM\Column(name="cognoms", type="text", length=65535, nullable=true)
     */
    private $cognoms;

    /**
     * @var string
     *
     * @ORM\Column(name="dni", type="text", length=65535, nullable=true)
     */
    private $dni;

    /**
     * @var string
     *
     * @ORM\Column(name="sexe", type="text", length=65535, nullable=true)
     */
    private $sexe;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="dataNaixement", type="date", nullable=true)
     */
    private $datanaixement;

    /**
     * @var string
     *
     * @ORM\Column(name="llocNaixement", type="text", length=65535, nullable=true)
     */
    private $llocnaixement;

    /**
     * @var string
     *
     * @ORM\Column(name="direccio", type="text", length=65535, nullable=true)
     */
    private $direccio;

    /**
     * @var string
     *
     * @ORM\Column(name="email", type="text", length=65535, nullable=true)
     */
    private $email;

    /**
     * @var integer
     *
     * @ORM\Column(name="codiPostal", type="integer", nullable=true)
     */
    private $codipostal;

    /**
     * @var integer
     *
     * @ORM\Column(name="telefonFixe", type="integer", nullable=true)
     */
    private $telefonfixe;

    /**
     * @var integer
     *
     * @ORM\Column(name="mobil", type="integer", nullable=true)
     */
    private $mobil;

    /**
     * @var string
     *
     * @ORM\Column(name="numSeguretatSocial", type="text", length=65535, nullable=true)
     */
    private $numseguretatsocial;

    /**
     * @var string
     *
     * @ORM\Column(name="codiTarjetaSanitaria", type="text", length=65535, nullable=true)
     */
    private $coditarjetasanitaria;

    /**
     * @var string
     *
     * @ORM\Column(name="nomPare", type="text", length=65535, nullable=true)
     */
    private $nompare;

    /**
     * @var string
     *
     * @ORM\Column(name="nomMare", type="text", length=65535, nullable=true)
     */
    private $nommare;

    /**
     * @var string
     *
     * @ORM\Column(name="emailPare", type="text", length=65535, nullable=true)
     */
    private $emailpare;

    /**
     * @var string
     *
     * @ORM\Column(name="emailMare", type="text", length=65535, nullable=true)
     */
    private $emailmare;

    /**
     * @var integer
     *
     * @ORM\Column(name="telefonPare", type="integer", nullable=true)
     */
    private $telefonpare;

    /**
     * @var integer
     *
     * @ORM\Column(name="telefonMare", type="integer", nullable=true)
     */
    private $telefonmare;

    /**
     * @var string
     *
     * @ORM\Column(name="centreProcedencia", type="text", length=65535, nullable=true)
     */
    private $centreprocedencia;

    /**
     * @var string
     *
     * @ORM\Column(name="linkedin", type="text", length=65535, nullable=true)
     */
    private $linkedin;

    /**
     * @var boolean
     *
     * @ORM\Column(name="actiuLaboral", type="boolean", nullable=true)
     */
    private $actiulaboral;

    /**
     * @var string
     *
     * @ORM\Column(name="nomEmpresa", type="text", length=65535, nullable=true)
     */
    private $nomempresa;

    /**
     * @var integer
     *
     * @ORM\Column(name="antiguitat", type="integer", nullable=true)
     */
    private $antiguitat;

    /**
     * @var boolean
     *
     * @ORM\Column(name="cercaFeina", type="boolean", nullable=true)
     */
    private $cercafeina;

    /**
     * @var string
     *
     * @ORM\Column(name="sectorEmpresarial", type="text", length=65535, nullable=true)
     */
    private $sectorempresarial;

    /**
     * @var boolean
     *
     * @ORM\Column(name="carnetConduir", type="boolean", nullable=true)
     */
    private $carnetconduir;

    /**
     * @var boolean
     *
     * @ORM\Column(name="vehiclePropi", type="boolean", nullable=true)
     */
    private $vehiclepropi;

    /**
     * @var string
     *
     * @ORM\Column(name="intencionsFutures", type="text", length=65535, nullable=true)
     */
    private $intencionsfutures;

    /**
     * @var boolean
     *
     * @ORM\Column(name="graduat", type="boolean", nullable=true)
     */
    private $graduat;

    /**
     * @var string
     *
     * @ORM\Column(name="curriculum", type="text", length=65535, nullable=true)
     */
    private $curriculum;

    /**
     * @var string
     *
     * @ORM\Column(name="descripcio", type="text", length=65535, nullable=true)
     */
    private $descripcio;

    /**
     * @var boolean
     *
     * @ORM\Column(name="fctDual", type="boolean", nullable=true)
     */
    private $fctdual;

    /**
     * @var boolean
     *
     * @ORM\Column(name="notificacions", type="boolean", nullable=true)
     */
    private $notificacions;

    /**
     * @var boolean
     *
     * @ORM\Column(name="validat", type="boolean", nullable=true)
     */
    private $validat;

    /**
     * @var \Cicle
     *
     * @ORM\ManyToOne(targetEntity="Cicle")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idCicle", referencedColumnName="idCicle")
     * })
     */
    private $idcicle;

    /**
     * @var \Estudiacces
     *
     * @ORM\ManyToOne(targetEntity="Estudiacces")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idEstudisAcces", referencedColumnName="idEstudiAcces")
     * })
     */
    private $idestudisacces;

    /**
     * @var \Nacionalitat
     *
     * @ORM\ManyToOne(targetEntity="Nacionalitat")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idNacionalitat", referencedColumnName="idNacionalitat")
     * })
     */
    private $idnacionalitat;

    /**
     * @var \Poblacio
     *
     * @ORM\ManyToOne(targetEntity="Poblacio")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idPoblacio", referencedColumnName="idPoblacio")
     * })
     */
    private $idpoblacio;

    /**
     * @var \Provincia
     *
     * @ORM\ManyToOne(targetEntity="Provincia")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idProvincia", referencedColumnName="idProvincia")
     * })
     */
    private $idprovincia;

    /**
     * @var \Estudi
     *
     * @ORM\ManyToOne(targetEntity="Estudi")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idNomEstudiAcces", referencedColumnName="idEstudi")
     * })
     */
    private $idnomestudiacces;


    /**
     * Set idalumne
     *
     * @param integer $idalumne
     *
     * @return Alumne
     */
    public function setIdalumne($idalumne)
    {
        $this->idalumne = $idalumne;

        return $this;
    }

    /**
     * Get idalumne
     *
     * @return integer
     */
    public function getIdalumne()
    {
        return $this->idalumne;
    }

    /**
     * Set nivellcurs
     *
     * @param integer $nivellcurs
     *
     * @return Alumne
     */
    public function setNivellcurs($nivellcurs)
    {
        $this->nivellcurs = $nivellcurs;

        return $this;
    }

    /**
     * Get nivellcurs
     *
     * @return integer
     */
    public function getNivellcurs()
    {
        return $this->nivellcurs;
    }

    /**
     * Set nom
     *
     * @param string $nom
     *
     * @return Alumne
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set cognoms
     *
     * @param string $cognoms
     *
     * @return Alumne
     */
    public function setCognoms($cognoms)
    {
        $this->cognoms = $cognoms;

        return $this;
    }

    /**
     * Get cognoms
     *
     * @return string
     */
    public function getCognoms()
    {
        return $this->cognoms;
    }

    /**
     * Set dni
     *
     * @param string $dni
     *
     * @return Alumne
     */
    public function setDni($dni)
    {
        $this->dni = $dni;

        return $this;
    }

    /**
     * Get dni
     *
     * @return string
     */
    public function getDni()
    {
        return $this->dni;
    }

    /**
     * Set sexe
     *
     * @param string $sexe
     *
     * @return Alumne
     */
    public function setSexe($sexe)
    {
        $this->sexe = $sexe;

        return $this;
    }

    /**
     * Get sexe
     *
     * @return string
     */
    public function getSexe()
    {
        return $this->sexe;
    }

    /**
     * Set datanaixement
     *
     * @param \DateTime $datanaixement
     *
     * @return Alumne
     */
    public function setDatanaixement($datanaixement)
    {
        $this->datanaixement = $datanaixement;

        return $this;
    }

    /**
     * Get datanaixement
     *
     * @return \DateTime
     */
    public function getDatanaixement()
    {
        return $this->datanaixement;
    }

    /**
     * Set llocnaixement
     *
     * @param string $llocnaixement
     *
     * @return Alumne
     */
    public function setLlocnaixement($llocnaixement)
    {
        $this->llocnaixement = $llocnaixement;

        return $this;
    }

    /**
     * Get llocnaixement
     *
     * @return string
     */
    public function getLlocnaixement()
    {
        return $this->llocnaixement;
    }

    /**
     * Set direccio
     *
     * @param string $direccio
     *
     * @return Alumne
     */
    public function setDireccio($direccio)
    {
        $this->direccio = $direccio;

        return $this;
    }

    /**
     * Get direccio
     *
     * @return string
     */
    public function getDireccio()
    {
        return $this->direccio;
    }

    /**
     * Set email
     *
     * @param string $email
     *
     * @return Alumne
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set codipostal
     *
     * @param integer $codipostal
     *
     * @return Alumne
     */
    public function setCodipostal($codipostal)
    {
        $this->codipostal = $codipostal;

        return $this;
    }

    /**
     * Get codipostal
     *
     * @return integer
     */
    public function getCodipostal()
    {
        return $this->codipostal;
    }

    /**
     * Set telefonfixe
     *
     * @param integer $telefonfixe
     *
     * @return Alumne
     */
    public function setTelefonfixe($telefonfixe)
    {
        $this->telefonfixe = $telefonfixe;

        return $this;
    }

    /**
     * Get telefonfixe
     *
     * @return integer
     */
    public function getTelefonfixe()
    {
        return $this->telefonfixe;
    }

    /**
     * Set mobil
     *
     * @param integer $mobil
     *
     * @return Alumne
     */
    public function setMobil($mobil)
    {
        $this->mobil = $mobil;

        return $this;
    }

    /**
     * Get mobil
     *
     * @return integer
     */
    public function getMobil()
    {
        return $this->mobil;
    }

    /**
     * Set numseguretatsocial
     *
     * @param integer $numseguretatsocial
     *
     * @return Alumne
     */
    public function setNumseguretatsocial($numseguretatsocial)
    {
        $this->numseguretatsocial = $numseguretatsocial;

        return $this;
    }

    /**
     * Get numseguretatsocial
     *
     * @return integer
     */
    public function getNumseguretatsocial()
    {
        return $this->numseguretatsocial;
    }

    /**
     * Set coditarjetasanitaria
     *
     * @param string $coditarjetasanitaria
     *
     * @return Alumne
     */
    public function setCoditarjetasanitaria($coditarjetasanitaria)
    {
        $this->coditarjetasanitaria = $coditarjetasanitaria;

        return $this;
    }

    /**
     * Get coditarjetasanitaria
     *
     * @return string
     */
    public function getCoditarjetasanitaria()
    {
        return $this->coditarjetasanitaria;
    }

    /**
     * Set nompare
     *
     * @param string $nompare
     *
     * @return Alumne
     */
    public function setNompare($nompare)
    {
        $this->nompare = $nompare;

        return $this;
    }

    /**
     * Get nompare
     *
     * @return string
     */
    public function getNompare()
    {
        return $this->nompare;
    }

    /**
     * Set nommare
     *
     * @param string $nommare
     *
     * @return Alumne
     */
    public function setNommare($nommare)
    {
        $this->nommare = $nommare;

        return $this;
    }

    /**
     * Get nommare
     *
     * @return string
     */
    public function getNommare()
    {
        return $this->nommare;
    }

    /**
     * Set emailpare
     *
     * @param string $emailpare
     *
     * @return Alumne
     */
    public function setEmailpare($emailpare)
    {
        $this->emailpare = $emailpare;

        return $this;
    }

    /**
     * Get emailpare
     *
     * @return string
     */
    public function getEmailpare()
    {
        return $this->emailpare;
    }

    /**
     * Set emailmare
     *
     * @param string $emailmare
     *
     * @return Alumne
     */
    public function setEmailmare($emailmare)
    {
        $this->emailmare = $emailmare;

        return $this;
    }

    /**
     * Get emailmare
     *
     * @return string
     */
    public function getEmailmare()
    {
        return $this->emailmare;
    }

    /**
     * Set telefonpare
     *
     * @param integer $telefonpare
     *
     * @return Alumne
     */
    public function setTelefonpare($telefonpare)
    {
        $this->telefonpare = $telefonpare;

        return $this;
    }

    /**
     * Get telefonpare
     *
     * @return integer
     */
    public function getTelefonpare()
    {
        return $this->telefonpare;
    }

    /**
     * Set telefonmare
     *
     * @param integer $telefonmare
     *
     * @return Alumne
     */
    public function setTelefonmare($telefonmare)
    {
        $this->telefonmare = $telefonmare;

        return $this;
    }

    /**
     * Get telefonmare
     *
     * @return integer
     */
    public function getTelefonmare()
    {
        return $this->telefonmare;
    }

    /**
     * Set centreprocedencia
     *
     * @param string $centreprocedencia
     *
     * @return Alumne
     */
    public function setCentreprocedencia($centreprocedencia)
    {
        $this->centreprocedencia = $centreprocedencia;

        return $this;
    }

    /**
     * Get centreprocedencia
     *
     * @return string
     */
    public function getCentreprocedencia()
    {
        return $this->centreprocedencia;
    }

    /**
     * Set linkedin
     *
     * @param string $linkedin
     *
     * @return Alumne
     */
    public function setLinkedin($linkedin)
    {
        $this->linkedin = $linkedin;

        return $this;
    }

    /**
     * Get linkedin
     *
     * @return string
     */
    public function getLinkedin()
    {
        return $this->linkedin;
    }

    /**
     * Set actiulaboral
     *
     * @param boolean $actiulaboral
     *
     * @return Alumne
     */
    public function setActiulaboral($actiulaboral)
    {
        $this->actiulaboral = $actiulaboral;

        return $this;
    }

    /**
     * Get actiulaboral
     *
     * @return boolean
     */
    public function getActiulaboral()
    {
        return $this->actiulaboral;
    }

    /**
     * Set nomempresa
     *
     * @param string $nomempresa
     *
     * @return Alumne
     */
    public function setNomempresa($nomempresa)
    {
        $this->nomempresa = $nomempresa;

        return $this;
    }

    /**
     * Get nomempresa
     *
     * @return string
     */
    public function getNomempresa()
    {
        return $this->nomempresa;
    }

    /**
     * Set antiguitat
     *
     * @param integer $antiguitat
     *
     * @return Alumne
     */
    public function setAntiguitat($antiguitat)
    {
        $this->antiguitat = $antiguitat;

        return $this;
    }

    /**
     * Get antiguitat
     *
     * @return integer
     */
    public function getAntiguitat()
    {
        return $this->antiguitat;
    }

    /**
     * Set cercafeina
     *
     * @param boolean $cercafeina
     *
     * @return Alumne
     */
    public function setCercafeina($cercafeina)
    {
        $this->cercafeina = $cercafeina;

        return $this;
    }

    /**
     * Get cercafeina
     *
     * @return boolean
     */
    public function getCercafeina()
    {
        return $this->cercafeina;
    }

    /**
     * Set sectorempresarial
     *
     * @param string $sectorempresarial
     *
     * @return Alumne
     */
    public function setSectorempresarial($sectorempresarial)
    {
        $this->sectorempresarial = $sectorempresarial;

        return $this;
    }

    /**
     * Get sectorempresarial
     *
     * @return string
     */
    public function getSectorempresarial()
    {
        return $this->sectorempresarial;
    }

    /**
     * Set carnetconduir
     *
     * @param boolean $carnetconduir
     *
     * @return Alumne
     */
    public function setCarnetconduir($carnetconduir)
    {
        $this->carnetconduir = $carnetconduir;

        return $this;
    }

    /**
     * Get carnetconduir
     *
     * @return boolean
     */
    public function getCarnetconduir()
    {
        return $this->carnetconduir;
    }

    /**
     * Set vehiclepropi
     *
     * @param boolean $vehiclepropi
     *
     * @return Alumne
     */
    public function setVehiclepropi($vehiclepropi)
    {
        $this->vehiclepropi = $vehiclepropi;

        return $this;
    }

    /**
     * Get vehiclepropi
     *
     * @return boolean
     */
    public function getVehiclepropi()
    {
        return $this->vehiclepropi;
    }

    /**
     * Set intencionsfutures
     *
     * @param string $intencionsfutures
     *
     * @return Alumne
     */
    public function setIntencionsfutures($intencionsfutures)
    {
        $this->intencionsfutures = $intencionsfutures;

        return $this;
    }

    /**
     * Get intencionsfutures
     *
     * @return string
     */
    public function getIntencionsfutures()
    {
        return $this->intencionsfutures;
    }

    /**
     * Set graduat
     *
     * @param boolean $graduat
     *
     * @return Alumne
     */
    public function setGraduat($graduat)
    {
        $this->graduat = $graduat;

        return $this;
    }

    /**
     * Get graduat
     *
     * @return boolean
     */
    public function getGraduat()
    {
        return $this->graduat;
    }

    /**
     * Set curriculum
     *
     * @param string $curriculum
     *
     * @return Alumne
     */
    public function setCurriculum($curriculum)
    {
        $this->curriculum = $curriculum;

        return $this;
    }

    /**
     * Get curriculum
     *
     * @return string
     */
    public function getCurriculum()
    {
        return $this->curriculum;
    }

    /**
     * Set descripcio
     *
     * @param string $descripcio
     *
     * @return Alumne
     */
    public function setDescripcio($descripcio)
    {
        $this->descripcio = $descripcio;

        return $this;
    }

    /**
     * Get descripcio
     *
     * @return string
     */
    public function getDescripcio()
    {
        return $this->descripcio;
    }

    /**
     * Set fctdual
     *
     * @param boolean $fctdual
     *
     * @return Alumne
     */
    public function setFctdual($fctdual)
    {
        $this->fctdual = $fctdual;

        return $this;
    }

    /**
     * Get fctdual
     *
     * @return boolean
     */
    public function getFctdual()
    {
        return $this->fctdual;
    }

    /**
     * Set notificacions
     *
     * @param boolean $notificacions
     *
     * @return Alumne
     */
    public function setNotificacions($notificacions)
    {
        $this->notificacions = $notificacions;

        return $this;
    }

    /**
     * Get notificacions
     *
     * @return boolean
     */
    public function getNotificacions()
    {
        return $this->notificacions;
    }

    /**
     * Set validat
     *
     * @param boolean $validat
     *
     * @return Alumne
     */
    public function setValidat($validat)
    {
        $this->validat = $validat;

        return $this;
    }

    /**
     * Get validat
     *
     * @return boolean
     */
    public function getValidat()
    {
        return $this->validat;
    }

    /**
     * Set idcicle
     *
     * @param \borsaTreball\WebBundle\Entity\Cicle $idcicle
     *
     * @return Alumne
     */
    public function setIdcicle(\borsaTreball\WebBundle\Entity\Cicle $idcicle = null)
    {
        $this->idcicle = $idcicle;

        return $this;
    }

    /**
     * Get idcicle
     *
     * @return \borsaTreball\WebBundle\Entity\Cicle
     */
    public function getIdcicle()
    {
        return $this->idcicle;
    }

    /**
     * Set idestudisacces
     *
     * @param \borsaTreball\WebBundle\Entity\Estudiacces $idestudisacces
     *
     * @return Alumne
     */
    public function setIdestudisacces(\borsaTreball\WebBundle\Entity\Estudiacces $idestudisacces = null)
    {
        $this->idestudisacces = $idestudisacces;

        return $this;
    }

    /**
     * Get idestudisacces
     *
     * @return \borsaTreball\WebBundle\Entity\Estudiacces
     */
    public function getIdestudisacces()
    {
        return $this->idestudisacces;
    }

    /**
     * Set idnacionalitat
     *
     * @param \borsaTreball\WebBundle\Entity\Nacionalitat $idnacionalitat
     *
     * @return Alumne
     */
    public function setIdnacionalitat(\borsaTreball\WebBundle\Entity\Nacionalitat $idnacionalitat = null)
    {
        $this->idnacionalitat = $idnacionalitat;

        return $this;
    }

    /**
     * Get idnacionalitat
     *
     * @return \borsaTreball\WebBundle\Entity\Nacionalitat
     */
    public function getIdnacionalitat()
    {
        return $this->idnacionalitat;
    }

    /**
     * Set idpoblacio
     *
     * @param \borsaTreball\WebBundle\Entity\Poblacio $idpoblacio
     *
     * @return Alumne
     */
    public function setIdpoblacio(\borsaTreball\WebBundle\Entity\Poblacio $idpoblacio = null)
    {
        $this->idpoblacio = $idpoblacio;

        return $this;
    }

    /**
     * Get idpoblacio
     *
     * @return \borsaTreball\WebBundle\Entity\Poblacio
     */
    public function getIdpoblacio()
    {
        return $this->idpoblacio;
    }

    /**
     * Set idprovincia
     *
     * @param \borsaTreball\WebBundle\Entity\Provincia $idprovincia
     *
     * @return Alumne
     */
    public function setIdprovincia(\borsaTreball\WebBundle\Entity\Provincia $idprovincia = null)
    {
        $this->idprovincia = $idprovincia;

        return $this;
    }

    /**
     * Get idprovincia
     *
     * @return \borsaTreball\WebBundle\Entity\Provincia
     */
    public function getIdprovincia()
    {
        return $this->idprovincia;
    }

    /**
     * Set idnomestudiacces
     *
     * @param \borsaTreball\WebBundle\Entity\Estudi $idnomestudiacces
     *
     * @return Alumne
     */
    public function setIdnomestudiacces(\borsaTreball\WebBundle\Entity\Estudi $idnomestudiacces = null)
    {
        $this->idnomestudiacces = $idnomestudiacces;

        return $this;
    }

    /**
     * Get idnomestudiacces
     *
     * @return \borsaTreball\WebBundle\Entity\Estudi
     */
    public function getIdnomestudiacces()
    {
        return $this->idnomestudiacces;
    }

    public function __toString()
    {
        return (string) $this->getIdalumne();
    }
}
