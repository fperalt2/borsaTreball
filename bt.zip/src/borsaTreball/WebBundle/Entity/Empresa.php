<?php

namespace borsaTreball\WebBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Empresa
 *
 * @ORM\Table(name="Empresa", indexes={@ORM\Index(name="idNacionalitat", columns={"idNacionalitat"}), @ORM\Index(name="idPoblacio", columns={"idPoblacio"}), @ORM\Index(name="idProvincia", columns={"idProvincia"})})
 * @ORM\Entity
 */
class Empresa
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idEmpresa", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idempresa;

    /**
     * @var string
     *
     * @ORM\Column(name="nomEmpresa", type="text", length=65535, nullable=false)
     */
    private $nomempresa;

    /**
     * @var string
     *
     * @ORM\Column(name="nifEmpresa", type="text", length=65535, nullable=false)
     */
    private $nifempresa;

    /**
     * @var string
     *
     * @ORM\Column(name="nomResponsable", type="text", length=65535, nullable=false)
     */
    private $nomresponsable;

    /**
     * @var string
     *
     * @ORM\Column(name="informacioEmpresa", type="text", length=65535, nullable=true)
     */
    private $informacioempresa;

    /**
     * @var string
     *
     * @ORM\Column(name="correoEmpresa", type="text", length=65535, nullable=false)
     */
    private $correoempresa;

    /**
     * @var integer
     *
     * @ORM\Column(name="telefonEmpresa", type="integer", nullable=false)
     */
    private $telefonempresa;

    /**
     * @var string
     *
     * @ORM\Column(name="direccio", type="text", length=65535, nullable=false)
     */
    private $direccio;

    /**
     * @var integer
     *
     * @ORM\Column(name="codiPostal", type="integer", nullable=false)
     */
    private $codipostal;

    /**
     * @var boolean
     *
     * @ORM\Column(name="validada", type="boolean", nullable=true)
     */
    private $validada;

    /**
     * @var \Nacionalitat
     *
     * @ORM\ManyToOne(targetEntity="Nacionalitat")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idNacionalitat", referencedColumnName="idNacionalitat")
     * })
     */
    private $idnacionalitat;

    /**
     * @var \Poblacio
     *
     * @ORM\ManyToOne(targetEntity="Poblacio")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idPoblacio", referencedColumnName="idPoblacio")
     * })
     */
    private $idpoblacio;

    /**
     * @var \Provincia
     *
     * @ORM\ManyToOne(targetEntity="Provincia")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idProvincia", referencedColumnName="idProvincia")
     * })
     */
    private $idprovincia;



    /**
     * Get idempresa
     *
     * @return integer
     */
    public function getIdempresa()
    {
        return $this->idempresa;
    }

    /**
     * Set nomempresa
     *
     * @param string $nomempresa
     *
     * @return Empresa
     */
    public function setNomempresa($nomempresa)
    {
        $this->nomempresa = $nomempresa;

        return $this;
    }

    /**
     * Get nomempresa
     *
     * @return string
     */
    public function getNomempresa()
    {
        return $this->nomempresa;
    }

    /**
     * Set nifempresa
     *
     * @param string $nifempresa
     *
     * @return Empresa
     */
    public function setNifempresa($nifempresa)
    {
        $this->nifempresa = $nifempresa;

        return $this;
    }

    /**
     * Get nifempresa
     *
     * @return string
     */
    public function getNifempresa()
    {
        return $this->nifempresa;
    }

    /**
     * Set nomresponsable
     *
     * @param string $nomresponsable
     *
     * @return Empresa
     */
    public function setNomresponsable($nomresponsable)
    {
        $this->nomresponsable = $nomresponsable;

        return $this;
    }

    /**
     * Get nomresponsable
     *
     * @return string
     */
    public function getNomresponsable()
    {
        return $this->nomresponsable;
    }

    /**
     * Set informacioempresa
     *
     * @param string $informacioempresa
     *
     * @return Empresa
     */
    public function setInformacioempresa($informacioempresa)
    {
        $this->informacioempresa = $informacioempresa;

        return $this;
    }

    /**
     * Get informacioempresa
     *
     * @return string
     */
    public function getInformacioempresa()
    {
        return $this->informacioempresa;
    }

    /**
     * Set correoempresa
     *
     * @param string $correoempresa
     *
     * @return Empresa
     */
    public function setCorreoempresa($correoempresa)
    {
        $this->correoempresa = $correoempresa;

        return $this;
    }

    /**
     * Get correoempresa
     *
     * @return string
     */
    public function getCorreoempresa()
    {
        return $this->correoempresa;
    }

    /**
     * Set telefonempresa
     *
     * @param integer $telefonempresa
     *
     * @return Empresa
     */
    public function setTelefonempresa($telefonempresa)
    {
        $this->telefonempresa = $telefonempresa;

        return $this;
    }

    /**
     * Get telefonempresa
     *
     * @return integer
     */
    public function getTelefonempresa()
    {
        return $this->telefonempresa;
    }

    /**
     * Set direccio
     *
     * @param string $direccio
     *
     * @return Empresa
     */
    public function setDireccio($direccio)
    {
        $this->direccio = $direccio;

        return $this;
    }

    /**
     * Get direccio
     *
     * @return string
     */
    public function getDireccio()
    {
        return $this->direccio;
    }

    /**
     * Set codipostal
     *
     * @param integer $codipostal
     *
     * @return Empresa
     */
    public function setCodipostal($codipostal)
    {
        $this->codipostal = $codipostal;

        return $this;
    }

    /**
     * Get codipostal
     *
     * @return integer
     */
    public function getCodipostal()
    {
        return $this->codipostal;
    }

    /**
     * Set validada
     *
     * @param boolean $validada
     *
     * @return Empresa
     */
    public function setValidada($validada)
    {
        $this->validada = $validada;

        return $this;
    }

    /**
     * Get validada
     *
     * @return boolean
     */
    public function getValidada()
    {
        return $this->validada;
    }

    /**
     * Set idnacionalitat
     *
     * @param \borsaTreball\WebBundle\Entity\Nacionalitat $idnacionalitat
     *
     * @return Empresa
     */
    public function setIdnacionalitat(\borsaTreball\WebBundle\Entity\Nacionalitat $idnacionalitat = null)
    {
        $this->idnacionalitat = $idnacionalitat;

        return $this;
    }

    /**
     * Get idnacionalitat
     *
     * @return \borsaTreball\WebBundle\Entity\Nacionalitat
     */
    public function getIdnacionalitat()
    {
        return $this->idnacionalitat;
    }

    /**
     * Set idpoblacio
     *
     * @param \borsaTreball\WebBundle\Entity\Poblacio $idpoblacio
     *
     * @return Empresa
     */
    public function setIdpoblacio(\borsaTreball\WebBundle\Entity\Poblacio $idpoblacio = null)
    {
        $this->idpoblacio = $idpoblacio;

        return $this;
    }

    /**
     * Get idpoblacio
     *
     * @return \borsaTreball\WebBundle\Entity\Poblacio
     */
    public function getIdpoblacio()
    {
        return $this->idpoblacio;
    }

    /**
     * Set idprovincia
     *
     * @param \borsaTreball\WebBundle\Entity\Provincia $idprovincia
     *
     * @return Empresa
     */
    public function setIdprovincia(\borsaTreball\WebBundle\Entity\Provincia $idprovincia = null)
    {
        $this->idprovincia = $idprovincia;

        return $this;
    }

    /**
     * Get idprovincia
     *
     * @return \borsaTreball\WebBundle\Entity\Provincia
     */
    public function getIdprovincia()
    {
        return $this->idprovincia;
    }
}
