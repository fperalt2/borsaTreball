<?php

namespace borsaTreball\WebBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Tipuscontracte
 *
 * @ORM\Table(name="TipusContracte")
 * @ORM\Entity
 */
class Tipuscontracte
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idTipusContracte", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idtipuscontracte;

    /**
     * @var string
     *
     * @ORM\Column(name="nomTipusContracte", type="text", length=65535, nullable=false)
     */
    private $nomtipuscontracte;



    /**
     * Get idtipuscontracte
     *
     * @return integer
     */
    public function getIdtipuscontracte()
    {
        return $this->idtipuscontracte;
    }

    /**
     * Set nomtipuscontracte
     *
     * @param string $nomtipuscontracte
     *
     * @return Tipuscontracte
     */
    public function setNomtipuscontracte($nomtipuscontracte)
    {
        $this->nomtipuscontracte = $nomtipuscontracte;

        return $this;
    }

    /**
     * Get nomtipuscontracte
     *
     * @return string
     */
    public function getNomtipuscontracte()
    {
        return $this->nomtipuscontracte;
    }
}
