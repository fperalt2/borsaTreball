<?php

namespace borsaTreball\WebBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Oferta
 *
 * @ORM\Table(name="Oferta", indexes={@ORM\Index(name="idEstatOferta", columns={"idEstatOferta"}), @ORM\Index(name="idEmpresa", columns={"idEmpresa"}), @ORM\Index(name="idTipusContracte", columns={"idTipusContracte"})})
 * @ORM\Entity
 */
class Oferta
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idOferta", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idoferta;

    /**
     * @var string
     *
     * @ORM\Column(name="sector", type="text", length=65535, nullable=false)
     */
    private $sector;

    /**
     * @var string
     *
     * @ORM\Column(name="descripcio", type="text", length=65535, nullable=true)
     */
    private $descripcio;
    
    /**
     * @var string
     *
     * @ORM\Column(name="infoLlocTreball", type="text", length=65535, nullable=false)
     */
    private $infolloctreball;

    /**
     * @var string
     *
     * @ORM\Column(name="requisits", type="text", length=65535, nullable=false)
     */
    private $requisits;

    /**
     * @var string
     *
     * @ORM\Column(name="condicions", type="text", length=65535, nullable=false)
     */
    private $condicions;

    /**
     * @var integer
     *
     * @ORM\Column(name="treballadorsNecessitats", type="integer", nullable=false)
     */
    private $treballadorsnecessitats;

    /**
     * @var \Estatoferta
     *
     * @ORM\ManyToOne(targetEntity="Estatoferta")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idEstatOferta", referencedColumnName="idEstatOferta")
     * })
     */
    private $idestatoferta;

    /**
     * @var \Empresa
     *
     * @ORM\ManyToOne(targetEntity="Empresa")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idEmpresa", referencedColumnName="idEmpresa")
     * })
     */
    private $idempresa;

    /**
     * @var \Tipuscontracte
     *
     * @ORM\ManyToOne(targetEntity="Tipuscontracte")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idTipusContracte", referencedColumnName="idTipusContracte")
     * })
     */
    private $idtipuscontracte;



    /**
     * Get idoferta
     *
     * @return integer
     */
    public function getIdoferta()
    {
        return $this->idoferta;
    }

    /**
     * Set idoferta
     *
     * @param integer $idoferta
     *
     * @return Oferta
     */
    public function setIdoferta($idoferta)
    {
        $this->idoferta = $idoferta;

        return $this;
    }
    
    /**
     * Set sector
     *
     * @param string $sector
     *
     * @return Oferta
     */
    public function setSector($sector)
    {
        $this->sector = $sector;

        return $this;
    }

    /**
     * Get descripcio
     *
     * @return string
     */
    public function getDescripcio()
    {
        return $this->descripcio;
    }
    
    /**
     * Set descripcio
     *
     * @param string descripcio
     *
     * @return Oferta
     */
    public function setDescripcio($descripcio)
    {
        $this->descripcio = $descripcio;

        return $this;
    }

    /**
     * Get sector
     *
     * @return string
     */
    public function getSector()
    {
        return $this->sector;
    }

    /**
     * Set infolloctreball
     *
     * @param string $infolloctreball
     *
     * @return Oferta
     */
    public function setInfolloctreball($infolloctreball)
    {
        $this->infolloctreball = $infolloctreball;

        return $this;
    }

    /**
     * Get infolloctreball
     *
     * @return string
     */
    public function getInfolloctreball()
    {
        return $this->infolloctreball;
    }

    /**
     * Set requisits
     *
     * @param string $requisits
     *
     * @return Oferta
     */
    public function setRequisits($requisits)
    {
        $this->requisits = $requisits;

        return $this;
    }

    /**
     * Get requisits
     *
     * @return string
     */
    public function getRequisits()
    {
        return $this->requisits;
    }

    /**
     * Set condicions
     *
     * @param string $condicions
     *
     * @return Oferta
     */
    public function setCondicions($condicions)
    {
        $this->condicions = $condicions;

        return $this;
    }

    /**
     * Get condicions
     *
     * @return string
     */
    public function getCondicions()
    {
        return $this->condicions;
    }

    /**
     * Set treballadorsnecessitats
     *
     * @param integer $treballadorsnecessitats
     *
     * @return Oferta
     */
    public function setTreballadorsnecessitats($treballadorsnecessitats)
    {
        $this->treballadorsnecessitats = $treballadorsnecessitats;

        return $this;
    }

    /**
     * Get treballadorsnecessitats
     *
     * @return integer
     */
    public function getTreballadorsnecessitats()
    {
        return $this->treballadorsnecessitats;
    }

    /**
     * Set idestatoferta
     *
     * @param \borsaTreball\WebBundle\Entity\Estatoferta $idestatoferta
     *
     * @return Oferta
     */
    public function setIdestatoferta(\borsaTreball\WebBundle\Entity\Estatoferta $idestatoferta = null)
    {
        $this->idestatoferta = $idestatoferta;

        return $this;
    }

    /**
     * Get idestatoferta
     *
     * @return \borsaTreball\WebBundle\Entity\Estatoferta
     */
    public function getIdestatoferta()
    {
        return $this->idestatoferta;
    }

    /**
     * Set idempresa
     *
     * @param \borsaTreball\WebBundle\Entity\Empresa $idempresa
     *
     * @return Oferta
     */
    public function setIdempresa(\borsaTreball\WebBundle\Entity\Empresa $idempresa = null)
    {
        $this->idempresa = $idempresa;

        return $this;
    }

    /**
     * Get idempresa
     *
     * @return \borsaTreball\WebBundle\Entity\Empresa
     */
    public function getIdempresa()
    {
        return $this->idempresa;
    }

    /**
     * Set idtipuscontracte
     *
     * @param \borsaTreball\WebBundle\Entity\Tipuscontracte $idtipuscontracte
     *
     * @return Oferta
     */
    public function setIdtipuscontracte(\borsaTreball\WebBundle\Entity\Tipuscontracte $idtipuscontracte = null)
    {
        $this->idtipuscontracte = $idtipuscontracte;

        return $this;
    }

    /**
     * Get idtipuscontracte
     *
     * @return \borsaTreball\WebBundle\Entity\Tipuscontracte
     */
    public function getIdtipuscontracte()
    {
        return $this->idtipuscontracte;
    }
}
