<?php

namespace borsaTreball\WebBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Estudi
 *
 * @ORM\Table(name="Estudi", indexes={@ORM\Index(name="Estudi_ibfk_1", columns={"idTipusEstudi"})})
 * @ORM\Entity
 */
class Estudi
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idEstudi", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idestudi;

    /**
     * @var string
     *
     * @ORM\Column(name="nomEstudi", type="text", length=65535, nullable=false)
     */
    private $nomestudi;

    /**
     * @var \Estudiacces
     *
     * @ORM\ManyToOne(targetEntity="Estudiacces")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idTipusEstudi", referencedColumnName="idEstudiAcces")
     * })
     */
    private $idtipusestudi;



    /**
     * Get idestudi
     *
     * @return integer
     */
    public function getIdestudi()
    {
        return $this->idestudi;
    }

    /**
     * Set nomestudi
     *
     * @param string $nomestudi
     *
     * @return Estudi
     */
    public function setNomestudi($nomestudi)
    {
        $this->nomestudi = $nomestudi;

        return $this;
    }

    /**
     * Get nomestudi
     *
     * @return string
     */
    public function getNomestudi()
    {
        return $this->nomestudi;
    }

    /**
     * Set idtipusestudi
     *
     * @param \borsaTreball\WebBundle\Entity\Estudiacces $idtipusestudi
     *
     * @return Estudi
     */
    public function setIdtipusestudi(\borsaTreball\WebBundle\Entity\Estudiacces $idtipusestudi = null)
    {
        $this->idtipusestudi = $idtipusestudi;

        return $this;
    }

    /**
     * Get idtipusestudi
     *
     * @return \borsaTreball\WebBundle\Entity\Estudiacces
     */
    public function getIdtipusestudi()
    {
        return $this->idtipusestudi;
    }
}
