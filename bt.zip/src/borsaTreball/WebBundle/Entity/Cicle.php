<?php

namespace borsaTreball\WebBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Cicle
 *
 * @ORM\Table(name="Cicle")
 * @ORM\Entity
 */
class Cicle
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idCicle", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idcicle;

    /**
     * @var string
     *
     * @ORM\Column(name="nomCicle", type="text", length=65535, nullable=false)
     */
    private $nomcicle;


    /**
     * @var string
     *
     * @ORM\Column(name="sigles", type="text", length=65535, nullable=false)
     */
    private $sigles;

    /**
     * Get idcicle
     *
     * @return integer
     */
    public function getIdcicle()
    {
        return $this->idcicle;
    }
    
    /**
     * Set idcicle
     *
     * @param integer $idcicle
     *
     * @return Cicle
     */
    public function setIdcicle($idcicle)
    {
        $this->idcicle = $idcicle;

        return $this;
    }

    /**
     * Set nomcicle
     *
     * @param string $nomcicle
     *
     * @return Cicle
     */
    public function setNomcicle($nomcicle)
    {
        $this->nomcicle = $nomcicle;

        return $this;
    }

    /**
     * Get nomcicle
     *
     * @return string
     */
    public function getNomcicle()
    {
        return $this->nomcicle;
    }
    
    /**
     * Set sigles
     *
     * @param string $sigles
     *
     * @return Cicle
     */
    public function setSigles($sigles)
    {
        $this->sigles = $sigles;

        return $this;
    }

    /**
     * Get nomcicle
     *
     * @return string
     */
    public function getSigles()
    {
        return $this->sigles;
    }
}
