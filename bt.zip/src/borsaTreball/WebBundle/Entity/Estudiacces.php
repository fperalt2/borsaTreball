<?php

namespace borsaTreball\WebBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Estudiacces
 *
 * @ORM\Table(name="EstudiAcces")
 * @ORM\Entity
 */
class Estudiacces
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idEstudiAcces", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idestudiacces;

    /**
     * @var string
     *
     * @ORM\Column(name="nomEstudi", type="text", length=65535, nullable=false)
     */
    private $nomestudi;



    /**
     * Get idestudiacces
     *
     * @return integer
     */
    public function getIdestudiacces()
    {
        return $this->idestudiacces;
    }

    /**
     * Set nomestudi
     *
     * @param string $nomestudi
     *
     * @return Estudiacces
     */
    public function setNomestudi($nomestudi)
    {
        $this->nomestudi = $nomestudi;

        return $this;
    }

    /**
     * Get nomestudi
     *
     * @return string
     */
    public function getNomestudi()
    {
        return $this->nomestudi;
    }
}
