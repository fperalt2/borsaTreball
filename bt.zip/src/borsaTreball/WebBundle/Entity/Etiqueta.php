<?php

namespace borsaTreball\WebBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Etiqueta
 *
 * @ORM\Table(name="Etiqueta", indexes={@ORM\Index(name="idCicle", columns={"idCicle"})})
 * @ORM\Entity
 */
class Etiqueta
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idEtiqueta", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idetiqueta;

    /**
     * @var string
     *
     * @ORM\Column(name="nomEtiqueta", type="text", length=65535, nullable=false)
     */
    private $nometiqueta;

    /**
     * @var \Cicle
     *
     * @ORM\ManyToOne(targetEntity="Cicle")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idCicle", referencedColumnName="idCicle")
     * })
     */
    private $idcicle;



    /**
     * Get idetiqueta
     *
     * @return integer
     */
    public function getIdetiqueta()
    {
        return $this->idetiqueta;
    }

    /**
     * Set idetiqueta
     *
     * @param integer $idetiqueta
     *
     * @return Etiqueta
     */
    public function setIdetiqueta($idetiqueta)
    {
        $this->idetiqueta = $idetiqueta;

        return $this;
    }
    
    /**
     * Set nometiqueta
     *
     * @param string $nometiqueta
     *
     * @return Etiqueta
     */
    public function setNometiqueta($nometiqueta)
    {
        $this->nometiqueta = $nometiqueta;

        return $this;
    }

    /**
     * Get nometiqueta
     *
     * @return string
     */
    public function getNometiqueta()
    {
        return $this->nometiqueta;
    }

    /**
     * Set idcicle
     *
     * @param \borsaTreball\WebBundle\Entity\Cicle $idcicle
     *
     * @return Etiqueta
     */
    public function setIdcicle(\borsaTreball\WebBundle\Entity\Cicle $idcicle = null)
    {
        $this->idcicle = $idcicle;

        return $this;
    }

    /**
     * Get idcicle
     *
     * @return \borsaTreball\WebBundle\Entity\Cicle
     */
    public function getIdcicle()
    {
        return $this->idcicle;
    }
}
