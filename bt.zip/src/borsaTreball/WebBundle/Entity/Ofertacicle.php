<?php

namespace borsaTreball\WebBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Ofertacicle
 *
 * @ORM\Table(name="OfertaCicle", indexes={@ORM\Index(name="idOferta", columns={"idOferta"}), @ORM\Index(name="OfertaCicle_ibfk_2", columns={"idCicle"})})
 * @ORM\Entity
 */
class Ofertacicle
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idOfertaCicle", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idofertacicle;

    /**
     * @var \Oferta
     *
     * @ORM\ManyToOne(targetEntity="Oferta"), cascade={"persist"}
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idOferta", referencedColumnName="idOferta")
     * })
     */
    private $idoferta;

    /**
     * @var \Cicle
     *
     * @ORM\ManyToOne(targetEntity="Cicle", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idCicle", referencedColumnName="idCicle")
     * })
     */
    private $idcicle;



    /**
     * Get idofertacicle
     *
     * @return integer
     */
    public function getIdofertacicle()
    {
        return $this->idofertacicle;
    }

    /**
     * Set idoferta
     *
     * @param \borsaTreball\WebBundle\Entity\Oferta $idoferta
     *
     * @return Ofertacicle
     */
    public function setIdoferta(\borsaTreball\WebBundle\Entity\Oferta $idoferta = null)
    {
        $this->idoferta = $idoferta;

        return $this;
    }

    /**
     * Get idoferta
     *
     * @return \borsaTreball\WebBundle\Entity\Oferta
     */
    public function getIdoferta()
    {
        return $this->idoferta;
    }

    /**
     * Set idcicle
     *
     * @param \borsaTreball\WebBundle\Entity\Cicle $idcicle
     *
     * @return Ofertacicle
     */
    public function setIdcicle(\borsaTreball\WebBundle\Entity\Cicle $idcicle = null)
    {
        $this->idcicle = $idcicle;

        return $this;
    }

    /**
     * Get idcicle
     *
     * @return \borsaTreball\WebBundle\Entity\Cicle
     */
    public function getIdcicle()
    {
        return $this->idcicle;
    }
}
