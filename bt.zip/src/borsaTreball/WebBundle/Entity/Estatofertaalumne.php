<?php

namespace borsaTreball\WebBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Estatofertaalumne
 *
 * @ORM\Table(name="EstatOfertaAlumne")
 * @ORM\Entity
 */
class Estatofertaalumne
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idEstatOfertaAlumne", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idestatofertaalumne;

    /**
     * @var string
     *
     * @ORM\Column(name="nomEstatOfertaAlumne", type="text", length=65535, nullable=false)
     */
    private $nomestatofertaalumne;


/**
     * Set idestatofertaalumne
     *
     * @param integer $idestatofertaalumne
     *
     * @return idestatofertaalumne
     */
    public function setIdestatofertaalumne($idestatofertaalumne)
    {
        $this->idestatofertaalumne = $idestatofertaalumne;

        return $this;
    }
    
    /**
     * Get idestatofertaalumne
     *
     * @return integer
     */
    public function getIdestatofertaalumne()
    {
        return $this->idestatofertaalumne;
    }

    /**
     * Set nomestatofertaalumne
     *
     * @param string $nomestatofertaalumne
     *
     * @return Estatofertaalumne
     */
    public function setNomestatofertaalumne($nomestatofertaalumne)
    {
        $this->nomestatofertaalumne = $nomestatofertaalumne;

        return $this;
    }

    /**
     * Get nomestatofertaalumne
     *
     * @return string
     */
    public function getNomestatofertaalumne()
    {
        return $this->nomestatofertaalumne;
    }
}
