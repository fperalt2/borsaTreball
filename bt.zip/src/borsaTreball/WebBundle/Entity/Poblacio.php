<?php

namespace borsaTreball\WebBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Poblacio
 *
 * @ORM\Table(name="Poblacio", indexes={@ORM\Index(name="idProvincia", columns={"idProvincia"})})
 * @ORM\Entity
 */
class Poblacio
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idPoblacio", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idpoblacio;

    /**
     * @var string
     *
     * @ORM\Column(name="nomPoblacio", type="string", length=43, nullable=true)
     */
    private $nompoblacio;

    /**
     * @var \Provincia
     *
     * @ORM\ManyToOne(targetEntity="Provincia")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idProvincia", referencedColumnName="idProvincia")
     * })
     */
    private $idprovincia;



    /**
     * Get idpoblacio
     *
     * @return integer
     */
    public function getIdpoblacio()
    {
        return $this->idpoblacio;
    }

    /**
     * Set nompoblacio
     *
     * @param string $nompoblacio
     *
     * @return Poblacio
     */
    public function setNompoblacio($nompoblacio)
    {
        $this->nompoblacio = $nompoblacio;

        return $this;
    }

    /**
     * Get nompoblacio
     *
     * @return string
     */
    public function getNompoblacio()
    {
        return $this->nompoblacio;
    }

    /**
     * Set idprovincia
     *
     * @param \borsaTreball\WebBundle\Entity\Provincia $idprovincia
     *
     * @return Poblacio
     */
    public function setIdprovincia(\borsaTreball\WebBundle\Entity\Provincia $idprovincia = null)
    {
        $this->idprovincia = $idprovincia;

        return $this;
    }

    /**
     * Get idprovincia
     *
     * @return \borsaTreball\WebBundle\Entity\Provincia
     */
    public function getIdprovincia()
    {
        return $this->idprovincia;
    }
}
