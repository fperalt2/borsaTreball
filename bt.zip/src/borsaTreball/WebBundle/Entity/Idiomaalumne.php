<?php

namespace borsaTreball\WebBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Idiomaalumne
 *
 * @ORM\Table(name="IdiomaAlumne", indexes={@ORM\Index(name="idAlumne", columns={"idAlumne"}), @ORM\Index(name="idIdioma", columns={"idIdioma"})})
 * @ORM\Entity
 */
class Idiomaalumne
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idIdiomaAlumne", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $ididiomaalumne;

    /**
     * @var string
     *
     * @ORM\Column(name="nivellIdioma", type="text", length=65535, nullable=false)
     */
    private $nivellidioma;

    /**
     * @var \Alumne
     *
     * @ORM\ManyToOne(targetEntity="Alumne")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idAlumne", referencedColumnName="idAlumne")
     * })
     */
    private $idalumne;

    /**
     * @var \Idioma
     *
     * @ORM\ManyToOne(targetEntity="Idioma")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idIdioma", referencedColumnName="idIdioma")
     * })
     */
    private $ididioma;



    /**
     * Get ididiomaalumne
     *
     * @return integer
     */
    public function getIdidiomaalumne()
    {
        return $this->ididiomaalumne;
    }

    /**
     * Set nivellidioma
     *
     * @param string $nivellidioma
     *
     * @return Idiomaalumne
     */
    public function setNivellidioma($nivellidioma)
    {
        $this->nivellidioma = $nivellidioma;

        return $this;
    }

    /**
     * Get nivellidioma
     *
     * @return string
     */
    public function getNivellidioma()
    {
        return $this->nivellidioma;
    }

    /**
     * Set idalumne
     *
     * @param \borsaTreball\WebBundle\Entity\Alumne $idalumne
     *
     * @return Idiomaalumne
     */
    public function setIdalumne(\borsaTreball\WebBundle\Entity\Alumne $idalumne = null)
    {
        $this->idalumne = $idalumne;

        return $this;
    }

    /**
     * Get idalumne
     *
     * @return \borsaTreball\WebBundle\Entity\Alumne
     */
    public function getIdalumne()
    {
        return $this->idalumne;
    }

    /**
     * Set ididioma
     *
     * @param \borsaTreball\WebBundle\Entity\Idioma $ididioma
     *
     * @return Idiomaalumne
     */
    public function setIdidioma(\borsaTreball\WebBundle\Entity\Idioma $ididioma = null)
    {
        $this->ididioma = $ididioma;

        return $this;
    }

    /**
     * Get ididioma
     *
     * @return \borsaTreball\WebBundle\Entity\Idioma
     */
    public function getIdidioma()
    {
        return $this->ididioma;
    }
}
