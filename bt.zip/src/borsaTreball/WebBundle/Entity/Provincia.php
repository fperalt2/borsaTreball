<?php

namespace borsaTreball\WebBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Provincia
 *
 * @ORM\Table(name="Provincia")
 * @ORM\Entity
 */
class Provincia
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idProvincia", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idprovincia;

    /**
     * @var string
     *
     * @ORM\Column(name="nomProvincia", type="text", length=65535, nullable=false)
     */
    private $nomprovincia;



    /**
     * Get idprovincia
     *
     * @return integer
     */
    public function getIdprovincia()
    {
        return $this->idprovincia;
    }

    /**
     * Set nomprovincia
     *
     * @param string $nomprovincia
     *
     * @return Provincia
     */
    public function setNomprovincia($nomprovincia)
    {
        $this->nomprovincia = $nomprovincia;

        return $this;
    }

    /**
     * Get nomprovincia
     *
     * @return string
     */
    public function getNomprovincia()
    {
        return $this->nomprovincia;
    }
}
