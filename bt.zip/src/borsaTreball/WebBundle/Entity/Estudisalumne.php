<?php

namespace borsaTreball\WebBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Estudisalumne
 *
 * @ORM\Table(name="EstudisAlumne", indexes={@ORM\Index(name="idAlumne", columns={"idAlumne"}), @ORM\Index(name="idEstudi", columns={"idEstudi"})})
 * @ORM\Entity
 */
class Estudisalumne
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idEstudisAlumne", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idestudisalumne;

    /**
     * @var boolean
     *
     * @ORM\Column(name="finalitzat", type="boolean", nullable=false)
     */
    private $finalitzat;

    /**
     * @var \Alumne
     *
     * @ORM\ManyToOne(targetEntity="Alumne")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idAlumne", referencedColumnName="idAlumne")
     * })
     */
    private $idalumne;

    /**
     * @var \Estudi
     *
     * @ORM\ManyToOne(targetEntity="Estudi")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idEstudi", referencedColumnName="idEstudi")
     * })
     */
    private $idestudi;



    /**
     * Get idestudisalumne
     *
     * @return integer
     */
    public function getIdestudisalumne()
    {
        return $this->idestudisalumne;
    }

    /**
     * Set finalitzat
     *
     * @param boolean $finalitzat
     *
     * @return Estudisalumne
     */
    public function setFinalitzat($finalitzat)
    {
        $this->finalitzat = $finalitzat;

        return $this;
    }

    /**
     * Get finalitzat
     *
     * @return boolean
     */
    public function getFinalitzat()
    {
        return $this->finalitzat;
    }

    /**
     * Set idalumne
     *
     * @param \borsaTreball\WebBundle\Entity\Alumne $idalumne
     *
     * @return Estudisalumne
     */
    public function setIdalumne(\borsaTreball\WebBundle\Entity\Alumne $idalumne = null)
    {
        $this->idalumne = $idalumne;

        return $this;
    }

    /**
     * Get idalumne
     *
     * @return \borsaTreball\WebBundle\Entity\Alumne
     */
    public function getIdalumne()
    {
        return $this->idalumne;
    }

    /**
     * Set idestudi
     *
     * @param \borsaTreball\WebBundle\Entity\Estudi $idestudi
     *
     * @return Estudisalumne
     */
    public function setIdestudi(\borsaTreball\WebBundle\Entity\Estudi $idestudi = null)
    {
        $this->idestudi = $idestudi;

        return $this;
    }

    /**
     * Get idestudi
     *
     * @return \borsaTreball\WebBundle\Entity\Estudi
     */
    public function getIdestudi()
    {
        return $this->idestudi;
    }
}
