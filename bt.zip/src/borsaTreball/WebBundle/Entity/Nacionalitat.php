<?php

namespace borsaTreball\WebBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Nacionalitat
 *
 * @ORM\Table(name="Nacionalitat")
 * @ORM\Entity
 */
class Nacionalitat
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idNacionalitat", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idnacionalitat;

    /**
     * @var string
     *
     * @ORM\Column(name="nomNacionalitat", type="text", length=65535, nullable=true)
     */
    private $nomnacionalitat;



    /**
     * Get idnacionalitat
     *
     * @return integer
     */
    public function getIdnacionalitat()
    {
        return $this->idnacionalitat;
    }

    /**
     * Set nomnacionalitat
     *
     * @param string $nomnacionalitat
     *
     * @return Nacionalitat
     */
    public function setNomnacionalitat($nomnacionalitat)
    {
        $this->nomnacionalitat = $nomnacionalitat;

        return $this;
    }

    /**
     * Get nomnacionalitat
     *
     * @return string
     */
    public function getNomnacionalitat()
    {
        return $this->nomnacionalitat;
    }
}
