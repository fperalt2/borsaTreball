<?php

namespace borsaTreball\WebBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Ofertaetiqueta
 *
 * @ORM\Table(name="OfertaEtiqueta", indexes={@ORM\Index(name="idOferta", columns={"idOferta"}), @ORM\Index(name="idEtiqueta", columns={"idEtiqueta"})})
 * @ORM\Entity
 */
class Ofertaetiqueta
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idOfertaEtiqueta", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idofertaetiqueta;

    /**
     * @var \Oferta
     *
     * @ORM\ManyToOne(targetEntity="Oferta", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idOferta", referencedColumnName="idOferta")
     * })
     */
    private $idoferta;

    /**
     * @var \Etiqueta
     *
     * @ORM\ManyToOne(targetEntity="Etiqueta", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idEtiqueta", referencedColumnName="idEtiqueta")
     * })
     */
    private $idetiqueta;



    /**
     * Get idofertaetiqueta
     *
     * @return integer
     */
    public function getIdofertaetiqueta()
    {
        return $this->idofertaetiqueta;
    }

    /**
     * Set idoferta
     *
     * @param \borsaTreball\WebBundle\Entity\Oferta $idoferta
     *
     * @return Ofertaetiqueta
     */
    public function setIdoferta(\borsaTreball\WebBundle\Entity\Oferta $idoferta = null)
    {
        $this->idoferta = $idoferta;

        return $this;
    }

    /**
     * Get idoferta
     *
     * @return \borsaTreball\WebBundle\Entity\Oferta
     */
    public function getIdoferta()
    {
        return $this->idoferta;
    }

    /**
     * Set idetiqueta
     *
     * @param \borsaTreball\WebBundle\Entity\Etiqueta $idetiqueta
     *
     * @return Ofertaetiqueta
     */
    public function setIdetiqueta(\borsaTreball\WebBundle\Entity\Etiqueta $idetiqueta = null)
    {
        $this->idetiqueta = $idetiqueta;

        return $this;
    }

    /**
     * Get idetiqueta
     *
     * @return \borsaTreball\WebBundle\Entity\Etiqueta
     */
    public function getIdetiqueta()
    {
        return $this->idetiqueta;
    }
}
