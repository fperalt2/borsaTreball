<?php

namespace borsaTreball\WebBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Ofertaalumne
 *
 * @ORM\Table(name="OfertaAlumne", indexes={@ORM\Index(name="idEstatOfertaAlumne", columns={"idEstatOfertaAlumne"}), @ORM\Index(name="idAlumne", columns={"idAlumne"}), @ORM\Index(name="idOferta", columns={"idOferta"})})
 * @ORM\Entity
 */
class Ofertaalumne
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idOfertaAlumne", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idofertaalumne;

    /**
     * @var \Estatofertaalumne
     *
     * @ORM\ManyToOne(targetEntity="Estatofertaalumne", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idEstatOfertaAlumne", referencedColumnName="idEstatOfertaAlumne")
     * })
     */
    private $idestatofertaalumne;

    /**
     * @var \Alumne
     *
     * @ORM\ManyToOne(targetEntity="Alumne", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idAlumne", referencedColumnName="idAlumne")
     * })
     */
    private $idalumne;

    /**
     * @var \Oferta
     *
     * @ORM\ManyToOne(targetEntity="Oferta", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idOferta", referencedColumnName="idOferta")
     * })
     */
    private $idoferta;



    /**
     * Get idofertaalumne
     *
     * @return integer
     */
    public function getIdofertaalumne()
    {
        return $this->idofertaalumne;
    }

    /**
     * Set idofertaalumne
     *
     * @param integer $idofertaalumne
     *
     * @return Oferta
     */
    public function setIdofertaalumne($idofertaalumne)
    {
        $this->idofertaalumne = $idofertaalumne;

        return $this;
    }
    
    /**
     * Set idestatofertaalumne
     *
     * @param \borsaTreball\WebBundle\Entity\Estatofertaalumne $idestatofertaalumne
     *
     * @return Ofertaalumne
     */
    public function setIdestatofertaalumne(\borsaTreball\WebBundle\Entity\Estatofertaalumne $idestatofertaalumne = null)
    {
        $this->idestatofertaalumne = $idestatofertaalumne;

        return $this;
    }

    /**
     * Get idestatofertaalumne
     *
     * @return \borsaTreball\WebBundle\Entity\Estatofertaalumne
     */
    public function getIdestatofertaalumne()
    {
        return $this->idestatofertaalumne;
    }

    /**
     * Set idalumne
     *
     * @param \borsaTreball\WebBundle\Entity\Alumne $idalumne
     *
     * @return Ofertaalumne
     */
    public function setIdalumne(\borsaTreball\WebBundle\Entity\Alumne $idalumne = null)
    {
        $this->idalumne = $idalumne;

        return $this;
    }

    /**
     * Get idalumne
     *
     * @return \borsaTreball\WebBundle\Entity\Alumne
     */
    public function getIdalumne()
    {
        return $this->idalumne;
    }

    /**
     * Set idoferta
     *
     * @param \borsaTreball\WebBundle\Entity\Oferta $idoferta
     *
     * @return Ofertaalumne
     */
    public function setIdoferta(\borsaTreball\WebBundle\Entity\Oferta $idoferta = null)
    {
        $this->idoferta = $idoferta;

        return $this;
    }

    /**
     * Get idoferta
     *
     * @return \borsaTreball\WebBundle\Entity\Oferta
     */
    public function getIdoferta()
    {
        return $this->idoferta;
    }
}
