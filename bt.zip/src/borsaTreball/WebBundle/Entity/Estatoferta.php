<?php

namespace borsaTreball\WebBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Estatoferta
 *
 * @ORM\Table(name="EstatOferta")
 * @ORM\Entity
 */
class Estatoferta
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idEstatOferta", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idestatoferta;

    /**
     * @var string
     *
     * @ORM\Column(name="nomEstatOferta", type="text", length=65535, nullable=false)
     */
    private $nomestatoferta;



    /**
     * Get idestatoferta
     *
     * @return integer
     */
    public function getIdestatoferta()
    {
        return $this->idestatoferta;
    }

    /**
     * Set nomestatoferta
     *
     * @param string $nomestatoferta
     *
     * @return Estatoferta
     */
    public function setNomestatoferta($nomestatoferta)
    {
        $this->nomestatoferta = $nomestatoferta;

        return $this;
    }

    /**
     * Get nomestatoferta
     *
     * @return string
     */
    public function getNomestatoferta()
    {
        return $this->nomestatoferta;
    }
}
