<?php

namespace borsaTreball\WebBundle\Entity;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\ORM\Mapping as ORM;


class FiltreCicle
{
    private $nivellcurs;

    private $idcicle;

    public function setNivellcurs($nivellcurs)
    {
        $this->nivellcurs = $nivellcurs;

        return $this;
    }

    /**
     * Get nivellcurs
     *
     * @return integer
     */
    public function getNivellcurs()
    {
        return $this->nivellcurs;
    }
    
    /**
     * Set idcicle
     *
     * @param \borsaTreball\WebBundle\Entity\Cicle $idcicle
     *
     * @return FiltreCicle
     */
    public function setIdcicle(\borsaTreball\WebBundle\Entity\Cicle $idcicle = null)
    {
        $this->idcicle = $idcicle;

        return $this;
    }

    /**
     * Get idcicle
     *
     * @return \borsaTreball\WebBundle\Entity\Cicle
     */
    public function getIdcicle()
    {
        return $this->idcicle;
    }

    public function __toString()
    {
     //   return (string) $this->getIdalumne();
    }
}
