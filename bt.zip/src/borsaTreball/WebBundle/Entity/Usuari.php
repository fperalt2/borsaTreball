<?php

namespace borsaTreball\WebBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Security\Core\User\UserInterface;


/**
 * Usuari
 *
 * @ORM\Table(name="Usuari", indexes={@ORM\Index(name="idTipusUsuari", columns={"idTipusUsuari"}), @ORM\Index(name="idReferencial", columns={"idAlumne"}), @ORM\Index(name="Usuari_ibfk_3", columns={"idEmpresa"}), @ORM\Index(name="Usuari_ibfk_4", columns={"idProfessor"})})
 * @ORM\Entity
 */
class Usuari implements UserInterface
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idUsuari", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idusuari;

    /**
     * @var string
     *
     * @ORM\Column(name="nomUsuari", type="text", length=65535, nullable=false)
     */
    private $nomusuari;

    /**
     * @var string
     *
     * @ORM\Column(name="password", type="text", length=65535, nullable=false)
     */
    private $password;

    /**
     * @var \Tipususuari
     *
     * @ORM\ManyToOne(targetEntity="Tipususuari", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idTipusUsuari", referencedColumnName="idTipusUsuari")
     * })
     */
    private $idtipususuari;

    /**
     * @var \Alumne
     *
     * @ORM\ManyToOne(targetEntity="Alumne", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idAlumne", referencedColumnName="idAlumne")
     * })
     */
    private $idalumne;

    /**
     * @var \Empresa
     *
     * @ORM\ManyToOne(targetEntity="Empresa")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idEmpresa", referencedColumnName="idEmpresa")
     * })
     */
    private $idempresa;

    /**
     * @var \Professor
     *
     * @ORM\ManyToOne(targetEntity="Professor")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idProfessor", referencedColumnName="idProfessor")
     * })
     */
    private $idprofessor;



    /**
     * Get idusuari
     *
     * @return integer
     */
    public function getIdusuari()
    {
        return $this->idusuari;
    }

    /**
     * Set nomusuari
     *
     * @param string $nomusuari
     *
     * @return Usuari
     */
    public function setNomusuari($nomusuari)
    {
        $this->nomusuari = $nomusuari;

        return $this;
    }

    /**
     * Get nomusuari
     *
     * @return string
     */
    public function getNomusuari()
    {
        return $this->nomusuari;
    }

    /**
     * Set password
     *
     * @param string $password
     *
     * @return Usuari
     */
    public function setPassword($password)
    {
        $this->password = $password;

        return $this;
    }

    /**
     * Get password
     *
     * @return string
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * Set idtipususuari
     *
     * @param \borsaTreball\WebBundle\Entity\Tipususuari $idtipususuari
     *
     * @return Usuari
     */
    public function setIdtipususuari(\borsaTreball\WebBundle\Entity\Tipususuari $idtipususuari = null)
    {
        $this->idtipususuari = $idtipususuari;

        return $this;
    }

    /**
     * Get idtipususuari
     *
     * @return \borsaTreball\WebBundle\Entity\Tipususuari
     */
    public function getIdtipususuari()
    {
        return $this->idtipususuari;
    }

    /**
     * Set idalumne
     *
     * @param \borsaTreball\WebBundle\Entity\Alumne $idalumne
     *
     * @return Usuari
     */
    public function setIdalumne(\borsaTreball\WebBundle\Entity\Alumne $idalumne = null)
    {
        $this->idalumne = $idalumne;

        return $this;
    }

    /**
     * Get idalumne
     *
     * @return \borsaTreball\WebBundle\Entity\Alumne
     */
    public function getIdalumne()
    {
        return $this->idalumne;
    }

    /**
     * Set idempresa
     *
     * @param \borsaTreball\WebBundle\Entity\Empresa $idempresa
     *
     * @return Usuari
     */
    public function setIdempresa(\borsaTreball\WebBundle\Entity\Empresa $idempresa = null)
    {
        $this->idempresa = $idempresa;

        return $this;
    }

    /**
     * Get idempresa
     *
     * @return \borsaTreball\WebBundle\Entity\Empresa
     */
    public function getIdempresa()
    {
        return $this->idempresa;
    }

    /**
     * Set idprofessor
     *
     * @param \borsaTreball\WebBundle\Entity\Professor $idprofessor
     *
     * @return Usuari
     */
    public function setIdprofessor(\borsaTreball\WebBundle\Entity\Professor $idprofessor = null)
    {
        $this->idprofessor = $idprofessor;

        return $this;
    }

    /**
     * Get idprofessor
     *
     * @return \borsaTreball\WebBundle\Entity\Professor
     */
    public function getIdprofessor()
    {
        return $this->idprofessor;
    }
    
       /**
     * Get nomusuari/username
     *
     * @return string
     */
    public function getUsername()
    {
        return $this->nomusuari;
    }

    public function getSalt()
    {
        return null;
    }

    public function getRoles()
    {
        // En este caso definimos un rol fijo, en el caso de que tengamos un campo role en la tabla de la BBDD    tendríamos que hacer $this->getRole()
        return ["ROLE_".$this->idtipususuari->getIdtipususuari().""];
    }

    public function eraseCredentials()
    {
    }
    
    public function __toString() {
        return strval($this->idusuari);
    }
}