<?php

namespace borsaTreball\WebBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Tipususuari
 *
 * @ORM\Table(name="TipusUsuari")
 * @ORM\Entity
 */
class Tipususuari
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idTipusUsuari", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idtipususuari;

    /**
     * @var string
     *
     * @ORM\Column(name="nomTipus", type="text", length=65535, nullable=false)
     */
    private $nomtipus;



     /**
     * Set idtipususuari
     *
     */
    public function setIdtipususuari($idtipususuari)
    {
        $this->idtipususuari = $idtipususuari;

        return $this;
    }
    
    /**
     * Get idtipususuari
     *
     * @return integer
     */
    public function getIdtipususuari()
    {
        return $this->idtipususuari;
    }

    /**
     * Set nomtipus
     *
     * @param string $nomtipus
     *
     * @return Tipususuari
     */
    public function setNomtipus($nomtipus)
    {
        $this->nomtipus = $nomtipus;

        return $this;
    }

    /**
     * Get nomtipus
     *
     * @return string
     */
    public function getNomtipus()
    {
        return $this->nomtipus;
    }
}
