<?php

namespace borsaTreball\WebBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Etiquetaalumne
 *
 * @ORM\Table(name="EtiquetaAlumne", indexes={@ORM\Index(name="idAlumne", columns={"idAlumne"}), @ORM\Index(name="idEtiqueta", columns={"idEtiqueta"})})
 * @ORM\Entity
 */
class Etiquetaalumne
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idEtiquetaAlumne", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idetiquetaalumne;

    /**
     * @var \Alumne
     *
     * @ORM\ManyToOne(targetEntity="Alumne")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idAlumne", referencedColumnName="idAlumne")
     * })
     */
    private $idalumne;

    /**
     * @var \Etiqueta
     *
     * @ORM\ManyToOne(targetEntity="Etiqueta")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="idEtiqueta", referencedColumnName="idEtiqueta")
     * })
     */
    private $idetiqueta;



    /**
     * Get idetiquetaalumne
     *
     * @return integer
     */
    public function getIdetiquetaalumne()
    {
        return $this->idetiquetaalumne;
    }

    /**
     * Set idalumne
     *
     * @param \borsaTreball\WebBundle\Entity\Alumne $idalumne
     *
     * @return Etiquetaalumne
     */
    public function setIdalumne(\borsaTreball\WebBundle\Entity\Alumne $idalumne = null)
    {
        $this->idalumne = $idalumne;

        return $this;
    }

    /**
     * Get idalumne
     *
     * @return \borsaTreball\WebBundle\Entity\Alumne
     */
    public function getIdalumne()
    {
        return $this->idalumne;
    }

    /**
     * Set idetiqueta
     *
     * @param \borsaTreball\WebBundle\Entity\Etiqueta $idetiqueta
     *
     * @return Etiquetaalumne
     */
    public function setIdetiqueta(\borsaTreball\WebBundle\Entity\Etiqueta $idetiqueta = null)
    {
        $this->idetiqueta = $idetiqueta;

        return $this;
    }

    /**
     * Get idetiqueta
     *
     * @return \borsaTreball\WebBundle\Entity\Etiqueta
     */
    public function getIdetiqueta()
    {
        return $this->idetiqueta;
    }
}
