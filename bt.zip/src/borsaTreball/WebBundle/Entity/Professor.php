<?php

namespace borsaTreball\WebBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Professor
 *
 * @ORM\Table(name="Professor")
 * @ORM\Entity
 */
class Professor
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idProfessor", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idprofessor;

    /**
     * @var string
     *
     * @ORM\Column(name="nomProfessor", type="text", length=65535, nullable=false)
     */
    private $nomprofessor;

    /**
     * @var string
     *
     * @ORM\Column(name="cognomProfessor", type="text", length=65535, nullable=false)
     */
    private $cognomprofessor;

    /**
     * @var string
     *
     * @ORM\Column(name="email", type="text", length=65535, nullable=false)
     */
    private $email;

    /**
     * @var string
     *
     * @ORM\Column(name="linkedin", type="text", length=65535, nullable=false)
     */
    private $linkedin;



    /**
     * Get idprofessor
     *
     * @return integer
     */
    public function getIdprofessor()
    {
        return $this->idprofessor;
    }

    /**
     * Set nomprofessor
     *
     * @param string $nomprofessor
     *
     * @return Professor
     */
    public function setNomprofessor($nomprofessor)
    {
        $this->nomprofessor = $nomprofessor;

        return $this;
    }

    /**
     * Get nomprofessor
     *
     * @return string
     */
    public function getNomprofessor()
    {
        return $this->nomprofessor;
    }

    /**
     * Set cognomprofessor
     *
     * @param string $cognomprofessor
     *
     * @return Professor
     */
    public function setCognomprofessor($cognomprofessor)
    {
        $this->cognomprofessor = $cognomprofessor;

        return $this;
    }

    /**
     * Get cognomprofessor
     *
     * @return string
     */
    public function getCognomprofessor()
    {
        return $this->cognomprofessor;
    }

    /**
     * Set email
     *
     * @param string $email
     *
     * @return Professor
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set linkedin
     *
     * @param string $linkedin
     *
     * @return Professor
     */
    public function setLinkedin($linkedin)
    {
        $this->linkedin = $linkedin;

        return $this;
    }

    /**
     * Get linkedin
     *
     * @return string
     */
    public function getLinkedin()
    {
        return $this->linkedin;
    }
}
